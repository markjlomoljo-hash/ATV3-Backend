"""
One-time seed script. Run with: python -m app.db.seed

Seeds the model_versions registry (so intelligence_service has real rows to
report instead of an empty "no models registered" state) and a starter set
of IngredientProfile rows sourced from established cosmetic-dermatology
comedogenicity literature (the Fulton scale and subsequent replications),
replacing v2's ~20-entry hardcoded in-bundle dictionary with the first rows
of a real, growable reference table. This is a starting seed, not a ceiling -
product_service in Phase 2 should keep extending this table as new
ingredients are encountered, ideally backed by an evidence_source citation
per entry rather than expanding it as another hardcoded list.
"""
import asyncio

from sqlalchemy import select

from app.db.models.intelligence import ModelVersion
from app.db.models.products import IngredientProfile
from app.db.session import AsyncSessionLocal

MODEL_VERSIONS = [
    {"service": "face_pipeline", "version": "v3.0.0-bootstrap", "description": "Real image-quality + face-presence validation; full lesion classification model pending Phase 2 training data volume.", "is_active": True},
    {"service": "forecast_pipeline", "version": "v3.0.0-bootstrap", "description": "Transparent baseline statistical model (weighted recent-history regression), upgradeable to a trained model once sufficient population data exists.", "is_active": True},
    {"service": "product_pipeline", "version": "v3.0.0-bootstrap", "description": "Rule-based ingredient cross-reference against IngredientProfile + evidence_sources.", "is_active": True},
    {"service": "assistant_routing", "version": "v3.0.0-bootstrap", "description": "Anthropic API (claude-sonnet-4-6) with RAG over evidence_sources and structured self-check pass.", "is_active": True},
]

# (name, comedogenic_rating 0-5, irritant_risk, hormonal_disruption_risk, occlusive_rating, barrier_support, mechanism_notes)
INGREDIENT_SEED = [
    ("Coconut Oil", 4.0, "low", "low", "high", "disruptive", "High comedogenic rating on the Fulton scale; occlusive enough to trap sebum/debris in follicles prone to acne."),
    ("Isopropyl Myristate", 5.0, "low", "low", "high", "disruptive", "Consistently rated highly comedogenic across replication studies; common emollient in older-formulation cosmetics."),
    ("Mineral Oil (Cosmetic Grade)", 1.0, "low", "low", "moderate", "neutral", "Highly refined cosmetic-grade mineral oil is low-comedogenic despite its reputation; occlusive but inert."),
    ("Niacinamide", 0.0, "low", "low", "low", "supportive", "Reduces sebum production and supports barrier lipid synthesis; widely used to address acne and barrier impairment together."),
    ("Salicylic Acid", 0.0, "moderate", "low", "low", "supportive", "Lipophilic BHA that exfoliates within the follicle; can be irritating at high concentration or frequency."),
    ("Benzoyl Peroxide", 0.0, "moderate", "low", "low", "neutral", "Antibacterial/keratolytic; effective against P. acnes but commonly causes dryness/irritation, especially early in use."),
    ("Dimethicone", 0.5, "low", "low", "moderate", "supportive", "Silicone occlusive that forms a breathable film; generally non-comedogenic despite being occlusive."),
    ("Cocoa Butter", 4.0, "low", "low", "high", "disruptive", "Highly comedogenic on the Fulton scale; common in heavier moisturizers and lip products."),
    ("Hyaluronic Acid", 0.0, "low", "low", "low", "supportive", "Humectant; supports barrier hydration without occlusion or pore-clogging."),
    ("Lanolin", 2.0, "moderate", "low", "high", "neutral", "Moderately comedogenic; also a recognized contact-allergen for a meaningful minority of users."),
    ("Retinol", 0.0, "moderate", "low", "low", "supportive", "Normalizes keratinization and reduces comedone formation; barrier-disruptive during initial adjustment (retinization)."),
    ("Fragrance (Parfum)", 0.0, "high", "low", "low", "disruptive", "Leading cause of cosmetic contact irritation/allergy; not comedogenic but a common barrier and sensitivity trigger."),
]


async def seed() -> None:
    async with AsyncSessionLocal() as db:
        for mv in MODEL_VERSIONS:
            existing = (await db.execute(select(ModelVersion).where(ModelVersion.service == mv["service"], ModelVersion.version == mv["version"]))).scalar_one_or_none()
            if existing is None:
                db.add(ModelVersion(**mv))

        for name, comedo, irritant, hormonal, occlusive, barrier, notes in INGREDIENT_SEED:
            existing = (await db.execute(select(IngredientProfile).where(IngredientProfile.name == name))).scalar_one_or_none()
            if existing is None:
                db.add(IngredientProfile(
                    name=name, comedogenic_rating=comedo, irritant_risk=irritant,
                    hormonal_disruption_risk=hormonal, occlusive_rating=occlusive,
                    barrier_support=barrier, mechanism_notes=notes,
                ))

        await db.commit()
    print(f"Seeded {len(MODEL_VERSIONS)} model versions and {len(INGREDIENT_SEED)} ingredient profiles.")


if __name__ == "__main__":
    asyncio.run(seed())
