"""
Scan routes - contract defined now, real face_pipeline.py implementation in
Phase 2. The FaceScan model, image storage field, and validation thresholds
already exist (db/models/scans.py, core/config.py MIN_FACE_CONFIDENCE /
MIN_IMAGE_QUALITY_SCORE) so Phase 2 only has to add the inference call and
the validation_service check, not redesign anything here.
"""
import uuid

from fastapi import APIRouter

from app.api.deps import CurrentUser, DbSession
from app.core.errors import NotImplementedYetError

router = APIRouter(prefix="/scans", tags=["scans"])

_PHASE_2_NOTE = "Real image-analysis pipeline (ml/face_pipeline.py) ships in Phase 2. The data model, validation thresholds, and storage contract are already in place."


@router.post("")
async def create_scan(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("")
async def list_scans(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("/{scan_id}")
async def get_scan(scan_id: uuid.UUID, db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.post("/{scan_id}/analyze")
async def analyze_scan(scan_id: uuid.UUID, db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)
