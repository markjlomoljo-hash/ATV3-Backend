"""DermVault evidence routes - contract defined now, real evidence_service.py
/ rag_service.py (semantic search over EvidenceSource.embedding via pgvector,
seeded from real literature) ships in Phase 2."""
import uuid

from fastapi import APIRouter, Query

from app.api.deps import CurrentUser, DbSession
from app.core.errors import NotImplementedYetError

router = APIRouter(prefix="/evidence", tags=["evidence"])

_PHASE_2_NOTE = "Real evidence retrieval (evidence_service.py / rag_service.py) ships in Phase 2. EvidenceSource already has a pgvector embedding column for semantic search, replacing v2's hardcoded reference array."


@router.get("/search")
async def search_evidence(db: DbSession, current_user: CurrentUser, q: str = Query(...)):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("/{evidence_id}")
async def get_evidence(evidence_id: uuid.UUID, db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)
