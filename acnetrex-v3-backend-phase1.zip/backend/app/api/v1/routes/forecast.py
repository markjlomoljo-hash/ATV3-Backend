"""Forecast/health-index routes - contract defined now, real
forecast_pipeline.py ships in Phase 2. The CHI formula itself (ZW in the
recovered bundle) is preserved verbatim in intelligence_service.py so health
index history stays continuous across the upgrade even before forecasting
goes live."""
from fastapi import APIRouter

from app.api.deps import CurrentUser, DbSession
from app.core.errors import NotImplementedYetError

router = APIRouter(tags=["forecast"])

_PHASE_2_NOTE = "Real forecasting pipeline (ml/forecast_pipeline.py) with confidence intervals and model versioning ships in Phase 2, gated on FORECAST_MIN_DAYS_REQUIRED days of real log history per validation_service rules."


@router.get("/health-index/latest")
async def health_index_latest(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("/health-index/history")
async def health_index_history(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.post("/forecast")
async def create_forecast(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.post("/what-if")
async def what_if(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)
