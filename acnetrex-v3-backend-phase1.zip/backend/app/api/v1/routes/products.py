"""Product/ingredient routes - contract defined now, real product_pipeline.py
(OCR parsing + IngredientProfile cross-reference + evidence linking) ships
in Phase 2. ProductScan/ProductIngredientResult/IngredientProfile models
already exist (db/models/products.py)."""
import uuid

from fastapi import APIRouter

from app.api.deps import CurrentUser, DbSession
from app.core.errors import NotImplementedYetError

router = APIRouter(prefix="/products", tags=["products"])

_PHASE_2_NOTE = "Real ingredient analysis pipeline (ml/product_pipeline.py) ships in Phase 2. The IngredientProfile reference table replaces v2's hardcoded dictionary; this endpoint will query it instead of returning canned data."


@router.post("/analyze")
async def analyze_product(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.post("")
async def save_product(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("")
async def list_products(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.patch("/{product_id}")
async def patch_product(product_id: uuid.UUID, db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)
