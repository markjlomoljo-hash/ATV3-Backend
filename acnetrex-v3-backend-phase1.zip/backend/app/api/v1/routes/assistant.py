"""CutisAI conversation routes - contract defined now, real
assistant_service.py (Anthropic API call + RAG retrieval + self-check pass)
ships in Phase 2. AssistantConversation/AssistantMessage models already
exist and capture confidence, evidence_source_ids, and self_check_passed so
the real implementation has somewhere to write that data from day one."""
import uuid

from fastapi import APIRouter

from app.api.deps import CurrentUser, DbSession
from app.core.errors import NotImplementedYetError

router = APIRouter(prefix="/assistant", tags=["assistant"])

_PHASE_2_NOTE = "Real CutisAI backend (assistant_service.py: user-context retrieval + evidence RAG + Anthropic API call + structured self-check pass) ships in Phase 2."


@router.post("/conversations")
async def create_conversation(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("/conversations")
async def list_conversations(db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.get("/conversations/{conversation_id}")
async def get_conversation(conversation_id: uuid.UUID, db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)


@router.post("/conversations/{conversation_id}/messages")
async def post_message(conversation_id: uuid.UUID, db: DbSession, current_user: CurrentUser):
    raise NotImplementedYetError(_PHASE_2_NOTE)
