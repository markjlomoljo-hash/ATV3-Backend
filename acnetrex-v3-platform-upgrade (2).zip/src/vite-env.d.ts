/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_AI_ENDPOINT?: string;
  readonly VITE_AI_API_KEY?: string;
  readonly VITE_WEATHER_ENDPOINT?: string;
  readonly VITE_WEATHER_API_KEY?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}