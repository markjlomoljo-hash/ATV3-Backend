import { useEffect, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { getSession } from './lib/api/session';
import { migrateLegacyIfPresent, hasLegacyData } from './lib/api/migration';
import AuthPage from './features/auth/AuthPage';
import OnboardingPage from './features/onboarding/OnboardingPage';
import DashboardPage from './features/dashboard/DashboardPage';
import FaceAtlasPage from './features/scans/FaceAtlasPage';
import ForecastPage from './features/forecast/ForecastPage';
import AssistantPage from './features/assistant/AssistantPage';
import ProductsPage from './features/products/ProductsPage';
import ResearchPage from './features/research/ResearchPage';
import IntelligencePage from './features/intelligence/IntelligencePage';
import ReportsPage from './features/reports/ReportsPage';
import ProfilePage from './features/profile/ProfilePage';
import {
  TriggersPage,
  BarrierPage,
  SkinTwinPage,
  SleepPage,
  DietPage,
  ActivityPage,
  CyclePage,
  ContactPage,
  ClimatePage,
} from './features/insights/InsightsPages';
import {
  SleepLogPage,
  FoodLogPage,
  StressLogPage,
  ActivityLogPage,
  HydrationLogPage,
  CycleLogPage,
  ContactLogPage,
  TreatmentLogPage,
  RoutineLogPage,
  SymptomsLogPage,
  SunscreenLogPage,
  CleansingLogPage,
  ExfoliationLogPage,
  MakeupLogPage,
  HyperpigmentationLogPage,
} from './features/logs/LogPages';
import { BottomNav } from './components/shared/BottomNav';
import { OnboardingProfileEntity } from './lib/api/entityDefs';

function Protected({ children }: { children: React.ReactNode }) {
  const loc = useLocation();
  const [ready, setReady] = useState(false);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  useEffect(() => {
    (async () => {
      const s = getSession();
      if (!s) {
        setNeedsOnboarding(false);
        setReady(true);
        return;
      }
      if (hasLegacyData()) {
        await migrateLegacyIfPresent();
      }
      const profiles = await OnboardingProfileEntity.list({ limit: 1 });
      const completed = profiles.records.some((p) => p.completed === true);
      setNeedsOnboarding(!completed && loc.pathname !== '/onboarding');
      setReady(true);
    })();
  }, [loc.pathname]);

  if (!ready) return null;

  if (!getSession()) {
    return <Navigate to="/auth" replace />;
  }
  if (needsOnboarding && loc.pathname !== '/onboarding') {
    return <Navigate to="/onboarding" replace />;
  }
  return <>{children}</>;
}

function PublicOnly({ children }: { children: React.ReactNode }) {
  if (getSession()) return <Navigate to="/" replace />;
  return <>{children}</>;
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <>
      {children}
      <BottomNav />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/auth"
          element={
            <PublicOnly>
              <AuthPage />
            </PublicOnly>
          }
        />
        <Route
          path="/onboarding"
          element={
            <Protected>
              <OnboardingPage />
            </Protected>
          }
        />
        <Route
          path="/"
          element={
            <Protected>
              <Shell>
                <DashboardPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/intelligence"
          element={
            <Protected>
              <Shell>
                <IntelligencePage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/face-atlas"
          element={
            <Protected>
              <Shell>
                <FaceAtlasPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/forecast"
          element={
            <Protected>
              <Shell>
                <ForecastPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/ai"
          element={
            <Protected>
              <Shell>
                <AssistantPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/products"
          element={
            <Protected>
              <Shell>
                <ProductsPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/research"
          element={
            <Protected>
              <Shell>
                <ResearchPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/triggers"
          element={
            <Protected>
              <Shell>
                <TriggersPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/barrier"
          element={
            <Protected>
              <Shell>
                <BarrierPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/skin-twin"
          element={
            <Protected>
              <Shell>
                <SkinTwinPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/sleep"
          element={
            <Protected>
              <Shell>
                <SleepPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/diet"
          element={
            <Protected>
              <Shell>
                <DietPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/activity"
          element={
            <Protected>
              <Shell>
                <ActivityPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/cycle"
          element={
            <Protected>
              <Shell>
                <CyclePage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/contact"
          element={
            <Protected>
              <Shell>
                <ContactPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/climate"
          element={
            <Protected>
              <Shell>
                <ClimatePage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/reports"
          element={
            <Protected>
              <Shell>
                <ReportsPage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/profile"
          element={
            <Protected>
              <Shell>
                <ProfilePage />
              </Shell>
            </Protected>
          }
        />
        <Route
          path="/log/sleep"
          element={
            <Protected>
              <SleepLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/food"
          element={
            <Protected>
              <FoodLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/stress"
          element={
            <Protected>
              <StressLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/activity"
          element={
            <Protected>
              <ActivityLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/hydration"
          element={
            <Protected>
              <HydrationLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/cycle"
          element={
            <Protected>
              <CycleLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/contact"
          element={
            <Protected>
              <ContactLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/treatment"
          element={
            <Protected>
              <TreatmentLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/routine"
          element={
            <Protected>
              <RoutineLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/symptoms"
          element={
            <Protected>
              <SymptomsLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/sunscreen"
          element={
            <Protected>
              <SunscreenLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/cleansing"
          element={
            <Protected>
              <CleansingLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/exfoliation"
          element={
            <Protected>
              <ExfoliationLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/makeup"
          element={
            <Protected>
              <MakeupLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/pih"
          element={
            <Protected>
              <HyperpigmentationLogPage />
            </Protected>
          }
        />
        <Route
          path="/log/face"
          element={
            <Protected>
              <FaceAtlasPage />
            </Protected>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}