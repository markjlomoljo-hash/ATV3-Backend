// DermVault research page.

import { useEffect, useRef, useState } from 'react';
import { Search, Bookmark, ExternalLink, Sparkles } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, ErrorState } from '../../components/shared/EmptyState';
import { searchEvidence } from '../../lib/ai/retrieval';
import { EvidenceBookmarkEntity } from '../../lib/api/entityDefs';
import { LIMITS } from '../../lib/constants/dataThresholds';

interface Evidence {
  id: string;
  title: string;
  journal?: string;
  year?: number;
  abstract?: string;
  url?: string;
  topic: string;
  sourceTrust: string;
}

export default function ResearchPage() {
  const [query, setQuery] = useState('');
  const [topic, setTopic] = useState('acne');
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [list, setList] = useState<Evidence[]>([]);
  const submittingRef = useRef(false);

  useEffect(() => {
    (async () => {
      const r = await EvidenceBookmarkEntity.list({ limit: LIMITS.EVIDENCE_BOOKMARK });
      setList(
        r.records.map((rec) => ({
          id: rec.id as string,
          title: rec.title as string,
          journal: rec.journal as string | undefined,
          year: rec.year as number | undefined,
          abstract: rec.abstract as string | undefined,
          url: rec.url as string | undefined,
          topic: rec.topic as string,
          sourceTrust: rec.sourceTrust as string,
        }))
      );
    })();
  }, []);

  async function run() {
    if (submittingRef.current) return;
    if (!query.trim()) return;
    submittingRef.current = true;
    setRunning(true);
    setError(null);
    try {
      await searchEvidence(query.trim(), topic);
      const r = await EvidenceBookmarkEntity.list({ limit: LIMITS.EVIDENCE_BOOKMARK });
      setList(
        r.records.map((rec) => ({
          id: rec.id as string,
          title: rec.title as string,
          journal: rec.journal as string | undefined,
          year: rec.year as number | undefined,
          abstract: rec.abstract as string | undefined,
          url: rec.url as string | undefined,
          topic: rec.topic as string,
          sourceTrust: rec.sourceTrust as string,
        }))
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Search failed.');
    } finally {
      submittingRef.current = false;
      setRunning(false);
    }
  }

  async function bookmark(id: string) {
    // Already saved on search; for manual toggle we could toggle a flag.
    // We keep it explicit and avoid mutating sourceTrust silently.
    void id;
  }

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="DermVault" />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <Bookmark className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-ink-900">In-app research vault</h2>
              <p className="text-xs text-ink-500">Live retrieval across peer-reviewed dermatology sources.</p>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search evidence (e.g. niacinamide for acne)"
              className="touch flex-1 rounded-2xl border border-surface-soft bg-white px-3 text-sm focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
              onKeyDown={(e) => e.key === 'Enter' && run()}
            />
            <input
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="topic"
              className="touch w-24 rounded-2xl border border-surface-soft bg-white px-3 text-sm"
            />
            <button
              onClick={run}
              disabled={running}
              className="touch flex items-center justify-center gap-1 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-60"
            >
              <Search className="h-4 w-4" />
            </button>
          </div>
          {error && <ErrorState description={error} onRetry={run} />}
        </div>

        {list.length === 0 ? (
          <EmptyState
            icon={Sparkles}
            title="Search DermVault"
            description="Try queries like 'retinoids for acne', 'barrier ceramides', or 'glycemic load inflammation'."
          />
        ) : (
          <ul className="space-y-2">
            {list.map((e) => (
              <li key={e.id} className="card-soft p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-ink-900">{e.title}</p>
                    <p className="text-xs text-ink-500">
                      {e.journal ?? 'Unknown'} {e.year ? `· ${e.year}` : ''} · {e.sourceTrust.replace('_', ' ')}
                    </p>
                  </div>
                  {e.url && (
                    <a
                      href={e.url}
                      target="_blank"
                      rel="noreferrer"
                      className="touch flex h-11 w-11 items-center justify-center rounded-full text-primary-700 hover:bg-primary-50"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                </div>
                {e.abstract && <p className="mt-2 line-clamp-3 text-xs text-ink-500">{e.abstract}</p>}
                <button
                  onClick={() => bookmark(e.id)}
                  className="mt-3 inline-flex items-center gap-1 rounded-full bg-surface-soft px-3 py-1.5 text-xs font-medium text-ink-700"
                >
                  <Bookmark className="h-3 w-3" /> Saved
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}