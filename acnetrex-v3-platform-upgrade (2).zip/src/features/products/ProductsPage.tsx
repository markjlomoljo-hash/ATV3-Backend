// FormulaLens — product ingestion and analysis page.

import { useEffect, useRef, useState } from 'react';
import { Sparkles, Camera, Trash2 } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, ErrorState } from '../../components/shared/EmptyState';
import { analyzeProduct } from '../../lib/ai/product';
import { ProductScanEntity } from '../../lib/api/entityDefs';
import { LIMITS } from '../../lib/constants/dataThresholds';
import { cn } from '../../utils/cn';
import { useDropzone } from 'react-dropzone';

export default function ProductsPage() {
  const [list, setList] = useState<Awaited<ReturnType<typeof ProductScanEntity.list>>['records']>([]);
  const [brand, setBrand] = useState('');
  const [productName, setProductName] = useState('');
  const [ingredientsText, setIngredientsText] = useState('');
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submittingRef = useRef(false);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { 'image/*': [] },
    maxFiles: 1,
    onDrop: async (files) => {
      const f = files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => setImageDataUrl(typeof reader.result === 'string' ? reader.result : null);
      reader.readAsDataURL(f);
    },
  });

  useEffect(() => {
    (async () => {
      const r = await ProductScanEntity.list({ limit: LIMITS.DAILY_LOG });
      setList(r.records);
    })();
  }, []);

  async function run() {
    if (submittingRef.current) return;
    if (!brand || !productName || (!ingredientsText && !imageDataUrl)) {
      setError('Brand, product name, and at least ingredients text or image are required.');
      return;
    }
    submittingRef.current = true;
    setAnalyzing(true);
    setError(null);
    try {
      await analyzeProduct({ brand, productName, ingredientsText, imageUrl: imageDataUrl ?? undefined });
      const r = await ProductScanEntity.list({ limit: LIMITS.DAILY_LOG });
      setList(r.records);
      setBrand('');
      setProductName('');
      setIngredientsText('');
      setImageDataUrl(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Analysis failed.');
    } finally {
      submittingRef.current = false;
      setAnalyzing(false);
    }
  }

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="FormulaLens" />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-ink-900">Analyze a product</h2>
              <p className="text-xs text-ink-500">Enter brand + product, paste ingredients, or upload a label photo.</p>
            </div>
          </div>

          <div className="mt-4 space-y-3">
            <Input label="Brand" value={brand} onChange={setBrand} placeholder="e.g. CeraVe" />
            <Input label="Product name" value={productName} onChange={setProductName} placeholder="e.g. Hydrating Cleanser" />
            <Textarea
              label="Ingredients"
              value={ingredientsText}
              onChange={setIngredientsText}
              placeholder="Paste the ingredient list (INCI) here."
            />
            <div
              {...getRootProps()}
              className={cn(
                'flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed p-5 text-center text-sm transition',
                isDragActive ? 'border-primary-400 bg-primary-50' : 'border-surface-soft text-ink-500'
              )}
            >
              <input {...getInputProps()} />
              <Camera className="h-5 w-5 text-primary-500" />
              {imageDataUrl ? (
                <div className="flex w-full items-center gap-2">
                  <img src={imageDataUrl} alt="label" className="h-16 w-16 rounded-lg object-cover" />
                  <span className="text-xs text-ink-700">Photo attached</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setImageDataUrl(null);
                    }}
                    className="ml-auto rounded-full p-1 text-flare-600 hover:bg-flare-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <p>Drop a label photo here, or tap to upload.</p>
              )}
            </div>
            {error && <p className="rounded-lg bg-flare-50 px-3 py-2 text-xs text-flare-600">{error}</p>}
            <button
              onClick={run}
              disabled={analyzing}
              className="touch flex w-full items-center justify-center gap-2 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-60"
            >
              <Sparkles className="h-4 w-4" />
              {analyzing ? 'Analyzing…' : 'Analyze'}
            </button>
          </div>
        </div>

        {error && <ErrorState description={error} onRetry={run} />}

        {list.length === 0 ? (
          <EmptyState
            icon={Sparkles}
            title="No products analyzed yet"
            description="Add a product above to see its ingredient risk and verdict."
          />
        ) : (
          <ul className="space-y-2">
            {list.map((p) => (
              <li key={p.id} className="card-soft p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-ink-900">
                      {p.brand} — {p.productName}
                    </p>
                    <p className="text-xs text-ink-500">conf {Math.round((p.confidence as number) * 100)}%</p>
                  </div>
                  <span
                    className={cn(
                      'rounded-full px-3 py-1 text-xs font-semibold',
                      p.verdict === 'favorable' && 'bg-success-50 text-success-600',
                      p.verdict === 'caution' && 'bg-flare-50 text-flare-600',
                      p.verdict === 'avoid' && 'bg-flare-50 text-flare-600',
                      p.verdict === 'insufficient_data' && 'bg-surface-soft text-ink-500'
                    )}
                  >
                    {p.verdict}
                  </span>
                </div>
                {p.rationale && <p className="mt-2 text-xs text-ink-500">{String(p.rationale)}</p>}
                <div className="mt-3 grid grid-cols-5 gap-2 text-center text-[10px]">
                  <Risk label="Comedo" value={Number(p.comedogenicRisk ?? 0)} />
                  <Risk label="Irritant" value={Number(p.irritantRisk ?? 0)} />
                  <Risk label="Hormonal" value={Number(p.hormonalRisk ?? 0)} />
                  <Risk label="Occlusive" value={Number(p.occlusiveRisk ?? 0)} />
                  <Risk label="Barrier" value={Number(p.barrierRisk ?? 0)} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function Input({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block text-xs font-medium text-ink-500">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="touch w-full rounded-2xl border border-surface-soft bg-white px-3 text-sm focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
      />
    </label>
  );
}

function Textarea({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block text-xs font-medium text-ink-500">{label}</span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={4}
        className="w-full rounded-2xl border border-surface-soft bg-white px-3 py-2 text-sm focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
      />
    </label>
  );
}

function Risk({ label, value }: { label: string; value: number }) {
  const pct = Math.round(value * 100);
  return (
    <div className="rounded-lg bg-surface-soft p-2">
      <div className="text-[10px] uppercase tracking-wide text-ink-400">{label}</div>
      <div className={`mt-0.5 text-sm font-semibold ${pct >= 50 ? 'text-flare-600' : pct >= 25 ? 'text-ink-700' : 'text-success-600'}`}>
        {pct}
      </div>
    </div>
  );
}