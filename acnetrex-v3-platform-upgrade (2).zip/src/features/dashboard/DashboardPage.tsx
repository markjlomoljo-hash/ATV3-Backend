// Dashboard (Home) page.
// Real summary metrics derived from persisted logs and analytics modules.

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  Brain,
  Calendar,
  ChevronRight,
  Droplets,
  Flame,
  Moon,
  Sparkles,
  Sun,
  TrendingUp,
} from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { AIStatusStrip } from '../../components/shared/Status';
import { EmptyState, InsufficientDataState } from '../../components/shared/EmptyState';
import { computeCutisHealthIndex, computeForecastTrend } from '../../lib/analytics';
import { getCoreStatus } from '../../lib/ai/intelligenceCore';
import { getTaskState } from '../../features/intelligence/tasks';
import {
  SleepLogEntity,
  HydrationLogEntity,
  SymptomLogEntity,
  StressLogEntity,
} from '../../lib/api/entityDefs';
import { format, subDays } from 'date-fns';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { getSession } from '../../lib/api/session';

export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [chi, setChi] = useState<Awaited<ReturnType<typeof computeCutisHealthIndex>> | null>(null);
  const [trend, setTrend] = useState<Awaited<ReturnType<typeof computeForecastTrend>>>([]);
  const [core, setCore] = useState<Awaited<ReturnType<typeof getCoreStatus>> | null>(null);
  const [taskState, setTaskState] = useState<Awaited<ReturnType<typeof getTaskState>> | null>(null);
  const [today, setToday] = useState<{
    sleepHours: number | null;
    hydration: number | null;
    stress: number | null;
    inflammation: number | null;
  }>({ sleepHours: null, hydration: null, stress: null, inflammation: null });

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const session = getSession();
        if (!session) return;
        const todayISO = new Date().toISOString().slice(0, 10);
        const [chiResult, trendResult, coreResult, taskResult, sleep, hydration, stress, symptoms] =
          await Promise.all([
            computeCutisHealthIndex(),
            computeForecastTrend(),
            getCoreStatus(),
            getTaskState(),
            SleepLogEntity.filter((r) => (r.logDate as string) === todayISO, { limit: 1 }),
            HydrationLogEntity.filter((r) => (r.logDate as string) === todayISO, { limit: 1 }),
            StressLogEntity.filter((r) => (r.logDate as string) === todayISO, { limit: 1 }),
            SymptomLogEntity.filter((r) => (r.logDate as string) === todayISO, { limit: 1 }),
          ]);
        if (!active) return;
        setChi(chiResult);
        setTrend(trendResult);
        setCore(coreResult);
        setTaskState(taskResult);
        setToday({
          sleepHours: sleep.records[0] ? (sleep.records[0].hours as number) : null,
          hydration: hydration.records[0] ? (hydration.records[0].waterLiters as number) : null,
          stress: stress.records[0] ? (stress.records[0].level as number) : null,
          inflammation: symptoms.records[0]
            ? ((symptoms.records[0].inflammation as number) ?? null)
            : null,
        });
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="AcneTrex" back={false} />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-soft gradient-hero p-5"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-500">
                {format(new Date(), 'EEEE, MMM d')}
              </p>
              <h2 className="text-xl font-bold text-ink-900">Good day, traveler.</h2>
            </div>
          </div>
          <p className="mt-3 text-sm text-ink-700">
            Each action you take strengthens your personal model. Here is where you stand today.
          </p>
        </motion.div>

        <AIStatusStrip />

        {loading ? (
          <Skeleton />
        ) : (
          <>
            {chi && !chi.sufficient ? (
              <InsufficientDataState
                moduleName="Cutis Health Index"
                requiredDataPoints={chi.minRequired}
                currentDataPoints={chi.dataPoints}
                ctaLabel="Log today"
                ctaRoute="/log/sleep"
              />
            ) : chi ? (
              <CHIWidget chi={chi} />
            ) : null}

            <QuickLogGrid today={today} />

            <ForecastTrendChart data={trend} />

            {core && (
              <div className="card-soft p-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-ink-900">Intelligence Core</h3>
                  <Brain className="h-4 w-4 text-primary-500" />
                </div>
                <p className="mt-1 text-xs text-ink-500">
                  Real-time signals from your private engine.
                </p>
                <ul className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
                  <Stat label="Inferences 24h" value={String(core.inferenceCount24h)} />
                  <Stat label="Retrievals 24h" value={String(core.evidenceRetrievals24h)} />
                  <Stat label="Active users" value={String(core.activeUsers)} />
                </ul>
              </div>
            )}

            {taskState && <TaskWidget state={taskState} />}
          </>
        )}
      </div>
    </div>
  );
}

function CHIWidget({ chi }: { chi: NonNullable<Awaited<ReturnType<typeof computeCutisHealthIndex>>> }) {
  const pct = Math.round(chi.score * 100);
  const trendLabel = chi.trend === 'up' ? 'Improving' : chi.trend === 'down' ? 'Declining' : 'Stable';
  const trendColor =
    chi.trend === 'up'
      ? 'text-success-600 bg-success-50'
      : chi.trend === 'down'
      ? 'text-flare-600 bg-flare-50'
      : 'text-ink-500 bg-surface-soft';
  return (
    <div className="card-soft p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">
            Cutis Health Index
          </p>
          <p className="mt-1 text-3xl font-bold text-ink-900">{pct}</p>
        </div>
        <div className={`rounded-full px-3 py-1 text-xs font-semibold ${trendColor}`}>
          {trendLabel}
        </div>
      </div>
      <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-surface-soft">
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary-500 to-accent-400"
          style={{ width: `${pct}%` }}
        />
      </div>
      {chi.contributors.length > 0 && (
        <p className="mt-3 text-xs text-ink-500">
          Drivers: <span className="text-ink-700">{chi.contributors.join(' · ')}</span>
        </p>
      )}
    </div>
  );
}

function QuickLogGrid({
  today,
}: {
  today: { sleepHours: number | null; hydration: number | null; stress: number | null; inflammation: number | null };
}) {
  const cells = [
    { to: '/log/sleep', label: 'Sleep', icon: Moon, value: today.sleepHours !== null ? `${today.sleepHours}h` : '—' },
    { to: '/log/hydration', label: 'Hydration', icon: Droplets, value: today.hydration !== null ? `${today.hydration}L` : '—' },
    { to: '/log/stress', label: 'Stress', icon: Activity, value: today.stress !== null ? `${today.stress}/10` : '—' },
    { to: '/log/symptoms', label: 'Symptoms', icon: Flame, value: today.inflammation !== null ? `${today.inflammation}/10` : '—' },
    { to: '/log/food', label: 'Diet', icon: Sun, value: 'log' },
    { to: '/log/activity', label: 'Activity', icon: TrendingUp, value: 'log' },
  ];
  return (
    <div className="grid grid-cols-3 gap-2">
      {cells.map((c) => (
        <Link
          key={c.to}
          to={c.to}
          className="card-soft flex flex-col items-center justify-center gap-1 p-3 text-center transition hover:bg-surface-soft"
        >
          <c.icon className="h-5 w-5 text-primary-500" />
          <p className="text-xs font-semibold text-ink-900">{c.label}</p>
          <p className="text-[10px] text-ink-500">{c.value}</p>
        </Link>
      ))}
    </div>
  );
}

function ForecastTrendChart({ data }: { data: { date: string; inflammation: number | null }[] }) {
  const points = data
    .filter((d) => d.inflammation !== null)
    .map((d) => ({ date: format(subDays(new Date(d.date), 0), 'MMM d'), value: d.inflammation ?? 0 }));
  if (points.length === 0) {
    return (
      <EmptyState
        icon={Calendar}
        title="No trend yet"
        description="Once you log symptoms or run face scans, your trend will appear here."
        ctaLabel="Log symptoms"
        ctaRoute="/log/symptoms"
      />
    );
  }
  return (
    <div className="card-soft p-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-ink-900">Inflammation trend (30 days)</h3>
        <Link to="/forecast" className="text-xs font-medium text-primary-700 hover:underline">
          Forecast <ChevronRight className="inline h-3 w-3" />
        </Link>
      </div>
      <div className="mt-3 h-32">
        <ResponsiveContainer>
          <LineChart data={points}>
            <XAxis dataKey="date" tickLine={false} axisLine={false} fontSize={10} />
            <YAxis tickLine={false} axisLine={false} fontSize={10} domain={[0, 1]} />
            <Tooltip />
            <Line type="monotone" dataKey="value" stroke="#7c6ee6" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function TaskWidget({ state }: { state: NonNullable<Awaited<ReturnType<typeof getTaskState>>> }) {
  const tasks = [
    { key: 'sleep_log', label: 'Sleep' },
    { key: 'hydration', label: 'Hydration' },
    { key: 'stress_log', label: 'Stress' },
    { key: 'symptom_log', label: 'Symptoms' },
    { key: 'food_log', label: 'Diet' },
    { key: 'face_scan', label: 'Face scan' },
  ];
  const completedToday = tasks.filter((t) => state.perTask[t.key]?.completedToday).length;
  return (
    <div className="card-soft p-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-ink-900">Daily tasks</h3>
        <Link to="/intelligence" className="text-xs font-medium text-primary-700 hover:underline">
          Intel <ChevronRight className="inline h-3 w-3" />
        </Link>
      </div>
      <p className="mt-1 text-xs text-ink-500">
        {completedToday} / {tasks.length} done · {state.totalPoints} pts · {state.totalStreak}-streak
      </p>
      <ul className="mt-3 grid grid-cols-3 gap-2 text-xs">
        {tasks.map((t) => {
          const done = state.perTask[t.key]?.completedToday;
          return (
            <li
              key={t.key}
              className={`flex items-center gap-2 rounded-lg px-2 py-1.5 ${done ? 'bg-success-50 text-success-600' : 'bg-surface-soft text-ink-500'}`}
            >
              <span className={`h-2 w-2 rounded-full ${done ? 'bg-success-500' : 'bg-ink-300'}`} />
              {t.label}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <li className="rounded-xl bg-surface-soft p-2">
      <div className="text-[10px] uppercase tracking-wide text-ink-400">{label}</div>
      <div className="mt-0.5 text-base font-semibold text-ink-900">{value}</div>
    </li>
  );
}

function Skeleton() {
  return (
    <div className="card-soft animate-pulse p-6 text-sm text-ink-400">Loading your dashboard…</div>
  );
}