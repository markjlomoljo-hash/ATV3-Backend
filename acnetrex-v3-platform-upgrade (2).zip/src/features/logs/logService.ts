// Daily log services with same-day merge.
// Every "log X" call writes/updates the same-day record.

import { format } from 'date-fns';
import {
  SleepLogEntity,
  FoodLogEntity,
  StressLogEntity,
  ActivityLogEntity,
  HydrationLogEntity,
  CycleLogEntity,
  ContactLogEntity,
  TreatmentLogEntity,
  RoutineLogEntity,
  SymptomLogEntity,
  SunscreenLogEntity,
  CleansingLogEntity,
  ExfoliationLogEntity,
  MakeupLogEntity,
  HyperpigmentationLogEntity,
} from '../../lib/api/entityDefs';
import { getSession } from '../../lib/api/session';
import { db, type BaaSRecord } from '../../lib/storage/db';

type LogStoreName =
  | 'SleepLog'
  | 'FoodLog'
  | 'StressLog'
  | 'ActivityLog'
  | 'HydrationLog'
  | 'CycleLog'
  | 'ContactLog'
  | 'TreatmentLog'
  | 'RoutineLog'
  | 'SymptomLog'
  | 'SunscreenLog'
  | 'CleansingLog'
  | 'ExfoliationLog'
  | 'MakeupLog'
  | 'HyperpigmentationLog';

interface EntityApi<T> {
  create: (input: Record<string, unknown>) => Promise<T>;
  update: (id: string, input: Record<string, unknown>) => Promise<T>;
}

async function findToday(store: LogStoreName): Promise<BaaSRecord | null> {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');
  const today = format(new Date(), 'yyyy-MM-dd');
  const rows = await db.list(store, { limit: 9999 });
  const match = rows.find(
    (r) => (r.logDate as string) === today && (r.created_by_id as string) === session.userId
  );
  return match ?? null;
}

async function upsertToday<T>(
  store: LogStoreName,
  fields: Record<string, unknown>,
  api: EntityApi<T>
): Promise<T> {
  const today = format(new Date(), 'yyyy-MM-dd');
  const existing = await findToday(store);
  if (existing) {
    return api.update(existing.id as string, fields);
  }
  return api.create({ ...fields, logDate: today });
}

export const logsService = {
  async saveSleep(fields: { hours: number; quality?: number; notes?: string }) {
    return upsertToday('SleepLog', fields, {
      create: SleepLogEntity.create,
      update: SleepLogEntity.update,
    });
  },
  async saveFood(fields: {
    glycemicLoad?: 'low' | 'medium' | 'high';
    dairyLevel?: 'none' | 'low' | 'medium' | 'high';
    wheyLevel?: 'none' | 'low' | 'medium' | 'high';
    sugarLevel?: 'none' | 'low' | 'medium' | 'high';
    omega3?: boolean;
    vegetables?: boolean;
    processed?: boolean;
    notes?: string;
  }) {
    return upsertToday('FoodLog', fields, {
      create: FoodLogEntity.create,
      update: FoodLogEntity.update,
    });
  },
  async saveStress(fields: { level: number; triggers?: string[]; notes?: string }) {
    return upsertToday('StressLog', fields, {
      create: StressLogEntity.create,
      update: StressLogEntity.update,
    });
  },
  async saveActivity(fields: {
    sweatLevel?: 'none' | 'low' | 'medium' | 'high';
    durationMinutes?: number;
    type?: string;
    notes?: string;
  }) {
    return upsertToday('ActivityLog', fields, {
      create: ActivityLogEntity.create,
      update: ActivityLogEntity.update,
    });
  },
  async saveHydration(fields: { waterLiters: number; notes?: string }) {
    return upsertToday('HydrationLog', fields, {
      create: HydrationLogEntity.create,
      update: HydrationLogEntity.update,
    });
  },
  async saveCycle(fields: { phase: 'menstrual' | 'follicular' | 'ovulatory' | 'luteal'; day?: number; notes?: string }) {
    return upsertToday('CycleLog', fields, {
      create: CycleLogEntity.create,
      update: CycleLogEntity.update,
    });
  },
  async saveContact(fields: {
    helmet?: boolean;
    mask?: boolean;
    phone?: boolean;
    pillowcase?: boolean;
    handsToFace?: boolean;
    notes?: string;
  }) {
    return upsertToday('ContactLog', fields, {
      create: ContactLogEntity.create,
      update: ContactLogEntity.update,
    });
  },
  async saveTreatment(fields: { treatment: string; applied: boolean; notes?: string }) {
    return upsertToday('TreatmentLog', fields, {
      create: TreatmentLogEntity.create,
      update: TreatmentLogEntity.update,
    });
  },
  async saveRoutine(fields: { am?: boolean; pm?: boolean; steps?: string[]; notes?: string }) {
    return upsertToday('RoutineLog', fields, {
      create: RoutineLogEntity.create,
      update: RoutineLogEntity.update,
    });
  },
  async saveSymptoms(fields: {
    inflammation?: number;
    oiliness?: number;
    dryness?: number;
    redness?: number;
    lesions?: number;
    notes?: string;
  }) {
    return upsertToday('SymptomLog', fields, {
      create: SymptomLogEntity.create,
      update: SymptomLogEntity.update,
    });
  },
  async saveSunscreen(fields: { applied: boolean; spf?: number; reapplied?: boolean; notes?: string }) {
    return upsertToday('SunscreenLog', fields, {
      create: SunscreenLogEntity.create,
      update: SunscreenLogEntity.update,
    });
  },
  async saveCleansing(fields: { times: number; cleanserType?: string; notes?: string }) {
    return upsertToday('CleansingLog', fields, {
      create: CleansingLogEntity.create,
      update: CleansingLogEntity.update,
    });
  },
  async saveExfoliation(fields: { active?: string; strength?: 'mild' | 'medium' | 'strong'; notes?: string }) {
    return upsertToday('ExfoliationLog', fields, {
      create: ExfoliationLogEntity.create,
      update: ExfoliationLogEntity.update,
    });
  },
  async saveMakeup(fields: { foundation?: boolean; nonComedogenic?: boolean; removedAtNight?: boolean; notes?: string }) {
    return upsertToday('MakeupLog', fields, {
      create: MakeupLogEntity.create,
      update: MakeupLogEntity.update,
    });
  },
  async saveHyperpigmentation(fields: { marks?: number; severity?: number; notes?: string }) {
    return upsertToday('HyperpigmentationLog', fields, {
      create: HyperpigmentationLogEntity.create,
      update: HyperpigmentationLogEntity.update,
    });
  },
};

export type { LogStoreName };