// Daily log form pages. Each form persists via same-day merge.

import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar } from '../../components/shared/TopBar';
import { logsService } from './logService';
import { cn } from '../../utils/cn';
import { CheckCircle2 } from 'lucide-react';

type NavigateFn = ReturnType<typeof useNavigate>;

const back = (navigate: NavigateFn) => () => navigate(-1);

export function SleepLogPage() {
  const navigate = useNavigate();
  return <SleepForm title="Log sleep" onSaved={back(navigate)} />;
}

export function FoodLogPage() {
  const navigate = useNavigate();
  return <FoodForm title="Log food" onSaved={back(navigate)} />;
}

export function StressLogPage() {
  const navigate = useNavigate();
  return <StressForm title="Log stress" onSaved={back(navigate)} />;
}

export function ActivityLogPage() {
  const navigate = useNavigate();
  return <ActivityForm title="Log activity" onSaved={back(navigate)} />;
}

export function HydrationLogPage() {
  const navigate = useNavigate();
  return <HydrationForm title="Log hydration" onSaved={back(navigate)} />;
}

export function CycleLogPage() {
  const navigate = useNavigate();
  return <CycleForm title="Log cycle" onSaved={back(navigate)} />;
}

export function ContactLogPage() {
  const navigate = useNavigate();
  return <ContactForm title="Log contact" onSaved={back(navigate)} />;
}

export function TreatmentLogPage() {
  const navigate = useNavigate();
  return <TreatmentForm title="Log treatment" onSaved={back(navigate)} />;
}

export function RoutineLogPage() {
  const navigate = useNavigate();
  return <RoutineForm title="Log routine" onSaved={back(navigate)} />;
}

export function SymptomsLogPage() {
  const navigate = useNavigate();
  return <SymptomsForm title="Log symptoms" onSaved={back(navigate)} />;
}

export function SunscreenLogPage() {
  const navigate = useNavigate();
  return <SunscreenForm title="Log sunscreen" onSaved={back(navigate)} />;
}

export function CleansingLogPage() {
  const navigate = useNavigate();
  return <CleansingForm title="Log cleansing" onSaved={back(navigate)} />;
}

export function ExfoliationLogPage() {
  const navigate = useNavigate();
  return <ExfoliationForm title="Log exfoliation" onSaved={back(navigate)} />;
}

export function MakeupLogPage() {
  const navigate = useNavigate();
  return <MakeupForm title="Log makeup" onSaved={back(navigate)} />;
}

export function HyperpigmentationLogPage() {
  const navigate = useNavigate();
  return <HyperpigmentationForm title="Log PIH marks" onSaved={back(navigate)} />;
}

function FormShell({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title={title} />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">{children}</div>
    </div>
  );
}

function NumberInput({
  label,
  value,
  onChange,
  step = 1,
  min,
  max,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
}) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block text-xs font-medium text-ink-500">{label}</span>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        step={step}
        min={min}
        max={max}
        className="touch w-full rounded-2xl border border-surface-soft bg-white px-3 text-sm focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
      />
    </label>
  );
}

function TextInput({ label, value, onChange, type = 'text' }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block text-xs font-medium text-ink-500">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="touch w-full rounded-2xl border border-surface-soft bg-white px-3 text-sm focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
      />
    </label>
  );
}

function PillGroup<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div>
      <span className="mb-1 block text-xs font-medium text-ink-500">{label}</span>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={cn(
              'rounded-full border px-4 py-2 text-sm font-medium transition',
              value === o.value
                ? 'border-primary-500 bg-primary-500 text-white shadow-sm shadow-primary-200'
                : 'border-surface-soft bg-white text-ink-700 hover:border-primary-300'
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function CheckboxRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 rounded border-ink-300 text-primary-500 focus:ring-primary-500"
      />
      <span className="text-ink-700">{label}</span>
    </label>
  );
}

function SaveButton({ saving }: { saving: boolean }) {
  return (
    <button
      type="submit"
      disabled={saving}
      className="touch w-full rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-60"
    >
      {saving ? 'Saving…' : 'Save'}
    </button>
  );
}

function DoneBanner() {
  return (
    <div className="rounded-2xl bg-success-50 px-3 py-2 text-sm text-success-600">
      <CheckCircle2 className="mr-1 inline h-4 w-4" /> Saved.
    </div>
  );
}

function Slider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block text-sm">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-ink-500">{label}</span>
        <span className="text-xs font-semibold text-ink-900">{value}/10</span>
      </div>
      <input
        type="range"
        min={0}
        max={10}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="touch mt-2 w-full accent-primary-500"
      />
    </label>
  );
}

function useSubmit<T>(service: (fields: T) => Promise<unknown>, onSaved: () => void) {
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submittingRef = useRef(false);

  async function submit(payload: T) {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSaving(true);
    setError(null);
    try {
      await service(payload);
      setDone(true);
      setTimeout(onSaved, 600);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Save failed.');
    } finally {
      submittingRef.current = false;
      setSaving(false);
    }
  }
  return { submit, saving, done, error };
}

function SleepForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ hours: 7.5, quality: 7, notes: '' });
  const { submit, saving, done, error } = useSubmit(logsService.saveSleep, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit({ hours: data.hours, quality: data.quality, notes: data.notes });
        }}
        className="card-soft space-y-3 p-5"
      >
        <NumberInput label="Hours slept" value={data.hours} onChange={(v) => setData({ ...data, hours: v })} step={0.5} min={0} max={24} />
        <NumberInput label="Quality (0–10)" value={data.quality} onChange={(v) => setData({ ...data, quality: v })} step={1} min={0} max={10} />
        <TextInput label="Notes" value={data.notes} onChange={(v) => setData({ ...data, notes: v })} />
        {error && <p className="text-sm text-flare-600">{error}</p>}
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function FoodForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({
    glycemicLoad: 'low' as 'low' | 'medium' | 'high',
    dairyLevel: 'none' as 'none' | 'low' | 'medium' | 'high',
    sugarLevel: 'none' as 'none' | 'low' | 'medium' | 'high',
    omega3: false,
    vegetables: true,
    processed: false,
  });
  const { submit, saving, done } = useSubmit(logsService.saveFood, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <PillGroup
          label="Glycemic load"
          value={data.glycemicLoad}
          onChange={(v) => setData({ ...data, glycemicLoad: v })}
          options={[
            { value: 'low', label: 'Low' },
            { value: 'medium', label: 'Medium' },
            { value: 'high', label: 'High' },
          ]}
        />
        <PillGroup
          label="Dairy"
          value={data.dairyLevel}
          onChange={(v) => setData({ ...data, dairyLevel: v })}
          options={[
            { value: 'none', label: 'None' },
            { value: 'low', label: 'Low' },
            { value: 'medium', label: 'Medium' },
            { value: 'high', label: 'High' },
          ]}
        />
        <PillGroup
          label="Sugar"
          value={data.sugarLevel}
          onChange={(v) => setData({ ...data, sugarLevel: v })}
          options={[
            { value: 'none', label: 'None' },
            { value: 'low', label: 'Low' },
            { value: 'medium', label: 'Medium' },
            { value: 'high', label: 'High' },
          ]}
        />
        <CheckboxRow label="Omega-3 today" checked={data.omega3} onChange={(v) => setData({ ...data, omega3: v })} />
        <CheckboxRow label="Vegetables today" checked={data.vegetables} onChange={(v) => setData({ ...data, vegetables: v })} />
        <CheckboxRow label="Processed foods" checked={data.processed} onChange={(v) => setData({ ...data, processed: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function StressForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ level: 5, triggers: [] as string[], notes: '' });
  const { submit, saving, done, error } = useSubmit(logsService.saveStress, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <NumberInput label="Stress level (0–10)" value={data.level} onChange={(v) => setData({ ...data, level: v })} step={1} min={0} max={10} />
        <TextInput
          label="Triggers (comma separated)"
          value={data.triggers.join(', ')}
          onChange={(v) => setData({ ...data, triggers: v.split(',').map((s) => s.trim()).filter(Boolean) })}
        />
        <TextInput label="Notes" value={data.notes} onChange={(v) => setData({ ...data, notes: v })} />
        {error && <p className="text-sm text-flare-600">{error}</p>}
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function ActivityForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ sweatLevel: 'low' as 'none' | 'low' | 'medium' | 'high', durationMinutes: 30, type: 'walk' });
  const { submit, saving, done } = useSubmit(logsService.saveActivity, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <TextInput label="Type" value={data.type} onChange={(v) => setData({ ...data, type: v })} />
        <NumberInput label="Duration (min)" value={data.durationMinutes} onChange={(v) => setData({ ...data, durationMinutes: v })} step={5} min={0} max={600} />
        <PillGroup
          label="Sweat level"
          value={data.sweatLevel}
          onChange={(v) => setData({ ...data, sweatLevel: v })}
          options={[
            { value: 'none', label: 'None' },
            { value: 'low', label: 'Low' },
            { value: 'medium', label: 'Medium' },
            { value: 'high', label: 'High' },
          ]}
        />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function HydrationForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ waterLiters: 1.5, notes: '' });
  const { submit, saving, done, error } = useSubmit(logsService.saveHydration, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <NumberInput label="Water (L)" value={data.waterLiters} onChange={(v) => setData({ ...data, waterLiters: v })} step={0.25} min={0} max={10} />
        <TextInput label="Notes" value={data.notes} onChange={(v) => setData({ ...data, notes: v })} />
        {error && <p className="text-sm text-flare-600">{error}</p>}
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function CycleForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ phase: 'follicular' as 'menstrual' | 'follicular' | 'ovulatory' | 'luteal', day: 1 });
  const { submit, saving, done } = useSubmit(logsService.saveCycle, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <PillGroup
          label="Phase"
          value={data.phase}
          onChange={(v) => setData({ ...data, phase: v })}
          options={[
            { value: 'menstrual', label: 'Menstrual' },
            { value: 'follicular', label: 'Follicular' },
            { value: 'ovulatory', label: 'Ovulatory' },
            { value: 'luteal', label: 'Luteal' },
          ]}
        />
        <NumberInput label="Cycle day" value={data.day} onChange={(v) => setData({ ...data, day: v })} min={1} max={40} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function ContactForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ helmet: false, mask: false, phone: true, pillowcase: false, handsToFace: false });
  const { submit, saving, done } = useSubmit(logsService.saveContact, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <CheckboxRow label="Helmet" checked={data.helmet} onChange={(v) => setData({ ...data, helmet: v })} />
        <CheckboxRow label="Mask" checked={data.mask} onChange={(v) => setData({ ...data, mask: v })} />
        <CheckboxRow label="Phone on face" checked={data.phone} onChange={(v) => setData({ ...data, phone: v })} />
        <CheckboxRow label="Clean pillowcase" checked={data.pillowcase} onChange={(v) => setData({ ...data, pillowcase: v })} />
        <CheckboxRow label="Hands to face" checked={data.handsToFace} onChange={(v) => setData({ ...data, handsToFace: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function TreatmentForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ treatment: 'Adapalene 0.1%', applied: true });
  const { submit, saving, done } = useSubmit(logsService.saveTreatment, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <TextInput label="Treatment" value={data.treatment} onChange={(v) => setData({ ...data, treatment: v })} />
        <CheckboxRow label="Applied today" checked={data.applied} onChange={(v) => setData({ ...data, applied: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function RoutineForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ am: true, pm: true, steps: ['Cleanser', 'Moisturizer', 'SPF'] as string[] });
  const { submit, saving, done } = useSubmit(logsService.saveRoutine, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <CheckboxRow label="AM completed" checked={data.am} onChange={(v) => setData({ ...data, am: v })} />
        <CheckboxRow label="PM completed" checked={data.pm} onChange={(v) => setData({ ...data, pm: v })} />
        <TextInput
          label="Steps (comma separated)"
          value={data.steps.join(', ')}
          onChange={(v) => setData({ ...data, steps: v.split(',').map((s) => s.trim()).filter(Boolean) })}
        />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function SymptomsForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ inflammation: 3, oiliness: 4, dryness: 2, redness: 3, lesions: 0 });
  const { submit, saving, done } = useSubmit(logsService.saveSymptoms, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <Slider label="Inflammation" value={data.inflammation} onChange={(v) => setData({ ...data, inflammation: v })} />
        <Slider label="Oiliness" value={data.oiliness} onChange={(v) => setData({ ...data, oiliness: v })} />
        <Slider label="Dryness" value={data.dryness} onChange={(v) => setData({ ...data, dryness: v })} />
        <Slider label="Redness" value={data.redness} onChange={(v) => setData({ ...data, redness: v })} />
        <NumberInput label="Lesion count" value={data.lesions} onChange={(v) => setData({ ...data, lesions: v })} min={0} max={200} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function SunscreenForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ applied: true, spf: 50, reapplied: false });
  const { submit, saving, done } = useSubmit(logsService.saveSunscreen, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <CheckboxRow label="Applied today" checked={data.applied} onChange={(v) => setData({ ...data, applied: v })} />
        <NumberInput label="SPF" value={data.spf} onChange={(v) => setData({ ...data, spf: v })} min={0} max={100} />
        <CheckboxRow label="Reapplied" checked={data.reapplied} onChange={(v) => setData({ ...data, reapplied: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function CleansingForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ times: 2, cleanserType: '' });
  const { submit, saving, done } = useSubmit(logsService.saveCleansing, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <NumberInput label="Times today" value={data.times} onChange={(v) => setData({ ...data, times: v })} min={0} max={10} />
        <TextInput label="Cleanser type" value={data.cleanserType} onChange={(v) => setData({ ...data, cleanserType: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function ExfoliationForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ active: '', strength: 'mild' as 'mild' | 'medium' | 'strong' });
  const { submit, saving, done } = useSubmit(logsService.saveExfoliation, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <TextInput label="Active" value={data.active} onChange={(v) => setData({ ...data, active: v })} />
        <PillGroup
          label="Strength"
          value={data.strength}
          onChange={(v) => setData({ ...data, strength: v })}
          options={[
            { value: 'mild', label: 'Mild' },
            { value: 'medium', label: 'Medium' },
            { value: 'strong', label: 'Strong' },
          ]}
        />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function MakeupForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ foundation: true, nonComedogenic: true, removedAtNight: true });
  const { submit, saving, done } = useSubmit(logsService.saveMakeup, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <CheckboxRow label="Foundation" checked={data.foundation} onChange={(v) => setData({ ...data, foundation: v })} />
        <CheckboxRow label="Non-comedogenic" checked={data.nonComedogenic} onChange={(v) => setData({ ...data, nonComedogenic: v })} />
        <CheckboxRow label="Removed at night" checked={data.removedAtNight} onChange={(v) => setData({ ...data, removedAtNight: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}

function HyperpigmentationForm({ title, onSaved }: { title: string; onSaved: () => void }) {
  const [data, setData] = useState({ marks: 0, severity: 0 });
  const { submit, saving, done } = useSubmit(logsService.saveHyperpigmentation, onSaved);
  return (
    <FormShell title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(data);
        }}
        className="card-soft space-y-3 p-5"
      >
        <NumberInput label="Mark count" value={data.marks} onChange={(v) => setData({ ...data, marks: v })} min={0} max={500} />
        <Slider label="Severity" value={data.severity} onChange={(v) => setData({ ...data, severity: v })} />
        {done && <DoneBanner />}
        <SaveButton saving={saving} />
      </form>
    </FormShell>
  );
}