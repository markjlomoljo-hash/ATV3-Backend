// Task board service. Every task maps to a real data contribution.

import { TaskProgressEntity } from '../../lib/api/entityDefs';
import { getSession } from '../../lib/api/session';
import { writeAudit } from '../../lib/api/audit';
import { db, type BaaSRecord } from '../../lib/storage/db';

export interface Task {
  key: string;
  title: string;
  description: string;
  points: number;
  check: () => Promise<{ completedToday: boolean; progress: number }>;
  route: string;
}

async function todayCount(
  store: 'SleepLog' | 'FoodLog' | 'StressLog' | 'ActivityLog' | 'HydrationLog' | 'FaceScan' | 'ProductScan' | 'SymptomLog' | 'RoutineLog'
): Promise<number> {
  const session = getSession();
  if (!session) return 0;
  const today = new Date().toISOString().slice(0, 10);
  const all = await db.list(store, { limit: 9999 });
  return all.filter(
    (r: BaaSRecord) => (r.logDate as string) === today && (r.created_by_id as string) === session.userId
  ).length;
}

export const tasks: Task[] = [
  {
    key: 'sleep_log',
    title: 'Log your sleep',
    description: 'Helps the engine detect sleep-driven inflammation.',
    points: 10,
    route: '/log/sleep',
    check: async () => {
      const n = await todayCount('SleepLog');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
  {
    key: 'food_log',
    title: 'Log today’s diet',
    description: 'Tracks glycemic, dairy, and inflammatory patterns.',
    points: 15,
    route: '/log/food',
    check: async () => {
      const n = await todayCount('FoodLog');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
  {
    key: 'stress_log',
    title: 'Log your stress',
    description: 'Stress is a top trigger for many users.',
    points: 10,
    route: '/log/stress',
    check: async () => {
      const n = await todayCount('StressLog');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
  {
    key: 'symptom_log',
    title: 'Log symptoms',
    description: 'Symptom severity feeds the Skin Twin and TriggerGraph.',
    points: 15,
    route: '/log/symptoms',
    check: async () => {
      const n = await todayCount('SymptomLog');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
  {
    key: 'face_scan',
    title: 'Run a face scan',
    description: 'Powers the Cutis Health Index and Skin Twin Lab.',
    points: 30,
    route: '/face-atlas',
    check: async () => {
      const n = await todayCount('FaceScan');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
  {
    key: 'product_scan',
    title: 'Analyze a product',
    description: 'Adds to FormulaLens and feeds your forecast.',
    points: 20,
    route: '/products',
    check: async () => {
      const n = await todayCount('ProductScan');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
  {
    key: 'hydration',
    title: 'Log hydration',
    description: 'Tracks barrier health in real time.',
    points: 5,
    route: '/log/hydration',
    check: async () => {
      const n = await todayCount('HydrationLog');
      return { completedToday: n > 0, progress: n > 0 ? 1 : 0 };
    },
  },
];

export async function completeTaskManually(taskKey: string) {
  const t = tasks.find((tt) => tt.key === taskKey);
  if (!t) return;
  const all = await TaskProgressEntity.list({ limit: 9999 });
  const existing = all.records.find((r) => r.taskKey === taskKey);
  const now = new Date().toISOString();
  if (existing) {
    await TaskProgressEntity.update(existing.id, {
      lastCompletedAt: now,
      streak: (existing.streak as number) + 1,
      count: (existing.count as number) + 1,
      points: (existing.points as number) + t.points,
    });
  } else {
    await TaskProgressEntity.create({
      taskKey,
      lastCompletedAt: now,
      streak: 1,
      count: 1,
      points: t.points,
    });
  }
  await writeAudit({
    entityType: 'TaskProgress',
    entityId: taskKey,
    operation: 'create',
    changedFields: ['streak', 'points'],
    source: 'user',
  });
}

export async function getTaskState() {
  const all = await TaskProgressEntity.list({ limit: 50 });
  const totalPoints = all.records.reduce((s: number, r) => s + (r.points as number), 0);
  const totalStreak = all.records.reduce((s: number, r) => s + (r.streak as number), 0);
  const perTask: Record<string, { completedToday: boolean; streak: number; points: number }> = {};
  for (const t of tasks) {
    const row = all.records.find((r) => r.taskKey === t.key);
    const today = new Date().toISOString().slice(0, 10);
    const completedToday = !!row && ((row.lastCompletedAt as string) ?? '').slice(0, 10) === today;
    perTask[t.key] = {
      completedToday,
      streak: (row?.streak as number) ?? 0,
      points: (row?.points as number) ?? 0,
    };
  }
  return { totalPoints, totalStreak, perTask };
}