// Intelligence hub.
// Combines AI status, task board, network learning participation,
// CHI, trigger graph, barrier, and AI core health.

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, CheckCircle2, Users, Lock, Unlock } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { AIStatusStrip } from '../../components/shared/Status';
import { InsufficientDataState } from '../../components/shared/EmptyState';
import {
  computeCutisHealthIndex,
  computeBarrierScore,
  computeTriggerGraph,
} from '../../lib/analytics';
import { getTaskState, tasks } from '../../features/intelligence/tasks';
import { useConsent } from '../../hooks/useConsent';
import { ConsentRecordEntity } from '../../lib/api/entityDefs';

import { cn } from '../../utils/cn';

export default function IntelligencePage() {
  const { consentStatus, canContributeToNetwork, revokeConsent, refresh } = useConsent();
  const [chi, setChi] = useState<Awaited<ReturnType<typeof computeCutisHealthIndex>> | null>(null);
  const [barrier, setBarrier] = useState<Awaited<ReturnType<typeof computeBarrierScore>> | null>(null);
  const [triggers, setTriggers] = useState<Awaited<ReturnType<typeof computeTriggerGraph>> | null>(null);
  const [taskState, setTaskState] = useState<Awaited<ReturnType<typeof getTaskState>> | null>(null);

  useEffect(() => {
    (async () => {
      const [a, b, c, t] = await Promise.all([
        computeCutisHealthIndex(),
        computeBarrierScore(),
        computeTriggerGraph(),
        getTaskState(),
      ]);
      setChi(a);
      setBarrier(b);
      setTriggers(c);
      setTaskState(t);
    })();
  }, []);

  async function optIn() {
    await ConsentRecordEntity.create({
      consentType: 'cohort_learning',
      status: 'granted',
      grantedAt: new Date().toISOString(),
      revokedAt: null,
      version: '3.0.0',
    });
    await refresh();
  }

  async function optOut() {
    await revokeConsent();
  }

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="Intelligence" />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <AIStatusStrip />

        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <Users className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <h2 className="text-base font-semibold text-ink-900">AcneTrex Research Network</h2>
              <p className="text-xs text-ink-500">
                Privacy-preserving cohort learning. No raw images or logs are shared without consent.
              </p>
            </div>
            <span
              className={cn(
                'rounded-full px-3 py-1 text-xs font-semibold',
                canContributeToNetwork ? 'bg-success-50 text-success-600' : 'bg-surface-soft text-ink-500'
              )}
            >
              {canContributeToNetwork ? 'Opted in' : 'Private'}
            </span>
          </div>
          <ul className="mt-3 space-y-1 text-xs text-ink-500">
            <li>• Aggregate, de-identified pattern learning only.</li>
            <li>• You can revoke at any time; future emissions stop immediately.</li>
            <li>• Historical aggregates remain for transparency and are clearly marked.</li>
          </ul>
          <div className="mt-3 flex gap-2">
            {canContributeToNetwork ? (
              <button
                onClick={optOut}
                className="touch inline-flex items-center gap-1 rounded-full border border-flare-200 px-4 py-2 text-sm font-semibold text-flare-600 hover:bg-flare-50"
              >
                <Lock className="h-4 w-4" /> Revoke consent
              </button>
            ) : (
              <button
                onClick={optIn}
                className="touch inline-flex items-center gap-1 rounded-full bg-primary-500 px-4 py-2 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600"
              >
                <Unlock className="h-4 w-4" /> Opt in to cohort learning
              </button>
            )}
            <p className="ml-2 text-xs text-ink-400">status: {consentStatus}</p>
          </div>
        </div>

        {taskState && <TaskBoard state={taskState} />}

        {chi && (
          chi.sufficient ? (
            <CHI chi={chi} />
          ) : (
            <InsufficientDataState
              moduleName="CHI"
              requiredDataPoints={chi.minRequired}
              currentDataPoints={chi.dataPoints}
              ctaLabel="Log sleep"
              ctaRoute="/log/sleep"
            />
          )
        )}
        {barrier && (
          barrier.sufficient ? (
            <BarrierCard barrier={barrier} />
          ) : (
            <InsufficientDataState
              moduleName="Barrier"
              requiredDataPoints={barrier.minRequired}
              currentDataPoints={barrier.dataPoints}
              ctaLabel="Log hydration"
              ctaRoute="/log/hydration"
            />
          )
        )}
        {triggers && (
          triggers.sufficient ? (
            <TriggerCard triggers={triggers} />
          ) : (
            <InsufficientDataState
              moduleName="TriggerGraph"
              requiredDataPoints={triggers.minRequired}
              currentDataPoints={triggers.dataPoints}
              ctaLabel="Log diet"
              ctaRoute="/log/food"
            />
          )
        )}
      </div>
    </div>
  );
}

function CHI({ chi }: { chi: NonNullable<Awaited<ReturnType<typeof computeCutisHealthIndex>>> }) {
  return (
    <div className="card-soft p-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-ink-900">Cutis Health Index</h3>
        <Link to="/" className="text-xs font-medium text-primary-700 hover:underline">Home</Link>
      </div>
      <p className="mt-1 text-3xl font-bold text-ink-900">{Math.round(chi.score * 100)}</p>
      <p className="text-xs text-ink-500">
        Trend: {chi.trend}. Drivers: {chi.contributors.join(', ') || 'none'}.
      </p>
    </div>
  );
}

function BarrierCard({ barrier }: { barrier: NonNullable<Awaited<ReturnType<typeof computeBarrierScore>>> }) {
  return (
    <div className="card-soft p-5">
      <h3 className="text-sm font-semibold text-ink-900">BarrierGuard</h3>
      <p className="mt-1 text-3xl font-bold text-ink-900">{Math.round(barrier.score * 100)}</p>
      <p className="text-xs text-ink-500">Drivers: {barrier.drivers.join(', ') || 'none'}.</p>
    </div>
  );
}

function TriggerCard({ triggers }: { triggers: NonNullable<Awaited<ReturnType<typeof computeTriggerGraph>>> }) {
  return (
    <div className="card-soft p-5">
      <h3 className="text-sm font-semibold text-ink-900">TriggerGraph</h3>
      <ul className="mt-2 space-y-1 text-xs">
        {triggers.factors.slice(0, 5).map((f) => (
          <li key={f.factor} className="flex items-center justify-between">
            <span className="text-ink-700">{f.factor}</span>
            <span
              className={cn(
                'rounded-full px-2 py-0.5 text-[10px] font-semibold',
                Math.abs(f.correlation) > 0.2
                  ? f.correlation > 0
                    ? 'bg-flare-50 text-flare-600'
                    : 'bg-success-50 text-success-600'
                  : 'bg-surface-soft text-ink-500'
              )}
            >
              r = {f.correlation.toFixed(2)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TaskBoard({ state }: { state: NonNullable<Awaited<ReturnType<typeof getTaskState>>> }) {
  return (
    <div className="card-soft p-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-ink-900">Daily missions</h3>
        <p className="text-xs text-ink-500">
          {state.totalPoints} pts · streak {state.totalStreak}
        </p>
      </div>
      <ul className="mt-3 space-y-2">
        {tasks.map((t) => {
          const ts = state.perTask[t.key];
          return (
            <li key={t.key} className="flex items-center justify-between rounded-xl bg-surface-soft p-3">
              <div>
                <p className="text-sm font-medium text-ink-900">{t.title}</p>
                <p className="text-xs text-ink-500">{t.description}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-[10px] font-semibold text-primary-700">+{t.points} pts</span>
                {ts?.completedToday ? (
                  <span className="inline-flex items-center gap-1 text-[10px] text-success-600">
                    <CheckCircle2 className="h-3 w-3" /> Done
                  </span>
                ) : (
                  <Link
                    to={t.route}
                    className="inline-flex items-center gap-1 rounded-full bg-primary-500 px-3 py-1.5 text-[10px] font-semibold text-white"
                  >
                    <Activity className="h-3 w-3" /> Start
                  </Link>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}