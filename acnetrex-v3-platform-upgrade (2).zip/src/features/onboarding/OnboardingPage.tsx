import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { OnboardingProfileEntity } from '../../lib/api/entityDefs';
import { getSession } from '../../lib/api/session';
import { ChevronRight } from 'lucide-react';
import { cn } from '../../utils/cn';

interface Answers {
  skinType: 'oily' | 'dry' | 'combination' | 'normal' | 'sensitive';
  acneSeverity: 'mild' | 'moderate' | 'severe';
  ageRange: string;
  concerns: string[];
  goals: string[];
  climate: string;
  dietPattern: string;
  hormonal: boolean;
}

const initial: Answers = {
  skinType: 'combination',
  acneSeverity: 'mild',
  ageRange: '25-34',
  concerns: [],
  goals: [],
  climate: 'temperate',
  dietPattern: 'omnivore',
  hormonal: false,
};

type StepDef = {
  key: keyof Answers;
  label: string;
  options: readonly string[];
  kind: 'single' | 'multi' | 'yesno';
};

const steps: readonly StepDef[] = [
  { key: 'skinType', label: 'How would you describe your skin?', options: ['oily', 'dry', 'combination', 'normal', 'sensitive'], kind: 'single' },
  { key: 'acneSeverity', label: 'How would you rate your current acne severity?', options: ['mild', 'moderate', 'severe'], kind: 'single' },
  { key: 'ageRange', label: 'Age range?', options: ['18-24', '25-34', '35-44', '45-54', '55+'], kind: 'single' },
  {
    key: 'concerns',
    label: 'Which concerns apply to you?',
    options: ['Inflammation', 'PIH / dark marks', 'PIE / red marks', 'Scarring', 'Texture', 'Excess oil', 'Dryness', 'Hormonal breakouts'],
    kind: 'multi',
  },
  {
    key: 'goals',
    label: 'What are your goals?',
    options: ['Clearer skin', 'Reduce redness', 'Reduce marks', 'Stronger barrier', 'Fewer breakouts', 'Better routine'],
    kind: 'multi',
  },
  { key: 'climate', label: 'Climate you live in?', options: ['temperate', 'humid', 'dry', 'cold', 'tropical'], kind: 'single' },
  { key: 'dietPattern', label: 'Diet pattern?', options: ['omnivore', 'vegetarian', 'vegan', 'pescatarian', 'other'], kind: 'single' },
  { key: 'hormonal', label: 'Do breakouts track with your cycle?', options: ['Yes', 'No'], kind: 'yesno' },
];

export default function OnboardingPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Answers>(initial);
  const [submitting, setSubmitting] = useState(false);
  const submittingRef = useRef(false);

  useEffect(() => {
    if (!getSession()) navigate('/auth', { replace: true });
  }, [navigate]);

  function toggle(key: 'concerns' | 'goals', value: string) {
    setAnswers((prev) => {
      const cur = prev[key];
      return {
        ...prev,
        [key]: cur.includes(value) ? cur.filter((v) => v !== value) : [...cur, value],
      };
    });
  }

  async function finish() {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSubmitting(true);
    try {
      await OnboardingProfileEntity.create({
        ...answers,
        completed: true,
        completedAt: new Date().toISOString(),
      });
      navigate('/', { replace: true });
    } catch (err) {
      console.error(err);
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  }

  function next() {
    if (step < steps.length - 1) setStep(step + 1);
    else finish();
  }

  const s = steps[step];

  return (
    <div className="gradient-hero min-h-screen px-4 pb-12 pt-10">
      <div className="mx-auto max-w-md">
        <div className="mb-6 flex items-center gap-2">
          {steps.map((_, i) => (
            <div
              key={i}
              className={cn('h-1 flex-1 rounded-full transition', i <= step ? 'bg-primary-500' : 'bg-surface-soft')}
            />
          ))}
        </div>
        <motion.div
          key={s.key}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-soft p-5"
        >
          <h2 className="text-lg font-semibold text-ink-900">{s.label}</h2>
          <p className="mt-1 text-sm text-ink-500">
            Step {step + 1} of {steps.length}
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            {s.kind === 'multi' ? (
              s.options.map((o) => {
                const list = answers[s.key] as string[];
                const active = list.includes(o);
                return (
                  <button
                    key={o}
                    type="button"
                    onClick={() => toggle(s.key as 'concerns' | 'goals', o)}
                    className={cn(
                      'rounded-full border px-3 py-2 text-sm font-medium transition',
                      active
                        ? 'border-primary-500 bg-primary-500 text-white shadow-sm shadow-primary-200'
                        : 'border-surface-soft bg-white text-ink-700 hover:border-primary-300'
                    )}
                  >
                    {o}
                  </button>
                );
              })
            ) : s.kind === 'yesno' ? (
              ['Yes', 'No'].map((o) => (
                <button
                  key={o}
                  type="button"
                  onClick={() => setAnswers({ ...answers, hormonal: o === 'Yes' })}
                  className={cn(
                    'rounded-full border px-4 py-2 text-sm font-medium transition',
                    answers.hormonal === (o === 'Yes')
                      ? 'border-primary-500 bg-primary-500 text-white shadow-sm shadow-primary-200'
                      : 'border-surface-soft bg-white text-ink-700 hover:border-primary-300'
                  )}
                >
                  {o}
                </button>
              ))
            ) : (
              s.options.map((o) => {
                const active = answers[s.key] === o;
                return (
                  <button
                    key={o}
                    type="button"
                    onClick={() =>
                      setAnswers({ ...answers, [s.key]: o } as Answers)
                    }
                    className={cn(
                      'rounded-full border px-4 py-2 text-sm font-medium transition capitalize',
                      active
                        ? 'border-primary-500 bg-primary-500 text-white shadow-sm shadow-primary-200'
                        : 'border-surface-soft bg-white text-ink-700 hover:border-primary-300'
                    )}
                  >
                    {o}
                  </button>
                );
              })
            )}
          </div>

          <button
            type="button"
            onClick={next}
            disabled={submitting}
            className="touch mt-6 flex w-full items-center justify-center gap-1 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 transition hover:bg-primary-600 disabled:opacity-60"
          >
            {step < steps.length - 1 ? 'Continue' : submitting ? 'Saving…' : 'Finish'}
            <ChevronRight className="h-4 w-4" />
          </button>
        </motion.div>
      </div>
    </div>
  );
}