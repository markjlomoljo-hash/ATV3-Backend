// Aggregated pages: Triggers, Barrier, SkinTwin, Sleep, Diet, Activity,
// Cycle, Contact, Climate, Forecast-trend. All read from real entities.

import { useEffect, useState } from 'react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, InsufficientDataState } from '../../components/shared/EmptyState';
import { computeBarrierScore, computeTriggerGraph, computeSkinTwin } from '../../lib/analytics';
import {
  SleepLogEntity,
  FoodLogEntity,
  ActivityLogEntity,
  CycleLogEntity,
  ContactLogEntity,
} from '../../lib/api/entityDefs';
import { TRIGGER_GRAPH_MIN_DAYS, BARRIER_MIN_DAYS, SKIN_TWIN_MIN_SCANS } from '../../lib/constants/dataThresholds';
import { BarChart, Bar, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, LineChart, Line } from 'recharts';
import { Activity, Moon, ShieldCheck, Sparkles, TrendingUp, Flame } from 'lucide-react';

export function TriggersPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof computeTriggerGraph>> | null>(null);
  useEffect(() => {
    computeTriggerGraph().then(setData);
  }, []);
  return (
    <Page title="TriggerGraph" subtitle="Correlations between your patterns and inflammation.">
      {data?.sufficient ? (
        <div className="card-soft p-5">
          <h3 className="text-sm font-semibold text-ink-900">Top correlations</h3>
          <div className="mt-3 h-56">
            <ResponsiveContainer>
              <BarChart data={data.factors}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eef0f4" />
                <XAxis dataKey="factor" tickLine={false} axisLine={false} fontSize={10} />
                <YAxis domain={[-1, 1]} tickLine={false} axisLine={false} fontSize={10} />
                <Tooltip />
                <Bar dataKey="correlation" fill="#7c6ee6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-3 space-y-1 text-xs text-ink-500">
            {data.factors.map((f) => (
              <li key={f.factor} className="flex justify-between">
                <span>{f.factor}</span>
                <span>r = {f.correlation.toFixed(2)}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : data ? (
        <InsufficientDataState
          moduleName="TriggerGraph"
          requiredDataPoints={TRIGGER_GRAPH_MIN_DAYS}
          currentDataPoints={data.dataPoints}
          ctaLabel="Log food"
          ctaRoute="/log/food"
        />
      ) : (
        <Skeleton />
      )}
    </Page>
  );
}

export function BarrierPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof computeBarrierScore>> | null>(null);
  useEffect(() => {
    computeBarrierScore().then(setData);
  }, []);
  return (
    <Page title="BarrierGuard" subtitle="Skin barrier resilience score and drivers.">
      {data?.sufficient ? (
        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-primary-500" />
            <p className="text-3xl font-bold text-ink-900">{Math.round(data.score * 100)}</p>
            <span className="ml-auto text-xs text-ink-500">{data.drivers.length} drivers</span>
          </div>
          <ul className="mt-4 space-y-2 text-sm">
            {data.drivers.map((d) => (
              <li key={d} className="rounded-xl bg-surface-soft px-3 py-2 text-ink-700">{d}</li>
            ))}
            {data.drivers.length === 0 && <li className="text-sm text-ink-500">No major drivers flagged.</li>}
          </ul>
        </div>
      ) : data ? (
        <InsufficientDataState
          moduleName="Barrier"
          requiredDataPoints={BARRIER_MIN_DAYS}
          currentDataPoints={data.dataPoints}
          ctaLabel="Log hydration"
          ctaRoute="/log/hydration"
        />
      ) : (
        <Skeleton />
      )}
    </Page>
  );
}

export function SkinTwinPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof computeSkinTwin>> | null>(null);
  useEffect(() => {
    computeSkinTwin().then(setData);
  }, []);
  return (
    <Page title="Skin Twin Lab" subtitle="Counterfactual reasoning layer — simulates interventions on your skin state.">
      {data?.sufficient ? (
        <>
          <div className="card-soft p-5">
            <div className="flex items-center gap-3">
              <Sparkles className="h-6 w-6 text-primary-500" />
              <div>
                <p className="text-sm font-semibold text-ink-900">Scan history</p>
                <p className="text-xs text-ink-500">{data.scanCount} scans powering this view</p>
              </div>
            </div>
            <div className="mt-4 h-48">
              <ResponsiveContainer>
                <LineChart data={data.trend}>
                  <XAxis dataKey="date" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis fontSize={10} tickLine={false} axisLine={false} domain={[0, 1]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="score" stroke="#5ac8e8" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card-soft p-5">
            <h3 className="text-sm font-semibold text-ink-900">Zone scores</h3>
            <ul className="mt-3 grid grid-cols-2 gap-2 text-xs">
              {Object.entries(data.zoneScores).map(([k, v]) => (
                <li key={k} className="rounded-xl bg-surface-soft px-3 py-2">
                  <div className="text-[10px] uppercase tracking-wide text-ink-400">{k}</div>
                  <div className="text-sm font-semibold text-ink-900">{(v * 100).toFixed(0)}%</div>
                </li>
              ))}
            </ul>
          </div>

          <div className="card-soft p-5">
            <h3 className="text-sm font-semibold text-ink-900">Counterfactual scenarios</h3>
            <ul className="mt-3 space-y-2 text-sm">
              {data.counterfactuals.map((c, i) => (
                <li key={i} className="rounded-xl bg-surface-soft p-3">
                  <p className="font-semibold text-ink-900">{c.intervention}</p>
                  <p className="text-xs text-ink-500">{c.rationale}</p>
                  <p className="mt-1 text-[10px] font-semibold text-primary-700">
                    Expected delta: {c.expectedDelta >= 0 ? '+' : ''}
                    {c.expectedDelta.toFixed(2)}
                  </p>
                </li>
              ))}
              {data.counterfactuals.length === 0 && (
                <li className="text-sm text-ink-500">No clear leverage points yet — keep logging.</li>
              )}
            </ul>
          </div>
        </>
      ) : data ? (
        <InsufficientDataState
          moduleName="Skin Twin"
          requiredDataPoints={SKIN_TWIN_MIN_SCANS}
          currentDataPoints={data.scanCount}
          ctaLabel="Run face scan"
          ctaRoute="/face-atlas"
        />
      ) : (
        <Skeleton />
      )}
    </Page>
  );
}

export function SleepPage() {
  const [data, setData] = useState<{ date: string; hours: number; quality: number | null }[]>([]);
  useEffect(() => {
    (async () => {
      const list = await SleepLogEntity.list({ limit: 14 });
      setData(
        list.records.map((r) => ({
          date: r.logDate as string,
          hours: r.hours as number,
          quality: (r.quality as number) ?? null,
        }))
      );
    })();
  }, []);
  return <LogPage title="SleepDerm" icon={Moon} data={data} empty="No sleep logs yet." cta="/log/sleep" ctaLabel="Log sleep" dataKey="hours" />;
}

export function DietPage() {
  const [data, setData] = useState<{ date: string; gi: number }[]>([]);
  useEffect(() => {
    (async () => {
      const list = await FoodLogEntity.list({ limit: 14 });
      const mapped = list.records.map((r) => ({
        date: r.logDate as string,
        gi: giScore(r.glycemicLoad as string | undefined) + dairyScore(r.dairyLevel as string | undefined) + sugarScore(r.sugarLevel as string | undefined),
      }));
      setData(mapped);
    })();
  }, []);
  return <LogPage title="DermDiet" icon={Flame} data={data} empty="No food logs yet." cta="/log/food" ctaLabel="Log food" dataKey="gi" />;
}

export function ActivityPage() {
  const [data, setData] = useState<{ date: string; sweat: number }[]>([]);
  useEffect(() => {
    (async () => {
      const list = await ActivityLogEntity.list({ limit: 14 });
      setData(list.records.map((r) => ({ date: r.logDate as string, sweat: sweatScore(r.sweatLevel as string | undefined) + (r.durationMinutes as number ?? 0) / 60 })));
    })();
  }, []);
  return <LogPage title="SweatFlow" icon={Activity} data={data} empty="No activity logs yet." cta="/log/activity" ctaLabel="Log activity" dataKey="sweat" />;
}

export function CyclePage() {
  const [data, setData] = useState<{ date: string; phase: string }[]>([]);
  useEffect(() => {
    (async () => {
      const list = await CycleLogEntity.list({ limit: 14 });
      setData(list.records.map((r) => ({ date: r.logDate as string, phase: String(r.phase) })));
    })();
  }, []);
  return (
    <Page title="CycleSync" subtitle="Cycle-aware skin insights.">
      <div className="card-soft p-5">
        {data.length === 0 ? (
          <EmptyState icon={TrendingUp} title="No cycle logs" description="Log your cycle to unlock hormonal pattern insights." ctaLabel="Log cycle" ctaRoute="/log/cycle" />
        ) : (
          <ul className="space-y-2 text-sm">
            {data.map((d, i) => (
              <li key={i} className="flex items-center justify-between rounded-xl bg-surface-soft px-3 py-2">
                <span className="text-ink-700">{d.date}</span>
                <span className="rounded-full bg-primary-50 px-3 py-1 text-xs font-semibold text-primary-700">{d.phase}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Page>
  );
}

export function ContactPage() {
  const [data, setData] = useState<{ date: string; load: number }[]>([]);
  useEffect(() => {
    (async () => {
      const list = await ContactLogEntity.list({ limit: 14 });
      setData(
        list.records.map((r) => ({
          date: r.logDate as string,
          load: (r.helmet ? 1 : 0) + (r.mask ? 1 : 0) + (r.phone ? 1 : 0) + (r.pillowcase ? 1 : 0) + (r.handsToFace ? 1 : 0),
        }))
      );
    })();
  }, []);
  return <LogPage title="ContactGuard" icon={ShieldCheck} data={data} empty="No contact logs yet." cta="/log/contact" ctaLabel="Log contact" dataKey="load" />;
}

export function ClimatePage() {
  return (
    <Page title="ClimateSkin Radar" subtitle="Weather-aware skin context.">
      <WeatherPanel />
    </Page>
  );
}

function WeatherPanel() {
  const [data, setData] = useState<{ temperatureC: number | null; humidity: number | null; uvIndex: number | null; description: string | null; source: string } | null>(null);
  useEffect(() => {
    (async () => {
      const { fetchWeather } = await import('../../lib/ai/weather');
      setData(await fetchWeather());
    })();
  }, []);
  if (!data) return <Skeleton />;
  if (data.source === 'unavailable') {
    return (
      <EmptyState
        icon={TrendingUp}
        title="Weather unavailable"
        description="Set VITE_WEATHER_ENDPOINT and VITE_WEATHER_API_KEY to enable live weather context."
      />
    );
  }
  return (
    <div className="card-soft p-5">
      <p className="text-sm text-ink-500">{data.description ?? 'No description'}</p>
      <p className="mt-1 text-3xl font-bold text-ink-900">{data.temperatureC ?? '—'}°C</p>
      <ul className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <li className="rounded-xl bg-surface-soft px-3 py-2">Humidity {data.humidity ?? '—'}%</li>
        <li className="rounded-xl bg-surface-soft px-3 py-2">UV {data.uvIndex ?? '—'}</li>
      </ul>
    </div>
  );
}

function Page({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title={title} />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        {subtitle && <p className="text-sm text-ink-500">{subtitle}</p>}
        {children}
      </div>
    </div>
  );
}

function LogPage({
  title,
  icon: Icon,
  data,
  empty,
  cta,
  ctaLabel,
  dataKey,
}: {
  title: string;
  icon: typeof Moon;
  data: { date: string; [k: string]: unknown }[];
  empty: string;
  cta: string;
  ctaLabel: string;
  dataKey: string;
}) {
  return (
    <Page title={title} subtitle="Real history from your logs.">
      <div className="card-soft p-5">
        {data.length === 0 ? (
          <EmptyState icon={Icon} title={empty} description="Start logging today to populate this view." ctaLabel={ctaLabel} ctaRoute={cta} />
        ) : (
          <div className="h-56">
            <ResponsiveContainer>
              <LineChart data={data}>
                <XAxis dataKey="date" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip />
                <Line type="monotone" dataKey={dataKey} stroke="#7c6ee6" strokeWidth={2} dot />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </Page>
  );
}

function Skeleton() {
  return <div className="card-soft animate-pulse p-6 text-sm text-ink-400">Loading…</div>;
}

function giScore(v?: string) {
  return v === 'high' ? 3 : v === 'medium' ? 2 : v === 'low' ? 1 : 0;
}
function dairyScore(v?: string) {
  return v === 'high' ? 3 : v === 'medium' ? 2 : v === 'low' ? 1 : 0;
}
function sugarScore(v?: string) {
  return v === 'high' ? 3 : v === 'medium' ? 2 : v === 'low' ? 1 : 0;
}
function sweatScore(v?: string) {
  return v === 'high' ? 3 : v === 'medium' ? 2 : v === 'low' ? 1 : 0;
}



