// Profile page — settings, consent, account deletion.

import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Trash2, User } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { logout, deleteAccount } from '../../lib/api/auth';
import { getSession } from '../../lib/api/session';
import { OnboardingProfileEntity } from '../../lib/api/entityDefs';
import { useConsent } from '../../hooks/useConsent';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { consentStatus, canContributeToNetwork, revokeConsent } = useConsent();
  const [profile, setProfile] = useState<Record<string, unknown> | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const submittingRef = useRef(false);

  useEffect(() => {
    (async () => {
      const list = await OnboardingProfileEntity.list({ limit: 1 });
      if (list.records[0]) setProfile(list.records[0] as unknown as Record<string, unknown>);
    })();
  }, []);

  async function handleLogout() {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSubmitting(true);
    await logout();
    navigate('/auth', { replace: true });
  }

  async function handleDelete() {
    if (submittingRef.current) return;
    if (!confirm('Delete your account? This is irreversible after 30 days.')) return;
    submittingRef.current = true;
    setSubmitting(true);
    try {
      await deleteAccount();
      navigate('/auth', { replace: true });
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  }

  const session = getSession();

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="Profile" />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <div className="card-soft flex items-center gap-3 p-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-500 text-white">
            <User className="h-6 w-6" />
          </div>
          <div>
            <p className="text-base font-semibold text-ink-900">{session?.displayName ?? 'Account'}</p>
            <p className="text-xs text-ink-500">{session?.email}</p>
          </div>
        </div>

        {profile && (
          <div className="card-soft p-5">
            <h3 className="text-sm font-semibold text-ink-900">Profile</h3>
            <ul className="mt-3 space-y-1 text-sm">
              {Object.entries(profile)
                .filter(([k]) => !['id', 'created_by_id', 'created_date', 'updated_date', 'app_version', 'schema_version', 'source'].includes(k))
                .map(([k, v]) => (
                  <li key={k} className="flex items-center justify-between">
                    <span className="text-ink-500">{k}</span>
                    <span className="font-medium text-ink-900">{typeof v === 'object' ? JSON.stringify(v) : String(v ?? '—')}</span>
                  </li>
                ))}
            </ul>
          </div>
        )}

        <div className="card-soft p-5">
          <h3 className="text-sm font-semibold text-ink-900">Privacy & consent</h3>
          <p className="mt-1 text-xs text-ink-500">
            Cohort learning: <strong>{canContributeToNetwork ? 'granted' : 'revoked'}</strong> ({consentStatus})
          </p>
          {canContributeToNetwork && (
            <button
              onClick={revokeConsent}
              className="touch mt-3 inline-flex items-center gap-1 rounded-full border border-flare-200 px-4 py-2 text-sm font-semibold text-flare-600 hover:bg-flare-50"
            >
              Revoke consent
            </button>
          )}
        </div>

        <div className="card-soft p-5">
          <h3 className="text-sm font-semibold text-ink-900">Account</h3>
          <div className="mt-3 flex flex-col gap-2">
            <button
              onClick={handleLogout}
              disabled={submitting}
              className="touch flex items-center justify-center gap-1 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600"
            >
              <LogOut className="h-4 w-4" /> Log out
            </button>
            <button
              onClick={handleDelete}
              disabled={submitting}
              className="touch flex items-center justify-center gap-1 rounded-full border border-flare-200 px-4 py-3 text-sm font-semibold text-flare-600 hover:bg-flare-50"
            >
              <Trash2 className="h-4 w-4" /> Delete account
            </button>
          </div>
        </div>

        <p className="text-center text-[10px] text-ink-400">
          Stored in your private durable store · v3.0.0
        </p>
      </div>
    </div>
  );
}