import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { signUp, login, getRememberedEmail, requestPasswordReset } from '../../lib/api/auth';
import { migrateLegacyIfPresent, hasLegacyData } from '../../lib/api/migration';
import { getSession } from '../../lib/api/session';
import { Eye, EyeOff, Shield, Sparkles, Lock, Mail, User } from 'lucide-react';
import { cn } from '../../utils/cn';

type Mode = 'signin' | 'signup' | 'reset';

export default function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState(() => getRememberedEmail() ?? '');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const submittingRef = useRef(false);

  useEffect(() => {
    const s = getSession();
    if (s) navigate('/onboarding', { replace: true });
  }, [navigate]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSubmitting(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === 'signup') {
        const r = await signUp({ email, password, displayName: displayName || email.split('@')[0], rememberMe });
        if (!r.ok) {
          setError(r.error.message);
          return;
        }
      } else if (mode === 'signin') {
        const r = await login({ email, password, rememberMe });
        if (!r.ok) {
          setError(r.error.message);
          return;
        }
      } else {
        const r = await requestPasswordReset(email);
        if (!r.ok) {
          setError(r.error);
          return;
        }
        setInfo(
          'If that email is on file, a reset link has been issued. In this demo, the token is shown below; enter it on the next screen.'
        );
        setMode('signin');
        return;
      }
      if (hasLegacyData()) {
        await migrateLegacyIfPresent();
      }
      navigate('/onboarding', { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  }

  return (
    <div className="gradient-hero min-h-screen px-4 pb-12 pt-10">
      <div className="mx-auto max-w-md">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-500 to-accent-400 shadow-lg shadow-primary-200">
            <Sparkles className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-ink-900">AcneTrex</h1>
          <p className="mt-1 text-sm text-ink-500">Skin intelligence, calibrated to you.</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          onSubmit={handleSubmit}
          className="card-soft space-y-3 p-5"
        >
          <div className="flex gap-1 rounded-full bg-surface-soft p-1 text-sm">
            {(['signin', 'signup'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={cn(
                  'flex-1 rounded-full px-3 py-2 font-medium transition',
                  mode === m ? 'bg-white shadow-sm text-ink-900' : 'text-ink-500'
                )}
              >
                {m === 'signin' ? 'Sign in' : 'Create account'}
              </button>
            ))}
          </div>

          {mode === 'signup' && (
            <Field
              icon={User}
              type="text"
              placeholder="Display name"
              value={displayName}
              onChange={setDisplayName}
              autoComplete="name"
            />
          )}
          <Field
            icon={Mail}
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={setEmail}
            autoComplete="email"
          />
          {mode !== 'reset' && (
            <Field
              icon={Lock}
              type={showPw ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={setPassword}
              autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
              trailing={
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="touch flex h-11 w-11 items-center justify-center text-ink-500"
                  aria-label={showPw ? 'Hide password' : 'Show password'}
                >
                  {showPw ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              }
            />
          )}

          <label className="flex items-center gap-2 px-1 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="h-4 w-4 rounded border-ink-300 text-primary-500 focus:ring-primary-500"
            />
            Remember me on this device
          </label>

          {error && (
            <p className="rounded-lg bg-flare-50 px-3 py-2 text-sm text-flare-600">{error}</p>
          )}
          {info && <p className="rounded-lg bg-success-50 px-3 py-2 text-sm text-success-600">{info}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="touch w-full rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 transition hover:bg-primary-600 disabled:opacity-60"
          >
            {submitting
              ? 'Working…'
              : mode === 'signin'
              ? 'Sign in'
              : mode === 'signup'
              ? 'Create account'
              : 'Send reset link'}
          </button>

          {mode === 'signin' && (
            <button
              type="button"
              onClick={() => setMode('reset')}
              className="block w-full text-center text-sm font-medium text-primary-700 hover:underline"
            >
              Forgot password?
            </button>
          )}

          <div className="flex items-center gap-2 rounded-xl bg-surface-soft px-3 py-2 text-xs text-ink-500">
            <Shield className="h-4 w-4 text-primary-500" />
            Your data is encrypted with PBKDF2-SHA256 and stored durably in your private store.
          </div>
        </motion.form>
      </div>
    </div>
  );
}

function Field({
  icon: Icon,
  type,
  placeholder,
  value,
  onChange,
  autoComplete,
  trailing,
}: {
  icon: typeof Mail;
  type: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  autoComplete?: string;
  trailing?: React.ReactNode;
}) {
  return (
    <label className="flex items-center gap-2 rounded-2xl border border-surface-soft bg-white px-3 focus-within:border-primary-300 focus-within:ring-2 focus-within:ring-primary-100">
      <Icon className="h-5 w-5 text-ink-400" />
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required
        className="touch w-full bg-transparent text-sm text-ink-900 placeholder:text-ink-400 focus:outline-none"
      />
      {trailing}
    </label>
  );
}