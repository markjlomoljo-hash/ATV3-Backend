// Reports page.

import { useEffect, useRef, useState } from 'react';
import { FileText, Loader2 } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, ErrorState } from '../../components/shared/EmptyState';
import { generateReport } from './reportService';
import { ReportExportEntity } from '../../lib/api/entityDefs';
import { LIMITS } from '../../lib/constants/dataThresholds';

interface Report {
  id: string;
  title: string;
  generatedAt: string;
  range: { from: string; to: string };
  payload: string;
}

export default function ReportsPage() {
  const [list, setList] = useState<Report[]>([]);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submittingRef = useRef(false);

  useEffect(() => {
    (async () => {
      const r = await ReportExportEntity.list({ limit: LIMITS.DAILY_LOG });
      setList(
        r.records.map((rec) => ({
          id: rec.id as string,
          title: rec.title as string,
          generatedAt: rec.generatedAt as string,
          range: rec.range as { from: string; to: string },
          payload: rec.payload as string,
        }))
      );
    })();
  }, []);

  async function generate() {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setGenerating(true);
    setError(null);
    try {
      await generateReport(30);
      const r = await ReportExportEntity.list({ limit: LIMITS.DAILY_LOG });
      setList(
        r.records.map((rec) => ({
          id: rec.id as string,
          title: rec.title as string,
          generatedAt: rec.generatedAt as string,
          range: rec.range as { from: string; to: string },
          payload: rec.payload as string,
        }))
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Report failed.');
    } finally {
      submittingRef.current = false;
      setGenerating(false);
    }
  }

  function openReport(r: Report) {
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(r.payload);
    w.document.close();
  }

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="Reports" />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-ink-900">Dermatologist-ready exports</h2>
              <p className="text-xs text-ink-500">
                Generates a structured 30-day summary with logs, scans, triggers, and AI commentary.
              </p>
            </div>
          </div>
          <button
            onClick={generate}
            disabled={generating}
            className="touch mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-60"
          >
            {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
            {generating ? 'Generating…' : 'Generate 30-day report'}
          </button>
          {error && <ErrorState description={error} onRetry={generate} />}
        </div>

        {list.length === 0 ? (
          <EmptyState
            icon={FileText}
            title="No reports yet"
            description="Generate your first 30-day report to share with your dermatologist."
          />
        ) : (
          <ul className="space-y-2">
            {list.map((r) => (
              <li key={r.id}>
                <button
                  onClick={() => openReport(r)}
                  className="card-soft flex w-full items-center justify-between p-4 text-left transition hover:bg-surface-soft"
                >
                  <div>
                    <p className="text-sm font-semibold text-ink-900">{r.title}</p>
                    <p className="text-xs text-ink-500">
                      Generated {new Date(r.generatedAt).toLocaleString()}
                    </p>
                  </div>
                  <FileText className="h-4 w-4 text-primary-500" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}