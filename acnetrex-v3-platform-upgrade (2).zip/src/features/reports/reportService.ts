// Report export service.
// Builds a dermatologist-ready PDF-friendly HTML report from real records.

import { format, subDays } from 'date-fns';
import {
  FaceScanEntity,
  ProductScanEntity,
  SleepLogEntity,
  StressLogEntity,
  FoodLogEntity,
  HydrationLogEntity,
  ActivityLogEntity,
  SymptomLogEntity,
  ContactLogEntity,
  RoutineLogEntity,
  TreatmentLogEntity,
  ForecastEntity,
  EvidenceBookmarkEntity,
  ReportExportEntity,
  OnboardingProfileEntity,
} from '../../lib/api/entityDefs';
import { computeBarrierScore, computeCutisHealthIndex, computeTriggerGraph } from '../../lib/analytics';
import { getCoreStatus } from '../../lib/ai/intelligenceCore';
import { invokeWithRetry } from '../../lib/ai/invokeWithRetry';
import { buildSafePrompt } from '../../lib/ai/promptBuilder';

export async function generateReport(rangeDays = 30) {
  const from = format(subDays(new Date(), rangeDays), 'yyyy-MM-dd');
  const to = format(new Date(), 'yyyy-MM-dd');

  const [onboarding, scans, products, sleep, stress, food, hydration, activity, symptoms, contact, routine, treatment, forecasts, evidence] =
    await Promise.all([
      OnboardingProfileEntity.list({ limit: 1 }),
      FaceScanEntity.list({ limit: 10 }),
      ProductScanEntity.list({ limit: 10 }),
      SleepLogEntity.list({ limit: 20 }),
      StressLogEntity.list({ limit: 20 }),
      FoodLogEntity.list({ limit: 20 }),
      HydrationLogEntity.list({ limit: 20 }),
      ActivityLogEntity.list({ limit: 20 }),
      SymptomLogEntity.list({ limit: 20 }),
      ContactLogEntity.list({ limit: 20 }),
      RoutineLogEntity.list({ limit: 20 }),
      TreatmentLogEntity.list({ limit: 20 }),
      ForecastEntity.list({ limit: 5 }),
      EvidenceBookmarkEntity.list({ limit: 20 }),
    ]);

  const chi = await computeCutisHealthIndex();
  const barrier = await computeBarrierScore();
  const triggers = await computeTriggerGraph();
  const core = await getCoreStatus();

  // Build an LLM-authored clinical summary only from the real data present.
  const { prompt } = buildSafePrompt(
    [
      {
        key: 'system',
        content:
          'You are a dermatology-focused clinical report writer. Produce a 4-paragraph plain-language summary suitable for a board-certified dermatologist. Be factual, cautious, and explicit about uncertainty. Output JSON {summary: string, keyFindings: string[], recommendations: string[]}.',
        priority: 0,
      },
      { key: 'range', content: `Range ${from} to ${to}`, priority: 0 },
      { key: 'chi', content: JSON.stringify(chi), priority: 1 },
      { key: 'barrier', content: JSON.stringify(barrier), priority: 1 },
      { key: 'triggers', content: JSON.stringify(triggers), priority: 1 },
      { key: 'scans', content: JSON.stringify(scans.records.slice(0, 3)), priority: 1 },
      { key: 'products', content: JSON.stringify(products.records.slice(0, 5)), priority: 1 },
      { key: 'forecasts', content: JSON.stringify(forecasts.records.slice(0, 2)), priority: 1 },
    ],
    8_000
  );

  const outcome = await invokeWithRetry({
    prompt,
    responseJsonSchema: {
      root: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          keyFindings: { type: 'array', items: { type: 'string' } },
          recommendations: { type: 'array', items: { type: 'string' } },
        },
        required: ['summary', 'keyFindings', 'recommendations'],
      },
    },
  });

  const llmSummary = outcome.ok ? outcome.parsed : { summary: '', keyFindings: [], recommendations: [] };

  const html = renderHtmlReport({
    onboarding: onboarding.records[0] ?? null,
    chi,
    barrier,
    triggers,
    core,
    scans: scans.records,
    products: products.records,
    sleep: sleep.records,
    stress: stress.records,
    food: food.records,
    hydration: hydration.records,
    activity: activity.records,
    symptoms: symptoms.records,
    contact: contact.records,
    routine: routine.records,
    treatment: treatment.records,
    forecasts: forecasts.records,
    evidence: evidence.records,
    llmSummary,
    range: { from, to },
  });

  const saved = await ReportExportEntity.create({
    title: `AcneTrex Report ${from} – ${to}`,
    generatedAt: new Date().toISOString(),
    sections: [
      'profile',
      'chi',
      'barrier',
      'triggers',
      'scans',
      'products',
      'forecasts',
      'evidence',
      'summary',
    ],
    payload: html,
    range: { from, to },
  });

  return saved;
}

function renderHtmlReport(input: {
  onboarding: Record<string, unknown> | null;
  chi: { score: number; trend: string; contributors: string[] };
  barrier: { score: number; drivers: string[] };
  triggers: { factors: { factor: string; correlation: number }[] };
  core: { activeUsers: number; inferenceCount24h: number; consentGranted: boolean };
  scans: Record<string, unknown>[];
  products: Record<string, unknown>[];
  sleep: Record<string, unknown>[];
  stress: Record<string, unknown>[];
  food: Record<string, unknown>[];
  hydration: Record<string, unknown>[];
  activity: Record<string, unknown>[];
  symptoms: Record<string, unknown>[];
  contact: Record<string, unknown>[];
  routine: Record<string, unknown>[];
  treatment: Record<string, unknown>[];
  forecasts: Record<string, unknown>[];
  evidence: Record<string, unknown>[];
  llmSummary: { summary?: string; keyFindings?: string[]; recommendations?: string[] };
  range: { from: string; to: string };
}) {
  const safe = (v: unknown) => String(v ?? '').replace(/[<>]/g, '');
  return `<!doctype html>
<html><head><meta charset="utf-8" /><title>AcneTrex Report ${input.range.from} – ${input.range.to}</title>
<style>
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#111;max-width:780px;margin:0 auto;padding:32px}
h1,h2{color:#4f46e5}
table{border-collapse:collapse;width:100%;margin:8px 0 24px}
th,td{border-bottom:1px solid #eee;padding:8px;text-align:left;font-size:14px}
.kv{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #f1f1f1;font-size:14px}
.section{margin:24px 0}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#eef2ff;color:#4338ca;font-size:12px;margin-right:6px}
</style></head><body>
<h1>AcneTrex Clinical Report</h1>
<p>Range: ${input.range.from} – ${input.range.to}</p>

<div class="section">
<h2>Profile</h2>
${
  input.onboarding
    ? Object.entries(input.onboarding)
        .filter(([k]) => !['id', 'created_by_id', 'created_date', 'updated_date', 'app_version', 'schema_version', 'source'].includes(k))
        .map(([k, v]) => `<div class="kv"><span>${safe(k)}</span><span>${safe(typeof v === 'object' ? JSON.stringify(v) : v)}</span></div>`)
        .join('')
    : '<p>No onboarding profile recorded.</p>'
}
</div>

<div class="section">
<h2>Cutis Health Index</h2>
<p>Score: <strong>${(input.chi.score * 100).toFixed(1)}</strong> · Trend: <strong>${input.chi.trend}</strong></p>
<p>${input.chi.contributors.length > 0 ? 'Drivers: ' + input.chi.contributors.map(safe).join(', ') : 'No major drivers flagged.'}</p>
</div>

<div class="section">
<h2>Barrier</h2>
<p>Score: <strong>${(input.barrier.score * 100).toFixed(1)}</strong></p>
<p>${input.barrier.drivers.length > 0 ? 'Drivers: ' + input.barrier.drivers.map(safe).join(', ') : 'No barrier drivers flagged.'}</p>
</div>

<div class="section">
<h2>Triggers</h2>
${
  input.triggers.factors.length > 0
    ? '<table><tr><th>Factor</th><th>Correlation</th></tr>' +
      input.triggers.factors
        .map(
          (f) =>
            `<tr><td>${safe(f.factor)}</td><td>${f.correlation.toFixed(2)}</td></tr>`
        )
        .join('') +
      '</table>'
    : '<p>Not enough data yet.</p>'
}
</div>

<div class="section">
<h2>Scans</h2>
${input.scans.length === 0 ? '<p>No face scans recorded.</p>' : '<table><tr><th>Date</th><th>Redness</th><th>Oiliness</th><th>Confidence</th></tr>' + input.scans.map((s) => `<tr><td>${safe(s.logDate)}</td><td>${safe(s.redness)}</td><td>${safe(s.oiliness)}</td><td>${safe(s.confidence)}</td></tr>`).join('') + '</table>'}
</div>

<div class="section">
<h2>Products</h2>
${input.products.length === 0 ? '<p>No products analyzed.</p>' : '<table><tr><th>Brand</th><th>Product</th><th>Verdict</th></tr>' + input.products.map((p) => `<tr><td>${safe(p.brand)}</td><td>${safe(p.productName)}</td><td>${safe(p.verdict)}</td></tr>`).join('') + '</table>'}
</div>

<div class="section">
<h2>Forecasts</h2>
${input.forecasts.length === 0 ? '<p>No forecasts generated.</p>' : '<table><tr><th>Generated</th><th>Risk</th><th>Confidence</th></tr>' + input.forecasts.map((f) => `<tr><td>${safe(f.generatedAt)}</td><td>${safe(f.overallRisk)}</td><td>${safe(f.confidence)}</td></tr>`).join('') + '</table>'}
</div>

<div class="section">
<h2>Evidence</h2>
${input.evidence.length === 0 ? '<p>No bookmarks.</p>' : '<ul>' + input.evidence.map((e) => `<li>${safe(e.title)} ${e.url ? `<a href="${safe(e.url)}">[link]</a>` : ''}</li>`).join('') + '</ul>'}
</div>

<div class="section">
<h2>Clinical Summary</h2>
<p>${safe(input.llmSummary.summary ?? 'AI summary unavailable.')}</p>
<h3>Key Findings</h3>
<ul>${(input.llmSummary.keyFindings ?? []).map((s) => `<li>${safe(s)}</li>`).join('')}</ul>
<h3>Recommendations</h3>
<ul>${(input.llmSummary.recommendations ?? []).map((s) => `<li>${safe(s)}</li>`).join('')}</ul>
</div>

<p style="margin-top:32px;font-size:12px;color:#666">Generated by AcneTrex v3 · ${new Date().toISOString()}</p>
</body></html>`;
}