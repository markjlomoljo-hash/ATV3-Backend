// CutisAI assistant page.
// Real conversational surface backed by the assistant engine with retrieval.

import { useEffect, useRef, useState } from 'react';
import { Send, Sparkles, ThumbsDown, ThumbsUp } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, ErrorState } from '../../components/shared/EmptyState';
import { askAssistant, recordFeedback } from '../../lib/ai/assistant';
import { AssistantMessageEntity, EvidenceBookmarkEntity } from '../../lib/api/entityDefs';
import { useConsent } from '../../hooks/useConsent';
import { LIMITS } from '../../lib/constants/dataThresholds';
import {
  SleepLogEntity,
  StressLogEntity,
  FoodLogEntity,
  HydrationLogEntity,
  FaceScanEntity,
  ForecastEntity,
  OnboardingProfileEntity,
} from '../../lib/api/entityDefs';
import { format, subDays } from 'date-fns';
import { cn } from '../../utils/cn';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  citations?: { title: string; source?: string; url?: string }[];
  confidence?: number;
  feedback?: 'helpful' | 'unhelpful';
  uncertainty?: string;
  pending?: boolean;
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submittingRef = useRef(false);
  const listRef = useRef<HTMLDivElement | null>(null);
  const { consentStatus } = useConsent();

  useEffect(() => {
    (async () => {
      const recent = await AssistantMessageEntity.list({ limit: LIMITS.ASSISTANT_MESSAGE });
      setMessages(
        recent.records
          .slice()
          .reverse()
          .map((r) => ({
            id: r.id as string,
            role: r.role as 'user' | 'assistant',
            content: r.content as string,
            citations: r.citations as { title: string; source?: string; url?: string }[] | undefined,
            confidence: r.confidence as number | undefined,
            feedback: r.feedback as 'helpful' | 'unhelpful' | undefined,
          }))
      );
    })();
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  async function send() {
    const text = input.trim();
    if (!text || submittingRef.current) return;
    submittingRef.current = true;
    setRunning(true);
    setError(null);
    setInput('');
    const tempId = 'pending-' + Date.now();
    setMessages((m) => [
      ...m,
      { id: tempId, role: 'user', content: text },
      { id: 'pending-' + Date.now() + '-a', role: 'assistant', content: '', pending: true },
    ]);
    try {
      const ctx = await buildContext();
      const result = await askAssistant(text, conversationId ?? undefined, ctx);
      setConversationId(result.conversationId);
      setMessages((m) =>
        m
          .filter((x) => !x.pending)
          .concat([
            {
              id: result.messageId,
              role: 'assistant',
              content: result.answer,
              citations: result.citations,
              confidence: result.confidence,
              uncertainty: result.uncertainty,
            },
          ])
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Assistant failed.');
      setMessages((m) => m.filter((x) => !x.pending));
    } finally {
      submittingRef.current = false;
      setRunning(false);
    }
  }

  async function feedback(msg: Message, value: 'helpful' | 'unhelpful') {
    if (msg.role !== 'assistant' || msg.id.startsWith('pending')) return;
    await recordFeedback(msg.id, value);
    setMessages((m) => m.map((x) => (x.id === msg.id ? { ...x, feedback: value } : x)));
  }

  return (
    <div className="bg-surface-muted flex min-h-screen flex-col pb-28">
      <TopBar title="CutisAI" />
      <div className="mx-auto flex w-full max-w-xl flex-1 flex-col px-4 py-4">
        <div className="card-soft mb-3 flex items-center gap-3 p-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary-500 text-white">
            <Sparkles className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-ink-900">CutisAI assistant</p>
            <p className="text-xs text-ink-500">
              Privacy: {consentStatus === 'granted' ? 'cohort learning on' : 'private'}. Citations from your evidence vault.
            </p>
          </div>
        </div>

        {messages.length === 0 && (
          <EmptyState
            icon={Sparkles}
            title="Ask CutisAI anything"
            description="Explain your scores, compare products, or get cautious guidance. Sources are cited when available."
          />
        )}

        <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto pb-2">
          <AnimatePresence initial={false}>
            {messages.map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={cn(
                  'max-w-[88%] rounded-2xl px-4 py-3 text-sm shadow-sm',
                  m.role === 'user'
                    ? 'ml-auto bg-primary-500 text-white'
                    : 'mr-auto bg-white text-ink-900'
                )}
              >
                {m.pending ? (
                  <span className="inline-flex items-center gap-1 text-ink-400">
                    <span className="h-2 w-2 animate-bounce rounded-full bg-primary-500 [animation-delay:-0.3s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-primary-500 [animation-delay:-0.15s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-primary-500" />
                  </span>
                ) : (
                  <div className="space-y-2">
                    <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
                    {m.uncertainty && (
                      <p className="text-xs text-ink-400">Uncertainty: {m.uncertainty}</p>
                    )}
                    {m.citations && m.citations.length > 0 && (
                      <div className="rounded-xl bg-surface-soft p-2 text-xs">
                        <p className="font-semibold text-ink-700">Citations</p>
                        <ul className="mt-1 space-y-1">
                          {m.citations.map((c, i) => (
                            <li key={i} className="text-ink-500">
                              {c.title}
                              {c.url && (
                                <a className="ml-1 text-primary-700 underline" href={c.url} target="_blank" rel="noreferrer">
                                  open
                                </a>
                              )}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {m.role === 'assistant' && (
                      <div className="flex items-center gap-1 text-xs text-ink-400">
                        <button
                          onClick={() => feedback(m, 'helpful')}
                          className={cn('rounded-full p-1', m.feedback === 'helpful' && 'bg-success-50 text-success-600')}
                        >
                          <ThumbsUp className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => feedback(m, 'unhelpful')}
                          className={cn('rounded-full p-1', m.feedback === 'unhelpful' && 'bg-flare-50 text-flare-600')}
                        >
                          <ThumbsDown className="h-3.5 w-3.5" />
                        </button>
                        {typeof m.confidence === 'number' && (
                          <span className="ml-1 text-[10px]">conf {Math.round(m.confidence * 100)}%</span>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
          {error && <ErrorState description={error} onRetry={send} />}
        </div>

        <div className="mt-3 flex items-center gap-2 rounded-full border border-surface-soft bg-white p-2 shadow-sm">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your skin, products, or routine…"
            className="touch flex-1 bg-transparent px-2 text-sm text-ink-900 placeholder:text-ink-400 focus:outline-none"
            onKeyDown={(e) => {
              if (e.key === 'Enter') send();
            }}
            disabled={running}
          />
          <button
            onClick={send}
            disabled={running || !input.trim()}
            className="touch flex h-10 w-10 items-center justify-center rounded-full bg-primary-500 text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

async function buildContext() {
  const cutoff = format(subDays(new Date(), 7), 'yyyy-MM-dd');
  const [sleep, stress, food, hydration, scans, forecasts, evidence, profile] = await Promise.all([
    SleepLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: 10 }),
    StressLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: 10 }),
    FoodLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: 10 }),
    HydrationLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: 10 }),
    FaceScanEntity.list({ limit: 3 }),
    ForecastEntity.list({ limit: 1 }),
    EvidenceBookmarkEntity.list({ limit: 5 }),
    OnboardingProfileEntity.list({ limit: 1 }),
  ]);

  return {
    profileSummary:
      profile.records[0]
        ? `Skin ${profile.records[0].skinType ?? '?'}, severity ${profile.records[0].acneSeverity ?? '?'}, age ${profile.records[0].ageRange ?? '?'}, concerns ${(profile.records[0].concerns ?? []).join(', ') || 'none'}`
        : 'No profile on file.',
    recentLogsSummary: `Sleep avg ${avg(sleep.records.map((r) => r.hours as number))}h · Stress avg ${avg(stress.records.map((r) => r.level as number))}/10 · Hydration avg ${avg(hydration.records.map((r) => r.waterLiters as number))}L · Food: dairy ${food.records.filter((r) => r.dairyLevel === 'high' || r.dairyLevel === 'medium').length} days`,
    recentFaceScanSummary:
      scans.records[0]
        ? `Last scan ${scans.records[0].logDate}: redness=${scans.records[0].redness} oil=${scans.records[0].oiliness} confidence=${scans.records[0].confidence}`
        : 'No scans',
    recentForecastSummary:
      forecasts.records[0]
        ? `Latest risk ${forecasts.records[0].overallRisk} conf ${forecasts.records[0].confidence}`
        : 'No forecast',
    evidenceSnippets: evidence.records.slice(0, 5).map((e) => ({
      title: e.title as string,
      source: e.journal as string | undefined,
      url: e.url as string | undefined,
      snippet: (e.abstract as string | undefined) ?? 'No abstract available.',
    })),
    recentTurns: [],
  };
}

function avg(xs: number[]) {
  if (xs.length === 0) return 0;
  return (xs.reduce((s, x) => s + x, 0) / xs.length).toFixed(1);
}