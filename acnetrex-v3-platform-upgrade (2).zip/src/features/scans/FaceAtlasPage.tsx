// FaceAtlas page.
// Multi-photo capture flow with state machine, camera lifecycle,
// compression, AI analysis, persistence, and downstream effects.

import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, CheckCircle2, Loader2, RefreshCw, Sparkles, X } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, ErrorState, InsufficientDataState } from '../../components/shared/EmptyState';
import { analyzeFace } from '../../lib/ai/face';
import { captureFromVideo, classifyCameraError, compressDataUrl, openCameraStream, stopStream } from '../../lib/ai/imageUtil';
import { FaceScanEntity } from '../../lib/api/entityDefs';
import { getSession } from '../../lib/api/session';
import { LIMITS } from '../../lib/constants/dataThresholds';
import { useConsent } from '../../hooks/useConsent';
import { SKIN_TWIN_MIN_SCANS } from '../../lib/constants/dataThresholds';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../../utils/cn';

const CAPTURE_STATES = {
  IDLE: 'IDLE',
  CAMERA_OPEN: 'CAMERA_OPEN',
  CAPTURING: 'CAPTURING',
  REVIEWING: 'REVIEWING',
  UPLOADING: 'UPLOADING',
  COMPLETE: 'COMPLETE',
  ERROR: 'ERROR',
} as const;
type CaptureState = (typeof CAPTURE_STATES)[keyof typeof CAPTURE_STATES];

const ANGLES = ['Front', 'Left 45°', 'Right 45°', 'Forehead', 'Chin'] as const;

export default function FaceAtlasPage() {
  const navigate = useNavigate();
  const { canContributeToNetwork } = useConsent();
  const [phase, setPhase] = useState<CaptureState>('IDLE');
  const [angleIndex, setAngleIndex] = useState(0);
  const [photos, setPhotos] = useState<string[]>(Array(5).fill(''));
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [resultId, setResultId] = useState<string | null>(null);
  const [historyCount, setHistoryCount] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const submittingRef = useRef(false);

  useEffect(() => {
    if (!getSession()) navigate('/auth', { replace: true });
  }, [navigate]);

  useEffect(() => {
    (async () => {
      const list = await FaceScanEntity.list({ limit: LIMITS.FACE_SCAN });
      setHistoryCount(list.total);
    })();
  }, [resultId]);

  useEffect(() => {
    return () => {
      stopStream(stream);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startCamera = useCallback(async () => {
    setError(null);
    setPhase('CAMERA_OPEN');
    try {
      const s = await openCameraStream();
      setStream(s);
      const v = videoRef.current;
      if (v) {
        v.srcObject = s;
        await v.play().catch(() => {});
      }
    } catch (e) {
      const cls = classifyCameraError(e);
      setError(cls.message);
      setPhase('ERROR');
    }
  }, []);

  const capture = useCallback(async () => {
    if (!videoRef.current) return;
    if (angleIndex >= ANGLES.length) return;
    setPhase('CAPTURING');
    try {
      const dataUrl = await captureFromVideo(videoRef.current);
      const compressed = await compressDataUrl(dataUrl);
      const next = [...photos];
      next[angleIndex] = compressed.dataUrl;
      setPhotos(next);
      if (angleIndex < ANGLES.length - 1) {
        setAngleIndex(angleIndex + 1);
        setPhase('CAMERA_OPEN');
      } else {
        setPhase('REVIEWING');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Capture failed.');
      setPhase('ERROR');
    }
  }, [angleIndex, photos]);

  const retake = useCallback(
    (i: number) => {
      const next = [...photos];
      next[i] = '';
      setPhotos(next);
      setAngleIndex(i);
      setPhase('CAMERA_OPEN');
    },
    [photos]
  );

  const submit = useCallback(async () => {
    if (submittingRef.current) return;
    if (photos.some((p) => !p)) {
      setError('All five angles are required.');
      return;
    }
    submittingRef.current = true;
    setPhase('UPLOADING');
    setError(null);
    try {
      const saved = await analyzeFace({
        photoFront: photos[0],
        photoLeft: photos[1],
        photoRight: photos[2],
        photoForehead: photos[3],
        photoChin: photos[4],
      });
      setResultId(saved.id);
      setPhase('COMPLETE');
      stopStream(stream);
      setStream(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Analysis failed.');
      setPhase('ERROR');
    } finally {
      submittingRef.current = false;
    }
  }, [photos, stream]);

  const reset = useCallback(() => {
    stopStream(stream);
    setStream(null);
    setPhotos(Array(5).fill(''));
    setAngleIndex(0);
    setPhase('IDLE');
    setResultId(null);
    setError(null);
  }, [stream]);

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="FaceAtlas" />

      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-ink-900">Five-angle skin scan</h2>
              <p className="text-xs text-ink-500">
                Capture front, left 45°, right 45°, forehead, and chin. Photos are analyzed in-app.
              </p>
            </div>
          </div>
          {historyCount < SKIN_TWIN_MIN_SCANS && (
            <div className="mt-3 rounded-xl bg-surface-soft p-3 text-xs text-ink-500">
              Skin Twin Lab unlocks at {SKIN_TWIN_MIN_SCANS} scans. You have {historyCount}.
            </div>
          )}
          {!canContributeToNetwork && (
            <div className="mt-3 rounded-xl bg-surface-soft p-3 text-xs text-ink-500">
              Photos remain private. Cohort learning is off until you opt in.
            </div>
          )}
        </div>

        <div className="card-soft overflow-hidden">
          <AnimatePresence mode="wait">
            {phase === 'IDLE' && (
              <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-5">
                <p className="text-sm text-ink-700">
                  Set up in a well-lit space. Look directly at the camera, remove glasses and makeup if possible.
                </p>
                <button
                  onClick={startCamera}
                  className="touch mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600"
                >
                  <Camera className="h-4 w-4" /> Start scan
                </button>
              </motion.div>
            )}

            {(phase === 'CAMERA_OPEN' || phase === 'CAPTURING') && (
              <motion.div key="cam" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="bg-black">
                <div className="relative aspect-[4/3] w-full">
                  <video
                    ref={videoRef}
                    className="absolute inset-0 h-full w-full object-cover"
                    autoPlay
                    playsInline
                    muted
                  />
                  <div className="absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1 text-xs font-medium text-white">
                    {ANGLES[angleIndex]} ({angleIndex + 1}/5)
                  </div>
                  <button
                    onClick={() => {
                      stopStream(stream);
                      setStream(null);
                      setPhase('IDLE');
                    }}
                    className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full bg-black/60 text-white"
                    aria-label="Close camera"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="flex items-center justify-between gap-2 bg-white p-3">
                  <div className="flex gap-1">
                    {photos.map((p, i) => (
                      <span
                        key={i}
                        className={cn(
                          'h-2 w-6 rounded-full transition',
                          p ? 'bg-primary-500' : i === angleIndex ? 'bg-accent-400' : 'bg-surface-soft'
                        )}
                      />
                    ))}
                  </div>
                  <button
                    onClick={capture}
                    disabled={phase === 'CAPTURING'}
                    className="touch flex items-center gap-2 rounded-full bg-primary-500 px-5 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-60"
                  >
                    {phase === 'CAPTURING' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                    Capture {ANGLES[angleIndex]}
                  </button>
                </div>
              </motion.div>
            )}

            {phase === 'REVIEWING' && (
              <motion.div key="review" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-5">
                <p className="text-sm text-ink-700">Review each angle. Tap a tile to retake.</p>
                <div className="mt-3 grid grid-cols-5 gap-2">
                  {photos.map((p, i) => (
                    <button
                      key={i}
                      onClick={() => retake(i)}
                      className="relative aspect-[3/4] overflow-hidden rounded-xl border border-surface-soft bg-surface-soft"
                    >
                      {p ? (
                        <img src={p} alt={`angle-${i}`} className="absolute inset-0 h-full w-full object-cover" />
                      ) : (
                        <Camera className="absolute inset-0 m-auto h-6 w-6 text-ink-400" />
                      )}
                      <span className="absolute bottom-0 left-0 right-0 bg-black/55 px-1 py-0.5 text-[10px] font-medium text-white">
                        {ANGLES[i]}
                      </span>
                    </button>
                  ))}
                </div>
                <button
                  onClick={submit}
                  className="touch mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600"
                >
                  <Sparkles className="h-4 w-4" /> Analyze my skin
                </button>
              </motion.div>
            )}

            {phase === 'UPLOADING' && (
              <motion.div key="upload" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center gap-2 p-10 text-sm text-ink-500">
                <Loader2 className="h-7 w-7 animate-spin text-primary-500" />
                Analyzing your skin…
              </motion.div>
            )}

            {phase === 'COMPLETE' && (
              <motion.div key="complete" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-5">
                <div className="flex items-center gap-2 text-success-600">
                  <CheckCircle2 className="h-5 w-5" />
                  <h3 className="text-base font-semibold">Analysis complete</h3>
                </div>
                <p className="mt-1 text-sm text-ink-500">
                  Your scan is saved with confidence, model version, and source context.
                </p>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => navigate(`/intelligence`)}
                    className="touch rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600"
                  >
                    Open Intelligence
                  </button>
                  <button
                    onClick={reset}
                    className="touch rounded-full border border-primary-200 px-4 py-3 text-sm font-semibold text-primary-700 hover:bg-primary-50"
                  >
                    Run another scan
                  </button>
                </div>
              </motion.div>
            )}

            {phase === 'ERROR' && (
              <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-5">
                <ErrorState
                  title="Scan could not continue"
                  description={error ?? 'Camera unavailable or analysis failed.'}
                  onRetry={() => {
                    setError(null);
                    setPhase('IDLE');
                  }}
                />
                <button onClick={reset} className="touch mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-primary-200 px-4 py-3 text-sm font-semibold text-primary-700">
                  <RefreshCw className="h-4 w-4" /> Reset
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {historyCount > 0 && historyCount < SKIN_TWIN_MIN_SCANS && (
          <InsufficientDataState
            moduleName="Skin Twin Lab"
            requiredDataPoints={SKIN_TWIN_MIN_SCANS}
            currentDataPoints={historyCount}
            ctaLabel="Run another scan"
            ctaRoute="/face-atlas"
          />
        )}

        {historyCount === 0 && (
          <EmptyState
            icon={Camera}
            title="No scans yet"
            description="Run your first FaceAtlas scan to populate Skin Twin and CHI."
            ctaLabel="Start scan"
            ctaRoute="/face-atlas"
          />
        )}
      </div>
    </div>
  );
}