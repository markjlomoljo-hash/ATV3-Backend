// Forecast page.
// Real forecasting engine output with confidence, contributors, and trends.

import { useEffect, useRef, useState } from 'react';
import { Sparkles, RefreshCw, BarChart3, AlertTriangle } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';
import { EmptyState, ErrorState, InsufficientDataState } from '../../components/shared/EmptyState';
import { generateForecast } from '../../lib/ai/forecast';
import { FORECAST_MIN_DAYS } from '../../lib/constants/dataThresholds';
import {
  SleepLogEntity,
  FoodLogEntity,
  StressLogEntity,
  HydrationLogEntity,
  SymptomLogEntity,
  ForecastEntity,
} from '../../lib/api/entityDefs';
import { format, subDays } from 'date-fns';
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { z } from 'zod';

const forecastPreviewSchema = z.object({
  id: z.string(),
  generatedAt: z.string(),
  overallRisk: z.number(),
  confidence: z.number(),
  contributors: z.array(z.object({ factor: z.string(), impact: z.number(), rationale: z.string() })),
  daily: z.array(z.object({ date: z.string(), risk: z.number(), confidence: z.number() })),
  horizonDays: z.number(),
  modelVersion: z.string(),
  validationStatus: z.enum(['valid', 'invalid', 'insufficient']),
});

export default function ForecastPage() {
  const [running, setRunning] = useState(false);
  const submittingRef = useRef(false);
  const [error, setError] = useState<string | null>(null);
  const [daysLogged, setDaysLogged] = useState(0);
  const [latest, setLatest] = useState<z.infer<typeof forecastPreviewSchema> | null>(null);

  useEffect(() => {
    (async () => {
      const cutoff = format(subDays(new Date(), FORECAST_MIN_DAYS + 7), 'yyyy-MM-dd');
      const [sleep, food, stress, hydration, symptoms] = await Promise.all([
        SleepLogEntity.list({ limit: 50 }),
        FoodLogEntity.list({ limit: 50 }),
        StressLogEntity.list({ limit: 50 }),
        HydrationLogEntity.list({ limit: 50 }),
        SymptomLogEntity.list({ limit: 50 }),
      ]);
      const set = new Set<string>();
      [sleep, food, stress, hydration, symptoms].forEach((res) => {
        for (const r of res.records) {
          if ((r.logDate as string) >= cutoff) set.add(r.logDate as string);
        }
      });
      setDaysLogged(set.size);

      const forecasts = await ForecastEntity.list({ limit: 5 });
      if (forecasts.records.length > 0) {
        const parsed = forecastPreviewSchema.safeParse(forecasts.records[0]);
        if (parsed.success) setLatest(parsed.data);
      }
    })();
  }, []);

  async function runForecast() {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setRunning(true);
    setError(null);
    try {
      const saved = await generateForecast({ horizonDays: 7 });
      const parsed = forecastPreviewSchema.safeParse(saved);
      if (parsed.success) setLatest(parsed.data);
      else setError('Forecast returned an unexpected shape.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Forecast failed.');
    } finally {
      submittingRef.current = false;
      setRunning(false);
    }
  }

  const sufficient = daysLogged >= FORECAST_MIN_DAYS;

  return (
    <div className="bg-surface-muted min-h-screen pb-28">
      <TopBar title="Forecast" />
      <div className="mx-auto max-w-xl space-y-4 px-4 py-4">
        <div className="card-soft p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-500 text-white">
              <BarChart3 className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-ink-900">7-day skin horizon</h2>
              <p className="text-xs text-ink-500">
                Combines your logs, scans, products, and weather into a calibrated forecast.
              </p>
            </div>
          </div>
          <button
            onClick={runForecast}
            disabled={running || !sufficient}
            className="touch mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-primary-500 px-4 py-3 text-sm font-semibold text-white shadow-sm shadow-primary-200 hover:bg-primary-600 disabled:opacity-60"
          >
            {running ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            {running ? 'Generating…' : 'Generate forecast'}
          </button>
          {!sufficient && (
            <p className="mt-2 text-xs text-ink-500">
              You have {daysLogged} day(s) of data. Need {FORECAST_MIN_DAYS}.
            </p>
          )}
        </div>

        {error && <ErrorState description={error} onRetry={runForecast} />}

        {!sufficient && (
          <InsufficientDataState
            moduleName="Forecast"
            requiredDataPoints={FORECAST_MIN_DAYS}
            currentDataPoints={daysLogged}
            ctaLabel="Log sleep"
            ctaRoute="/log/sleep"
          />
        )}

        {sufficient && !latest && (
          <EmptyState
            icon={BarChart3}
            title="No forecast yet"
            description="Generate your first 7-day forecast to see contributing factors and risk."
            ctaLabel="Generate"
            ctaRoute="/forecast"
          />
        )}

        {latest && (
          <>
            <div className="card-soft p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-ink-400">
                    Overall risk
                  </p>
                  <p className="mt-1 text-3xl font-bold text-ink-900">
                    {Math.round(latest.overallRisk * 100)}
                    <span className="text-base font-medium text-ink-400">/100</span>
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-ink-500">Confidence</p>
                  <p className="text-base font-semibold text-ink-900">
                    {Math.round(latest.confidence * 100)}%
                  </p>
                  <p className="text-[10px] text-ink-400">model {latest.modelVersion}</p>
                </div>
              </div>
              <div className="mt-4 h-40">
                <ResponsiveContainer>
                  <AreaChart data={latest.daily}>
                    <defs>
                      <linearGradient id="riskFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#7c6ee6" stopOpacity={0.4} />
                        <stop offset="100%" stopColor="#7c6ee6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eef0f4" />
                    <XAxis dataKey="date" tickLine={false} axisLine={false} fontSize={10} />
                    <YAxis tickLine={false} axisLine={false} fontSize={10} domain={[0, 1]} />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="risk"
                      stroke="#7c6ee6"
                      fill="url(#riskFill)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="card-soft p-5">
              <h3 className="text-sm font-semibold text-ink-900">Contributing factors</h3>
              <ul className="mt-3 space-y-2">
                {latest.contributors.slice(0, 6).map((c, i) => (
                  <li
                    key={i}
                    className="flex items-start justify-between gap-3 rounded-xl bg-surface-soft p-3 text-sm"
                  >
                    <div>
                      <p className="font-semibold text-ink-900">{c.factor}</p>
                      <p className="text-xs text-ink-500">{c.rationale}</p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-semibold ${
                        c.impact > 0
                          ? 'bg-flare-50 text-flare-600'
                          : 'bg-success-50 text-success-600'
                      }`}
                    >
                      {c.impact > 0 ? '+' : ''}
                      {c.impact.toFixed(2)}
                    </span>
                  </li>
                ))}
                {latest.contributors.length === 0 && (
                  <li className="text-sm text-ink-500">
                    <AlertTriangle className="mr-1 inline h-4 w-4 text-ink-400" />
                    No major contributors identified.
                  </li>
                )}
              </ul>
            </div>

            <div className="card-soft p-5">
              <h3 className="text-sm font-semibold text-ink-900">What-If simulator</h3>
              <p className="mt-1 text-xs text-ink-500">
                Open Skin Twin Lab to model counterfactual interventions on this forecast.
              </p>
              <a
                href="/skin-twin"
                className="mt-3 inline-flex touch items-center justify-center gap-1 rounded-full border border-primary-200 px-5 py-2.5 text-sm font-semibold text-primary-700 hover:bg-primary-50"
              >
                Open Skin Twin
              </a>
            </div>
          </>
        )}
      </div>
    </div>
  );
}