import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Menu } from 'lucide-react';
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../../utils/cn';

export function TopBar({ title, back = true }: { title: string; back?: boolean }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  return (
    <header className="sticky top-0 z-20 border-b border-surface-soft bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-xl items-center gap-2 px-3 py-3">
        {back ? (
          <button
            onClick={() => navigate(-1)}
            className="touch flex h-11 w-11 items-center justify-center rounded-full text-ink-700 hover:bg-surface-soft"
            aria-label="Back"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
        ) : (
          <span className="w-2" />
        )}
        <h1 className="flex-1 truncate text-base font-semibold text-ink-900">{title}</h1>
        <button
          onClick={() => setOpen((v) => !v)}
          className="touch flex h-11 w-11 items-center justify-center rounded-full text-ink-700 hover:bg-surface-soft"
          aria-label="Menu"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>
      {open && (
        <div className="border-t border-surface-soft bg-white">
          <ul className="mx-auto grid max-w-xl grid-cols-2 gap-1 p-3 text-sm">
            {[
              { to: '/', label: 'Home' },
              { to: '/intelligence', label: 'Intelligence' },
              { to: '/face-atlas', label: 'FaceAtlas' },
              { to: '/forecast', label: 'Forecast' },
              { to: '/triggers', label: 'TriggerGraph' },
              { to: '/barrier', label: 'BarrierGuard' },
              { to: '/products', label: 'FormulaLens' },
              { to: '/research', label: 'DermVault' },
              { to: '/skin-twin', label: 'SkinTwin' },
              { to: '/sleep', label: 'SleepDerm' },
              { to: '/diet', label: 'DermDiet' },
              { to: '/activity', label: 'SweatFlow' },
              { to: '/cycle', label: 'CycleSync' },
              { to: '/contact', label: 'ContactGuard' },
              { to: '/climate', label: 'ClimateSkin' },
              { to: '/reports', label: 'Reports' },
              { to: '/ai', label: 'CutisAI' },
              { to: '/profile', label: 'Profile' },
            ].map((it) => (
              <li key={it.to}>
                <Link
                  to={it.to}
                  onClick={() => setOpen(false)}
                  className={cn(
                    'block rounded-lg px-3 py-2 hover:bg-surface-soft',
                    loc.pathname === it.to ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-ink-700'
                  )}
                >
                  {it.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}