import { Activity, Brain, Database, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { getCoreStatus } from '../../lib/ai/intelligenceCore';

export function AIStatusStrip() {
  const [status, setStatus] = useState<{
    activeUsers: number;
    consentGranted: boolean;
    lastInferenceAt: string | null;
    inferenceCount24h: number;
    evidenceRetrievals24h: number;
    recentFailures: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const s = await getCoreStatus();
        if (active) {
          setStatus(s);
          setLoading(false);
        }
      } catch {
        if (active) setLoading(false);
      }
    };
    load();
    const id = setInterval(load, 30_000);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, []);

  if (loading) {
    return (
      <div className="card-soft flex items-center gap-2 p-3 text-sm text-ink-500">
        <Brain className="h-4 w-4 animate-pulse" />
        Checking AI core…
      </div>
    );
  }
  if (!status) return null;

  const lastAgo = status.lastInferenceAt ? minutesAgo(status.lastInferenceAt) : null;

  return (
    <div className="card-soft grid grid-cols-2 gap-2 p-3 text-xs sm:grid-cols-4">
      <Stat icon={Activity} label="Inferences 24h" value={String(status.inferenceCount24h)} />
      <Stat icon={Database} label="Evidence 24h" value={String(status.evidenceRetrievals24h)} />
      <Stat icon={ShieldCheck} label="Consent" value={status.consentGranted ? 'Granted' : 'Off'} />
      <Stat
        icon={Brain}
        label="Last activity"
        value={lastAgo !== null ? `${lastAgo}m ago` : 'idle'}
      />
    </div>
  );
}

function minutesAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  return Math.max(0, Math.round(diff / 60000));
}

function Stat({ icon: Icon, label, value }: { icon: typeof Activity; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-surface-soft px-3 py-2">
      <Icon className="h-4 w-4 text-primary-600" />
      <div>
        <div className="text-[10px] uppercase tracking-wide text-ink-400">{label}</div>
        <div className="text-sm font-semibold text-ink-900">{value}</div>
      </div>
    </div>
  );
}