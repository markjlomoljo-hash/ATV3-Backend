import { Link } from 'react-router-dom';
import type { LucideIcon } from 'lucide-react';
import { ChevronRight } from 'lucide-react';

export interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  ctaLabel?: string;
  ctaRoute?: string;
}

export function EmptyState({ icon: Icon, title, description, ctaLabel, ctaRoute }: EmptyStateProps) {
  return (
    <div className="card-soft p-8 text-center">
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
        <Icon className="h-7 w-7" />
      </div>
      <h3 className="text-base font-semibold text-ink-900">{title}</h3>
      <p className="mx-auto mt-2 max-w-sm text-sm text-ink-500">{description}</p>
      {ctaLabel && ctaRoute && (
        <Link
          to={ctaRoute}
          className="mt-5 inline-flex touch items-center justify-center gap-1 rounded-full bg-primary-500 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-primary-200 transition hover:bg-primary-600 active:scale-[0.99]"
        >
          {ctaLabel} <ChevronRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}

export interface InsufficientDataStateProps {
  moduleName: string;
  requiredDataPoints: number;
  currentDataPoints: number;
  ctaLabel?: string;
  ctaRoute?: string;
}

export function InsufficientDataState({
  moduleName,
  requiredDataPoints,
  currentDataPoints,
  ctaLabel,
  ctaRoute,
}: InsufficientDataStateProps) {
  const ratio = Math.max(0, Math.min(1, currentDataPoints / Math.max(1, requiredDataPoints)));
  return (
    <div className="card-soft p-6">
      <h3 className="text-base font-semibold text-ink-900">Building your {moduleName}</h3>
      <p className="mt-1 text-sm text-ink-500">
        We need a bit more data before the model can produce a meaningful signal.
      </p>
      <div className="mt-4">
        <div className="flex items-center justify-between text-xs font-medium text-ink-500">
          <span>
            {currentDataPoints} / {requiredDataPoints}
          </span>
          <span>{Math.round(ratio * 100)}%</span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-surface-soft">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary-500 to-accent-400 transition-all"
            style={{ width: `${ratio * 100}%` }}
          />
        </div>
      </div>
      {ctaLabel && ctaRoute && (
        <Link
          to={ctaRoute}
          className="mt-5 inline-flex touch items-center justify-center gap-1 rounded-full bg-primary-500 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-primary-200 transition hover:bg-primary-600"
        >
          {ctaLabel} <ChevronRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}

export interface ErrorStateProps {
  title?: string;
  description?: string;
  onRetry?: () => void;
}

export function ErrorState({
  title = 'Something went wrong',
  description = 'The AI service did not respond. Please try again.',
  onRetry,
}: ErrorStateProps) {
  return (
    <div className="card-soft p-6">
      <h3 className="text-base font-semibold text-flare-600">{title}</h3>
      <p className="mt-1 text-sm text-ink-500">{description}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 inline-flex touch items-center justify-center rounded-full border border-primary-200 px-5 py-2.5 text-sm font-semibold text-primary-700 hover:bg-primary-50"
        >
          Retry
        </button>
      )}
    </div>
  );
}