import { NavLink } from 'react-router-dom';
import { Home, Activity, Sparkles, ScanLine, BarChart3 } from 'lucide-react';
import { cn } from '../../utils/cn';

const items = [
  { to: '/', label: 'Home', icon: Home },
  { to: '/intelligence', label: 'Intel', icon: Activity },
  { to: '/face-atlas', label: 'Scan', icon: ScanLine },
  { to: '/ai', label: 'CutisAI', icon: Sparkles },
  { to: '/forecast', label: 'Forecast', icon: BarChart3 },
];

export function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-surface-soft bg-white/95 backdrop-blur safe-bottom">
      <ul className="mx-auto flex max-w-xl items-stretch justify-between px-2 py-1.5">
        {items.map((it) => (
          <li key={it.to} className="flex-1">
            <NavLink
              to={it.to}
              end={it.to === '/'}
              className={({ isActive }) =>
                cn(
                  'flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1.5 text-[11px] font-medium touch',
                  isActive ? 'text-accent-600' : 'text-ink-500'
                )
              }
            >
              {({ isActive }) => (
                <>
                  <span
                    className={cn(
                      'flex h-9 w-12 items-center justify-center rounded-full transition',
                      isActive ? 'bg-accent-50' : 'bg-transparent'
                    )}
                  >
                    <it.icon className="h-5 w-5" />
                  </span>
                  <span>{it.label}</span>
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}