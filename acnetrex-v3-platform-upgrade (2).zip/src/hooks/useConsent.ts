// useConsent hook.
// Shared consent state and revocation logic. Every network-learning emit
// must consult canContributeToNetwork() before publishing.

import { useEffect, useState, useCallback } from 'react';
import { ConsentRecordEntity } from '../lib/api/entityDefs';
import { getSession } from '../lib/api/session';

export interface ConsentStatus {
  consentStatus: 'granted' | 'revoked' | 'unknown';
  canContributeToNetwork: boolean;
  revokeConsent: () => Promise<void>;
  refresh: () => Promise<void>;
}

export function useConsent(): ConsentStatus {
  const [status, setStatus] = useState<'granted' | 'revoked' | 'unknown'>('unknown');

  const refresh = useCallback(async () => {
    if (!getSession()) {
      setStatus('unknown');
      return;
    }
    const list = await ConsentRecordEntity.list({ limit: 50 });
    const cohort = list.records.find((c) => c.consentType === 'cohort_learning');
    setStatus(cohort ? (cohort.status as 'granted' | 'revoked') : 'unknown');
  }, []);

  const revokeConsent = useCallback(async () => {
    const list = await ConsentRecordEntity.list({ limit: 50 });
    const cohort = list.records.find((c) => c.consentType === 'cohort_learning');
    if (cohort) {
      await ConsentRecordEntity.update(cohort.id, {
        status: 'revoked',
        revokedAt: new Date().toISOString(),
      });
    }
    setStatus('revoked');
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return {
    consentStatus: status,
    canContributeToNetwork: status === 'granted',
    revokeConsent,
    refresh,
  };
}