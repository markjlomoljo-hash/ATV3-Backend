// FaceAtlas face analysis engine.
// Real multi-photo analysis flow with quality validation, image compression,
// vision LLM call (no internet), and persisted FaceScan record.

import { invokeWithRetry } from './invokeWithRetry';
import { buildSafePrompt } from './promptBuilder';
import { emit } from './intelligenceCore';
import { AI_MODELS } from '../constants/dataThresholds';
import { FaceScanEntity } from '../api/entityDefs';
import { getSession } from '../api/session';
import { compressDataUrl } from './imageUtil';

const FACE_SCHEMA = {
  root: {
    type: 'object',
    properties: {
      imageQualityScore: { type: 'number' },
      faceDetected: { type: 'boolean' },
      alignmentOk: { type: 'boolean' },
      redness: { type: 'number' },
      oiliness: { type: 'number' },
      dryness: { type: 'number' },
      pihPhe: { type: 'number' },
      scarVisibility: { type: 'number' },
      inflammatoryCount: { type: 'number' },
      comedonalCount: { type: 'number' },
      zoneScores: {
        type: 'object',
        additionalProperties: { type: 'number' },
      },
      confidence: { type: 'number' },
      rationale: { type: 'string' },
    },
    required: ['confidence', 'rationale', 'faceDetected'],
  },
};

export interface FaceAnalysisInput {
  photoFront: string;
  photoLeft: string;
  photoRight: string;
  photoForehead: string;
  photoChin: string;
  notes?: string;
}

export async function analyzeFace(input: FaceAnalysisInput) {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');
  await emit({ engine: 'FaceAtlas', eventType: 'inference', status: 'started' });

  const compressed = await Promise.all([
    compressDataUrl(input.photoFront),
    compressDataUrl(input.photoLeft),
    compressDataUrl(input.photoRight),
    compressDataUrl(input.photoForehead),
    compressDataUrl(input.photoChin),
  ]);

  const fileUrls = compressed.map((d) => d.dataUrl);

  const { prompt } = buildSafePrompt(
    [
      {
        key: 'system',
        content:
          'You are FaceAtlas, a multi-photo skin analysis engine. Five photos (front, left 45°, right 45°, forehead, chin) are attached. Compute per-zone scores (0..1), lesion counts, redness, oiliness, dryness, PIH/PHE, scar visibility. If face is not visible in a photo, set faceDetected=false. Output JSON only.',
        priority: 0,
      },
      { key: 'notes', content: input.notes ?? '(no notes)', priority: 1 },
    ],
    2_000
  );

  const outcome = await invokeWithRetry({
    prompt,
    model: AI_MODELS.FACE_ANALYSIS,
    fileUrls,
    responseJsonSchema: FACE_SCHEMA,
  });

  if (!outcome.ok) {
    await emit({ engine: 'FaceAtlas', eventType: 'inference', status: 'failed', message: outcome.error });
    throw new Error(outcome.error);
  }

  const parsed = outcome.parsed;
  const confidence = clamp01(Number(parsed.confidence ?? 0));
  const validationStatus =
    parsed.faceDetected === false
      ? 'invalid'
      : confidence >= 0.6
      ? 'valid'
      : confidence >= 0.4
      ? 'insufficient'
      : 'invalid';

  const saved = await FaceScanEntity.create({
    logDate: new Date().toISOString().slice(0, 10),
    photoFront: compressed[0].dataUrl,
    photoLeft: compressed[1].dataUrl,
    photoRight: compressed[2].dataUrl,
    photoForehead: compressed[3].dataUrl,
    photoChin: compressed[4].dataUrl,
    imageQualityScore: clamp01(Number(parsed.imageQualityScore ?? 0)),
    faceDetected: parsed.faceDetected === true,
    alignmentOk: parsed.alignmentOk === true,
    redness: clamp01(Number(parsed.redness ?? 0)),
    oiliness: clamp01(Number(parsed.oiliness ?? 0)),
    dryness: clamp01(Number(parsed.dryness ?? 0)),
    pihPhe: clamp01(Number(parsed.pihPhe ?? 0)),
    scarVisibility: clamp01(Number(parsed.scarVisibility ?? 0)),
    inflammatoryCount: Math.max(0, Math.round(Number(parsed.inflammatoryCount ?? 0))),
    comedonalCount: Math.max(0, Math.round(Number(parsed.comedonalCount ?? 0))),
    zoneScores: (parsed.zoneScores as Record<string, number>) ?? {},
    validationStatus,
    confidence,
    modelVersion: outcome.model,
    rationale: String(parsed.rationale ?? ''),
    notes: input.notes,
  });

  await emit({
    engine: 'FaceAtlas',
    eventType: 'inference',
    status: validationStatus === 'valid' ? 'succeeded' : 'degraded',
    confidence,
    modelVersion: outcome.model,
    metadata: { faceScanId: saved.id, validation: validationStatus },
  });

  return saved;
}

function clamp01(n: number) {
  if (Number.isNaN(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}