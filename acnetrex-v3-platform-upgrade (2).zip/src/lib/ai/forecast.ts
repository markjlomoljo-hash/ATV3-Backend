// Forecasting engine.
// Consumes real logs, scans, weather context, and prior outcomes.
// Produces structured daily forecasts, contributing factor list,
// and counterfactual scenarios. Persists as Forecast and ForecastSnapshot.

import { invokeWithRetry } from './invokeWithRetry';
import { buildSafePrompt } from './promptBuilder';
import { emit } from './intelligenceCore';
import { AI_MODELS, LIMITS } from '../constants/dataThresholds';
import { ForecastEntity, ForecastSnapshotEntity } from '../api/entityDefs';
import { getSession } from '../api/session';
import {
  SleepLogEntity,
  FoodLogEntity,
  StressLogEntity,
  ActivityLogEntity,
  HydrationLogEntity,
  CycleLogEntity,
  ContactLogEntity,
  FaceScanEntity,
  ProductScanEntity,
} from '../api/entityDefs';
import { getWeatherSummary } from './weather';

interface ForecastInput {
  horizonDays: number;
}

const FORECAST_SCHEMA = {
  root: {
    type: 'object',
    properties: {
      overallRisk: { type: 'number' },
      confidence: { type: 'number' },
      contributors: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            factor: { type: 'string' },
            impact: { type: 'number' },
            rationale: { type: 'string' },
          },
          required: ['factor', 'impact', 'rationale'],
        },
      },
      daily: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            date: { type: 'string' },
            risk: { type: 'number' },
            confidence: { type: 'number' },
          },
          required: ['date', 'risk', 'confidence'],
        },
      },
    },
    required: ['overallRisk', 'confidence', 'daily', 'contributors'],
  },
};

function summarizeLogs<T>(rows: T[], pick: (r: T) => string): string {
  if (rows.length === 0) return '(none)';
  const tail = rows.slice(0, 7).map((r) => pick(r)).join(' | ');
  return tail.slice(0, 200);
}

export async function generateForecast(input: ForecastInput = { horizonDays: 7 }) {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');
  await emit({ engine: 'Forecast', eventType: 'inference', status: 'started' });

  const [sleep, food, stress, activity, hydration, cycle, contact, scans, products, weather] =
    await Promise.all([
      SleepLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      FoodLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      StressLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      ActivityLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      HydrationLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      CycleLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      ContactLogEntity.list({ limit: LIMITS.DAILY_LOG }),
      FaceScanEntity.list({ limit: LIMITS.FACE_SCAN }),
      ProductScanEntity.list({ limit: 10 }),
      getWeatherSummary(),
    ]);

  const logSections = [
    { key: 'sleep', content: summarizeLogs(sleep.records, (r) => `${r.logDate}: ${r.hours}h q=${r.quality ?? '-'}`), priority: 2 },
    { key: 'food', content: summarizeLogs(food.records, (r) => `${r.logDate}: gi=${r.glycemicLoad ?? '-'} dairy=${r.dairyLevel ?? '-'}`), priority: 2 },
    { key: 'stress', content: summarizeLogs(stress.records, (r) => `${r.logDate}: ${r.level}/10`), priority: 2 },
    { key: 'activity', content: summarizeLogs(activity.records, (r) => `${r.logDate}: sweat=${r.sweatLevel ?? '-'} ${r.durationMinutes ?? '-'}m`), priority: 2 },
    { key: 'hydration', content: summarizeLogs(hydration.records, (r) => `${r.logDate}: ${r.waterLiters}L`), priority: 2 },
    { key: 'cycle', content: summarizeLogs(cycle.records, (r) => `${r.logDate}: ${r.phase}`), priority: 2 },
    { key: 'contact', content: summarizeLogs(contact.records, (r) => `${r.logDate}: helmet=${!!r.helmet} mask=${!!r.mask}`), priority: 2 },
    { key: 'scans', content: summarizeLogs(scans.records, (r) => `${r.logDate}: redness=${r.redness ?? '-'} infl=${r.inflammatoryCount ?? '-'}`), priority: 2 },
    { key: 'products', content: products.records.slice(0, 5).map((p) => `${p.brand} ${p.productName} verdict=${p.verdict ?? '-'}`).join(' | ').slice(0, 200) || '(none)', priority: 2 },
    { key: 'weather', content: weather, priority: 2 },
  ];

  const { prompt } = buildSafePrompt(
    [
      { key: 'system', content: 'You are the AcneTrex forecasting engine. Produce a 7-day acne-risk forecast from real user inputs. Output ONLY valid JSON per the schema. No prose.', priority: 0 },
      { key: 'horizon', content: `horizonDays=${input.horizonDays}`, priority: 0 },
      ...logSections,
    ],
    8_000
  );

  const outcome = await invokeWithRetry({
    prompt,
    model: AI_MODELS.FORECAST,
    responseJsonSchema: FORECAST_SCHEMA,
  });

  if (!outcome.ok) {
    await emit({ engine: 'Forecast', eventType: 'inference', status: 'failed', message: outcome.error });
    throw new Error(outcome.error);
  }

  const parsed = outcome.parsed;
  const daily = Array.isArray(parsed.daily)
    ? (parsed.daily as Array<{ date: string; risk: number; confidence: number }>).slice(0, input.horizonDays)
    : [];

  const contributors = Array.isArray(parsed.contributors)
    ? (parsed.contributors as Array<{ factor: string; impact: number; rationale: string }>)
    : [];

  const confidence = clamp01(Number(parsed.confidence ?? 0));
  const overallRisk = clamp01(Number(parsed.overallRisk ?? 0));

  if (confidence < 0.3 || daily.length === 0) {
    await emit({
      engine: 'Forecast',
      eventType: 'validation',
      status: 'degraded',
      confidence,
      message: 'Forecast produced insufficient signal.',
    });
    throw new Error('Forecast confidence too low to publish.');
  }

  const saved = await ForecastEntity.create({
    generatedAt: new Date().toISOString(),
    horizonDays: input.horizonDays,
    overallRisk,
    confidence,
    contributors,
    daily,
    modelVersion: outcome.model,
    validationStatus: 'valid',
  });

  await ForecastSnapshotEntity.create({
    date: new Date().toISOString().slice(0, 10),
    horizonDays: input.horizonDays,
    points: daily,
  });

  await emit({
    engine: 'Forecast',
    eventType: 'inference',
    status: 'succeeded',
    confidence,
    modelVersion: outcome.model,
    metadata: { forecastId: saved.id, horizon: input.horizonDays },
  });

  return saved;
}

function clamp01(n: number) {
  if (Number.isNaN(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}