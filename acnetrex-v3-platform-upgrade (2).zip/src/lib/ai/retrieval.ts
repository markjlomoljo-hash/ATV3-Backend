// DermVault evidence retrieval engine.
// Internet-augmented search through the configured AI endpoint.
// Persists results as EvidenceBookmark records with source trust labels.

import { invokeWithRetry } from './invokeWithRetry';
import { buildSafePrompt } from './promptBuilder';
import { emit } from './intelligenceCore';
import { AI_MODELS } from '../constants/dataThresholds';
import { EvidenceBookmarkEntity } from '../api/entityDefs';
import { getSession } from '../api/session';

const RETRIEVAL_SCHEMA = {
  root: {
    type: 'object',
    properties: {
      results: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            authors: { type: 'string' },
            journal: { type: 'string' },
            year: { type: 'number' },
            abstract: { type: 'string' },
            url: { type: 'string' },
            sourceTrust: { type: 'string' },
            topic: { type: 'string' },
          },
          required: ['title', 'sourceTrust'],
        },
      },
    },
    required: ['results'],
  },
};

export async function searchEvidence(query: string, topic: string) {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');
  await emit({ engine: 'DermVault', eventType: 'retrieval', status: 'started', message: query });

  const { prompt } = buildSafePrompt(
    [
      {
        key: 'system',
        content:
          'You are DermVault, a dermatology evidence retrieval engine. Find relevant peer-reviewed studies and reliable sources. Output JSON only.',
        priority: 0,
      },
      { key: 'query', content: query, priority: 0 },
      { key: 'topic', content: topic, priority: 1 },
    ],
    8_000
  );

  const outcome = await invokeWithRetry({
    prompt,
    model: AI_MODELS.RESEARCH,
    addContextFromInternet: true,
    responseJsonSchema: RETRIEVAL_SCHEMA,
  });

  if (!outcome.ok) {
    await emit({ engine: 'DermVault', eventType: 'retrieval', status: 'failed', message: outcome.error });
    throw new Error(outcome.error);
  }

  const results = Array.isArray(outcome.parsed.results) ? outcome.parsed.results : [];
  const saved: unknown[] = [];
  for (const r of results as Array<Record<string, unknown>>) {
    if (typeof r.title !== 'string') continue;
    const trust = String(r.sourceTrust ?? 'unknown');
    const record = await EvidenceBookmarkEntity.create({
      title: r.title,
      authors: typeof r.authors === 'string' ? r.authors : undefined,
      journal: typeof r.journal === 'string' ? r.journal : undefined,
      year: typeof r.year === 'number' ? r.year : undefined,
      abstract: typeof r.abstract === 'string' ? r.abstract : undefined,
      url: typeof r.url === 'string' ? r.url : undefined,
      topic: typeof r.topic === 'string' ? r.topic : topic,
      sourceTrust: (['peer_reviewed', 'preprint', 'database', 'vendor', 'unknown'].includes(trust)
        ? trust
        : 'unknown') as 'peer_reviewed' | 'preprint' | 'database' | 'vendor' | 'unknown',
      bookmarkedAt: new Date().toISOString(),
    });
    saved.push(record);
  }

  await emit({
    engine: 'DermVault',
    eventType: 'retrieval',
    status: 'succeeded',
    metadata: { query, count: saved.length },
  });

  return saved;
}