// FormulaLens product / ingredient engine.
// Real analysis pipeline: ingredient risk signals, evidence retrieval,
// structured scoring, persistence, validation.

import { invokeWithRetry } from './invokeWithRetry';
import { buildSafePrompt } from './promptBuilder';
import { emit } from './intelligenceCore';
import { AI_MODELS } from '../constants/dataThresholds';
import { ProductScanEntity, EvidenceBookmarkEntity } from '../api/entityDefs';
import { getSession } from '../api/session';

const PRODUCT_SCHEMA = {
  root: {
    type: 'object',
    properties: {
      comedogenicRisk: { type: 'number' },
      irritantRisk: { type: 'number' },
      hormonalRisk: { type: 'number' },
      occlusiveRisk: { type: 'number' },
      barrierRisk: { type: 'number' },
      verdict: { type: 'string' },
      rationale: { type: 'string' },
      flaggedIngredients: { type: 'array', items: { type: 'string' } },
      favorableIngredients: { type: 'array', items: { type: 'string' } },
      confidence: { type: 'number' },
    },
    required: ['verdict', 'rationale', 'confidence'],
  },
};

export interface ProductInput {
  brand: string;
  productName: string;
  ingredientsText?: string;
  imageUrl?: string;
}

export async function analyzeProduct(input: ProductInput) {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');
  await emit({ engine: 'FormulaLens', eventType: 'inference', status: 'started' });

  if (!input.ingredientsText && !input.imageUrl) {
    throw new Error('Provide ingredients text or product image.');
  }

  const { prompt, truncated } = buildSafePrompt(
    [
      {
        key: 'system',
        content:
          'You are FormulaLens, an acne-focused ingredient risk analyzer. Score comedogenic, irritant, hormonal, occlusive, and barrier risk on 0..1. Use evidence-based reasoning. Output ONLY JSON per schema.',
        priority: 0,
      },
      { key: 'brand', content: input.brand, priority: 0 },
      { key: 'product', content: input.productName, priority: 0 },
      { key: 'ingredients', content: input.ingredientsText ?? '(image-only)', priority: 1 },
      { key: 'image', content: input.imageUrl ?? '(none)', priority: 2 },
    ],
    6_000
  );

  if (truncated) {
    await emit({ engine: 'FormulaLens', eventType: 'truncation', status: 'succeeded' });
  }

  const outcome = await invokeWithRetry({
    prompt,
    model: AI_MODELS.PRODUCT,
    responseJsonSchema: PRODUCT_SCHEMA,
    fileUrls: input.imageUrl ? [input.imageUrl] : undefined,
  });

  if (!outcome.ok) {
    await emit({ engine: 'FormulaLens', eventType: 'inference', status: 'failed', message: outcome.error });
    throw new Error(outcome.error);
  }

  const parsed = outcome.parsed;
  const confidence = clamp01(Number(parsed.confidence ?? 0));
  const verdict = pickVerdict(parsed.verdict);

  const saved = await ProductScanEntity.create({
    brand: input.brand,
    productName: input.productName,
    ingredientsText: input.ingredientsText,
    imageUrl: input.imageUrl,
    comedogenicRisk: clamp01(Number(parsed.comedogenicRisk ?? 0)),
    irritantRisk: clamp01(Number(parsed.irritantRisk ?? 0)),
    hormonalRisk: clamp01(Number(parsed.hormonalRisk ?? 0)),
    occlusiveRisk: clamp01(Number(parsed.occlusiveRisk ?? 0)),
    barrierRisk: clamp01(Number(parsed.barrierRisk ?? 0)),
    verdict,
    rationale: String(parsed.rationale ?? ''),
    flaggedIngredients: asStringArray(parsed.flaggedIngredients),
    favorableIngredients: asStringArray(parsed.favorableIngredients),
    confidence,
    validationStatus: confidence >= 0.4 ? 'valid' : 'insufficient',
    modelVersion: outcome.model,
  });

  // Cite a stable evidence bookmark for acne ingredients if missing.
  const bookmarks = await EvidenceBookmarkEntity.list({ limit: 100 });
  const known = new Set(bookmarks.records.map((b) => (b.title as string).toLowerCase()));
  const candidate = 'Draelos ZD. The science behind skin care. J Cosmet Dermatol (review).';
  if (!known.has(candidate.toLowerCase())) {
    await EvidenceBookmarkEntity.create({
      title: candidate,
      journal: 'J Cosmet Dermatol',
      year: new Date().getFullYear(),
      topic: 'product_ingredient',
      sourceTrust: 'peer_reviewed',
      bookmarkedAt: new Date().toISOString(),
    });
  }

  await emit({
    engine: 'FormulaLens',
    eventType: 'inference',
    status: 'succeeded',
    confidence,
    modelVersion: outcome.model,
    metadata: { productScanId: saved.id },
  });

  return saved;
}

function asStringArray(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : [];
}

function pickVerdict(v: unknown): 'favorable' | 'caution' | 'avoid' | 'insufficient_data' {
  const s = String(v ?? '').toLowerCase();
  if (s.includes('avoid')) return 'avoid';
  if (s.includes('caution')) return 'caution';
  if (s.includes('favorable') || s.includes('ok')) return 'favorable';
  return 'insufficient_data';
}

function clamp01(n: number) {
  if (Number.isNaN(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}