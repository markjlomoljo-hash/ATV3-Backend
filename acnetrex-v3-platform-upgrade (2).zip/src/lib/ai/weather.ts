// Weather context lookup. Real call to a configured weather endpoint.
// Falls back to a clear "unavailable" state when no key is configured.

export interface WeatherSummary {
  temperatureC: number | null;
  humidity: number | null;
  uvIndex: number | null;
  description: string | null;
  source: 'live' | 'unavailable';
}

export async function fetchWeather(): Promise<WeatherSummary> {
  const endpoint = import.meta.env.VITE_WEATHER_ENDPOINT;
  const key = import.meta.env.VITE_WEATHER_API_KEY;
  if (!endpoint || !key) return { temperatureC: null, humidity: null, uvIndex: null, description: null, source: 'unavailable' };

  try {
    const res = await fetch(`${endpoint}?key=${key}`);
    if (!res.ok) return { temperatureC: null, humidity: null, uvIndex: null, description: null, source: 'unavailable' };
    const json = await res.json();
    return {
      temperatureC: typeof json.temp === 'number' ? json.temp : null,
      humidity: typeof json.humidity === 'number' ? json.humidity : null,
      uvIndex: typeof json.uv === 'number' ? json.uv : null,
      description: typeof json.desc === 'string' ? json.desc : null,
      source: 'live',
    };
  } catch {
    return { temperatureC: null, humidity: null, uvIndex: null, description: null, source: 'unavailable' };
  }
}

export async function getWeatherSummary(): Promise<string> {
  const w = await fetchWeather();
  if (w.source === 'unavailable') return 'weather: unavailable (no key configured)';
  return `weather: ${w.temperatureC ?? '-'}C, hum=${w.humidity ?? '-'}%, uv=${w.uvIndex ?? '-'} (${w.description ?? ''})`;
}