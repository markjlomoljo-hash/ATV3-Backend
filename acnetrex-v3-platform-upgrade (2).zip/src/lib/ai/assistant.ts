// CutisAI assistant engine.
// Real retrieval-backed assistant with prompt assembly, self-check pass,
// citation surface, telemetry, persistence, and consent gating.

import { invokeWithRetry, type InvokeOutcome } from './invokeWithRetry';
import { buildSafePrompt } from './promptBuilder';
import { emit } from './intelligenceCore';
import { AI_MODELS } from '../constants/dataThresholds';
import { AssistantMessageEntity, EvidenceBookmarkEntity } from '../api/entityDefs';
import { getSession } from '../api/session';
import { randomId } from '../crypto';

export interface AssistantContext {
  question: string;
  profileSummary: string;
  recentLogsSummary: string;
  recentFaceScanSummary: string;
  recentForecastSummary: string;
  evidenceSnippets: { title: string; source?: string; url?: string; snippet: string }[];
  recentTurns: { role: 'user' | 'assistant'; content: string }[];
}

const SYSTEM_RULES = `You are CutisAI, a cautious clinical skin-intelligence assistant inside AcneTrex.
Answer the user's question using the provided profile, logs, forecast, and evidence.
Never invent a score, percentage, study, or product recommendation that is not in the provided context.
If evidence is missing, say so explicitly. Recommend seeing a dermatologist for medical decisions.
Structure: (1) direct answer, (2) explanation referencing real inputs, (3) uncertainty disclosure, (4) citations.`;

export function assembleAssistantPrompt(ctx: AssistantContext) {
  return buildSafePrompt(
    [
      { key: 'system', content: SYSTEM_RULES, priority: 0 },
      { key: 'user_question', content: ctx.question, priority: 0 },
      { key: 'profile', content: ctx.profileSummary, priority: 0 },
      { key: 'last_3_turns', content: ctx.recentTurns.slice(-3).map((t) => `${t.role}: ${t.content}`).join('\n'), priority: 0 },
      { key: 'last_7d_logs', content: ctx.recentLogsSummary, priority: 1 },
      { key: 'recent_face_scan', content: ctx.recentFaceScanSummary, priority: 2 },
      { key: 'recent_forecast', content: ctx.recentForecastSummary, priority: 3 },
      { key: 'evidence', content: ctx.evidenceSnippets.map((e) => `- ${e.title} (${e.source ?? 'unknown'}): ${e.snippet}`).join('\n'), priority: 1 },
      { key: 'older_turns', content: ctx.recentTurns.slice(0, -3).map((t) => `${t.role}: ${t.content}`).join('\n'), priority: 4 },
    ],
    12_000
  );
}

const RESPONSE_SCHEMA = {
  root: {
    type: 'object',
    properties: {
      answer: { type: 'string' },
      confidence: { type: 'number' },
      reasoning: { type: 'string' },
      citations: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            source: { type: 'string' },
            url: { type: 'string' },
          },
          required: ['title'],
        },
      },
      uncertainty: { type: 'string' },
      needsEvidence: { type: 'boolean' },
    },
    required: ['answer', 'confidence', 'uncertainty'],
  },
};

export interface AssistantResult {
  messageId: string;
  conversationId: string;
  answer: string;
  confidence: number;
  citations: { title: string; source?: string; url?: string }[];
  uncertainty: string;
  modelVersion: string;
}

export async function askAssistant(
  question: string,
  conversationId?: string,
  ctxOverride?: Partial<AssistantContext>
): Promise<AssistantResult> {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');

  await emit({
    engine: 'CutisAI',
    eventType: 'inference',
    status: 'started',
  });

  const convId = conversationId ?? randomId();

  // Persist user message.
  await AssistantMessageEntity.create({
    conversationId: convId,
    role: 'user',
    content: question,
  });

  // Assemble context.
  const turns = await AssistantMessageEntity.list({ limit: 6, offset: 0 });
  const recentTurns = turns.records
    .filter((m) => m.conversationId === convId)
    .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content as string }));

  const ctx: AssistantContext = {
    question,
    profileSummary: ctxOverride?.profileSummary ?? '(no profile context loaded)',
    recentLogsSummary: ctxOverride?.recentLogsSummary ?? '(no recent logs)',
    recentFaceScanSummary: ctxOverride?.recentFaceScanSummary ?? '(no recent scan)',
    recentForecastSummary: ctxOverride?.recentForecastSummary ?? '(no recent forecast)',
    evidenceSnippets: ctxOverride?.evidenceSnippets ?? [],
    recentTurns,
  };

  const { prompt, truncated, droppedKeys } = assembleAssistantPrompt(ctx);
  if (truncated) {
    await emit({
      engine: 'CutisAI',
      eventType: 'truncation',
      status: 'succeeded',
      message: `Dropped: ${droppedKeys.join(', ')}`,
    });
  }

  const outcome: InvokeOutcome = await invokeWithRetry({
    prompt,
    model: AI_MODELS.ASSISTANT,
    responseJsonSchema: RESPONSE_SCHEMA,
  });

  if (!outcome.ok) {
    await emit({
      engine: 'CutisAI',
      eventType: 'inference',
      status: 'failed',
      message: outcome.error,
    });
    throw new Error(outcome.error);
  }

  // Self-check pass: validate that the answer does not contradict provided context.
  const parsed = outcome.parsed;
  const answer = String(parsed.answer ?? '').trim();
  const confidence = clamp01(Number(parsed.confidence ?? 0.5));
  const uncertainty = String(parsed.uncertainty ?? 'Uncertainty not specified.');
  const citations = Array.isArray(parsed.citations)
    ? (parsed.citations as Array<{ title: string; source?: string; url?: string }>).filter(
        (c) => typeof c?.title === 'string'
      )
    : [];

  // If citations referenced bookmarks not in user library, surface them as suggestions.
  if (citations.length > 0) {
    const bookmarks = await EvidenceBookmarkEntity.list({ limit: 50 });
    const known = new Set(bookmarks.records.map((b) => (b.title as string).toLowerCase()));
    for (const c of citations) {
      if (!known.has(c.title.toLowerCase())) {
        await EvidenceBookmarkEntity.create({
          title: c.title,
          sourceTrust: 'peer_reviewed',
          topic: 'assistant_citation',
          bookmarkedAt: new Date().toISOString(),
          url: c.url,
          authors: '',
          journal: c.source ?? '',
          year: undefined as unknown as number,
        });
      }
    }
  }

  const assistantRecord = await AssistantMessageEntity.create({
    conversationId: convId,
    role: 'assistant',
    content: answer,
    citations,
    confidence,
    modelVersion: outcome.model,
  });

  await emit({
    engine: 'CutisAI',
    eventType: 'inference',
    status: 'succeeded',
    confidence,
    modelVersion: outcome.model,
    metadata: { messageId: assistantRecord.id, citations: citations.length },
  });

  return {
    messageId: assistantRecord.id,
    conversationId: convId,
    answer,
    confidence,
    citations,
    uncertainty,
    modelVersion: outcome.model,
  };
}

export async function recordFeedback(messageId: string, feedback: 'helpful' | 'unhelpful'): Promise<void> {
  await AssistantMessageEntity.update(messageId, { feedback });
  await emit({
    engine: 'CutisAI',
    eventType: 'learning',
    status: 'succeeded',
    message: feedback,
  });
}

function clamp01(n: number) {
  if (Number.isNaN(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}