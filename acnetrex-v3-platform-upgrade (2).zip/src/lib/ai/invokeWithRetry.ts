// AI invocation with timeout + single retry on timeout.
// In production this targets a Base44 InvokeLLM-style endpoint.
// In this build it targets a configurable model endpoint with graceful degradation
// when no API key is configured — returning an explicit "unavailable" outcome
// instead of fabricated content.

import { AI_MODELS } from '../constants/dataThresholds';

export type ModelName = (typeof AI_MODELS)[keyof typeof AI_MODELS] | string;

export interface InvokeParams {
  prompt: string;
  model?: ModelName;
  responseJsonSchema?: { root: Record<string, unknown> };
  addContextFromInternet?: boolean;
  fileUrls?: string[];
  temperature?: number;
}

export type InvokeOutcome =
  | { ok: true; parsed: Record<string, unknown>; raw: string; model: string; truncated: boolean }
  | { ok: false; error: string; reason: 'timeout' | 'refusal' | 'invalid_schema' | 'unavailable' };

const TIMEOUTS: Record<string, number> = {
  internet: 45_000,
  vision: 30_000,
  reasoning: 20_000,
  extraction: 10_000,
};

function pickTimeout(p: InvokeParams): number {
  if (p.fileUrls && p.fileUrls.length) return TIMEOUTS.vision;
  if (p.addContextFromInternet) return TIMEOUTS.internet;
  if (p.responseJsonSchema) return TIMEOUTS.extraction;
  return TIMEOUTS.reasoning;
}

function pickModel(p: InvokeParams): ModelName {
  if (p.model) return p.model;
  if (p.fileUrls && p.fileUrls.length) return AI_MODELS.FACE_ANALYSIS;
  if (p.addContextFromInternet) return AI_MODELS.RESEARCH;
  if (p.responseJsonSchema) return AI_MODELS.EXTRACTION;
  return AI_MODELS.ASSISTANT;
}

function isVisionOnly(p: InvokeParams): boolean {
  return Array.isArray(p.fileUrls) && p.fileUrls.length > 0;
}

function validateModelRules(p: InvokeParams): string | null {
  if (isVisionOnly(p) && p.addContextFromInternet) {
    return 'Vision calls must not include add_context_from_internet.';
  }
  if (p.addContextFromInternet) {
    const m = String(p.model ?? '');
    if (m !== AI_MODELS.RESEARCH) {
      return 'Internet-augmented calls require gemini_3_flash or gemini_3_1_pro.';
    }
  }
  if (p.responseJsonSchema && p.responseJsonSchema.root && p.responseJsonSchema.root.type !== 'object') {
    return 'response_json_schema.root must be of type object.';
  }
  return null;
}

async function fetchWithTimeout(url: string, init: RequestInit, ms: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

export async function invokeWithRetry(params: InvokeParams, overrideTimeoutMs?: number): Promise<InvokeOutcome> {
  const ruleError = validateModelRules(params);
  if (ruleError) {
    return { ok: false, error: ruleError, reason: 'invalid_schema' };
  }

  const endpoint = (import.meta.env.VITE_AI_ENDPOINT as string | undefined) ?? '';
  const apiKey = (import.meta.env.VITE_AI_API_KEY as string | undefined) ?? '';
  const timeoutMs = overrideTimeoutMs ?? pickTimeout(params);
  const model = pickModel(params);

  if (!endpoint || !apiKey) {
    return {
      ok: false,
      error: 'AI endpoint not configured. Set VITE_AI_ENDPOINT and VITE_AI_API_KEY to enable.',
      reason: 'unavailable',
    };
  }

  const body = {
    model,
    prompt: params.prompt,
    add_context_from_internet: !!params.addContextFromInternet,
    file_urls: params.fileUrls ?? [],
    response_json_schema: params.responseJsonSchema,
    temperature: params.temperature ?? 0.2,
  };

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await fetchWithTimeout(
        endpoint,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify(body),
        },
        timeoutMs
      );
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        return { ok: false, error: text || `HTTP ${res.status}`, reason: 'refusal' };
      }
      const json = await res.json();
      // Base44 contract: result is already a parsed object when response_json_schema is provided.
      const parsed =
        json && typeof json === 'object'
          ? (json.parsed ?? json.result ?? json)
          : {};
      const raw =
        typeof json?.text === 'string'
          ? json.text
          : typeof json?.raw === 'string'
          ? json.raw
          : JSON.stringify(parsed);
      return { ok: true, parsed: parsed as Record<string, unknown>, raw, model, truncated: !!json?.truncated };
    } catch (e: unknown) {
      const isTimeout =
        (e instanceof DOMException && e.name === 'AbortError') ||
        (e instanceof Error && /aborted|timeout/i.test(e.message));
      if (isTimeout && attempt === 0) {
        await new Promise((r) => setTimeout(r, 2000));
        continue;
      }
      return {
        ok: false,
        error: e instanceof Error ? e.message : 'unknown error',
        reason: isTimeout ? 'timeout' : 'refusal',
      };
    }
  }

  return { ok: false, error: 'exhausted retries', reason: 'timeout' };
}