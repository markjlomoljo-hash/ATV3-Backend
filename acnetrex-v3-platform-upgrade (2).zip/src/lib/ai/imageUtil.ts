// Image utility: extract a JPEG data URL from a <video> element,
// then iteratively compress until size <= 4MB.

const MAX_BYTES = 4 * 1024 * 1024;

export async function captureFromVideo(video: HTMLVideoElement): Promise<string> {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas not supported.');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.85);
}

export async function compressDataUrl(
  dataUrl: string,
  maxBytes = MAX_BYTES
): Promise<{ dataUrl: string; bytes: number }> {
  let quality = 0.85;
  let current = dataUrl;
  let bytes = estimateBytes(current);
  while (bytes > maxBytes && quality > 0.2) {
    quality -= 0.05;
    current = await reencode(current, quality);
    bytes = estimateBytes(current);
  }
  return { dataUrl: current, bytes };
}

function estimateBytes(dataUrl: string): number {
  const idx = dataUrl.indexOf(',');
  if (idx < 0) return dataUrl.length;
  const b64 = dataUrl.slice(idx + 1);
  return Math.floor((b64.length * 3) / 4);
}

async function reencode(dataUrl: string, quality: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas not supported.'));
        return;
      }
      ctx.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => reject(new Error('Image decode failed.'));
    img.src = dataUrl;
  });
}

export async function openCameraStream(): Promise<MediaStream> {
  const constraints: MediaStreamConstraints = {
    video: {
      facingMode: 'user',
      width: { ideal: 1280 },
      height: { ideal: 720 },
    },
    audio: false,
  };
  try {
    return await navigator.mediaDevices.getUserMedia(constraints);
  } catch (e) {
    if (e instanceof DOMException && e.name === 'OverconstrainedError') {
      return navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    }
    throw e;
  }
}

export function classifyCameraError(e: unknown): { code: 'not_allowed' | 'not_found' | 'overconstrained' | 'other'; message: string } {
  if (e instanceof DOMException) {
    if (e.name === 'NotAllowedError') return { code: 'not_allowed', message: 'Camera permission denied. Enable camera access in your settings.' };
    if (e.name === 'NotFoundError') return { code: 'not_found', message: 'No camera detected on this device.' };
    if (e.name === 'OverconstrainedError') return { code: 'overconstrained', message: 'Camera constraints could not be satisfied.' };
  }
  return { code: 'other', message: e instanceof Error ? e.message : 'Camera unavailable.' };
}

export function stopStream(stream: MediaStream | null) {
  if (!stream) return;
  for (const track of stream.getTracks()) track.stop();
}