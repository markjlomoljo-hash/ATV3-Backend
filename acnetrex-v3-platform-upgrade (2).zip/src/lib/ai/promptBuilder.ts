// Prompt builder with safe truncation. Priority order matters:
// earlier sections are kept; later sections are truncated first.

export interface PromptSection {
  key: string;
  content: string;
  priority: number; // lower = higher priority; never truncated if priority === 0
}

export function buildSafePrompt(sections: PromptSection[], maxChars: number): {
  prompt: string;
  truncated: boolean;
  droppedKeys: string[];
} {
  const sorted = [...sections].sort((a, b) => a.priority - b.priority);
  const droppedKeys: string[] = [];
  let used = 0;
  const out: string[] = [];

  // Always include priority 0 (untouchable).
  for (const s of sorted) {
    if (s.priority === 0) {
      out.push(`### ${s.key}\n${s.content}`);
      used += s.content.length + s.key.length + 5;
    }
  }

  // Allocate the rest by priority, dropping low-priority sections if needed.
  const rest = sorted.filter((s) => s.priority !== 0);
  const usable = maxChars - used;

  for (const s of rest) {
    if (used + s.content.length + s.key.length + 5 <= usable) {
      out.push(`### ${s.key}\n${s.content}`);
      used += s.content.length + s.key.length + 5;
    } else {
      const remaining = usable - used - s.key.length - 5;
      if (remaining > 100) {
        const truncated = s.content.slice(0, remaining - 30) + '... [truncated]';
        out.push(`### ${s.key}\n${truncated}`);
        used = maxChars;
        droppedKeys.push(s.key);
      } else {
        droppedKeys.push(s.key);
      }
    }
  }

  return { prompt: out.join('\n\n'), truncated: droppedKeys.length > 0, droppedKeys };
}