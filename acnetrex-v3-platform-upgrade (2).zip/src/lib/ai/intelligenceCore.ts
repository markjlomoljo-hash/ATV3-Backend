// Intelligence Core: central telemetry + state for the AI/ML layer.
// Emits IntelligenceEvent records and exposes execution state derived from real data.

import { IntelligenceEventEntity } from '../api/entityDefs';
import { APP_VERSION } from '../constants/dataThresholds';
import { getSession } from '../api/session';
import { ConsentRecordEntity } from '../api/entityDefs';
import { db } from '../storage/db';

export type EngineName =
  | 'FaceAtlas'
  | 'Forecast'
  | 'CutisAI'
  | 'FormulaLens'
  | 'DermVault'
  | 'SkinTwin'
  | 'TriggerGraph'
  | 'Barrier'
  | 'CHI';

export interface EmitInput {
  engine: EngineName;
  eventType: 'inference' | 'retrieval' | 'validation' | 'learning' | 'error' | 'milestone' | 'truncation';
  status: 'started' | 'succeeded' | 'failed' | 'degraded';
  confidence?: number;
  message?: string;
  modelVersion?: string;
  metadata?: Record<string, unknown>;
}

export async function emit(input: EmitInput): Promise<void> {
  const session = getSession();
  if (!session) return; // telemetry scoped to authenticated users
  let consentStatus: 'granted' | 'revoked' | 'unknown' = 'unknown';
  try {
    const consents = await ConsentRecordEntity.list({ limit: 50 });
    const cohort = consents.records.find((c) => c.consentType === 'cohort_learning');
    consentStatus = cohort ? (cohort.status as 'granted' | 'revoked') : 'unknown';
  } catch {
    // ignore
  }
  await IntelligenceEventEntity.create({
    eventType: input.eventType,
    engine: input.engine,
    status: input.status,
    confidence: input.confidence,
    message: input.message,
    consentStatus,
    modelVersion: input.modelVersion ?? APP_VERSION,
    metadata: input.metadata,
  });
}

export interface CoreStatus {
  activeUsers: number;
  consentGranted: boolean;
  lastInferenceAt: string | null;
  inferenceCount24h: number;
  evidenceRetrievals24h: number;
  recentFailures: number;
}

export async function getCoreStatus(): Promise<CoreStatus> {
  const session = getSession();
  const allEvents = await db.list('IntelligenceEvent', { limit: 9999 });
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  const last24 = allEvents.filter((e) => new Date(e.created_date as string).getTime() >= cutoff);

  const consents = await ConsentRecordEntity.list({ limit: 50 });
  const cohortConsent = consents.records.find((c) => c.consentType === 'cohort_learning');

  // Distinct users who have written an event in the last 30 days, from the audit trail.
  const allUsers = await db.list('User', { limit: 9999 });
  const activeUserIds = new Set<string>();
  for (const u of allUsers) {
    const created = new Date(u.created_date as string).getTime();
    if (Date.now() - created < 30 * 24 * 60 * 60 * 1000) activeUserIds.add(u.id as string);
  }

  const lastInference = last24
    .filter((e) => e.eventType === 'inference')
    .sort((a, b) => (b.created_date as string).localeCompare(a.created_date as string))[0];

  return {
    activeUsers: activeUserIds.size + (session ? 1 : 0),
    consentGranted: cohortConsent?.status === 'granted',
    lastInferenceAt: (lastInference?.created_date as string) ?? null,
    inferenceCount24h: last24.filter((e) => e.eventType === 'inference').length,
    evidenceRetrievals24h: last24.filter((e) => e.eventType === 'retrieval').length,
    recentFailures: last24.filter((e) => e.status === 'failed').length,
  };
}