// Derived analytics modules: CHI, Barrier, TriggerGraph, SkinTwin.
// All compute from real persisted log/scan records — never invented values.

import { format, subDays } from 'date-fns';
import {
  SleepLogEntity,
  FoodLogEntity,
  StressLogEntity,
  HydrationLogEntity,
  SymptomLogEntity,
  FaceScanEntity,
  ProductScanEntity,
  ContactLogEntity,
  CycleLogEntity,
} from '../api/entityDefs';
import { BARRIER_MIN_DAYS, CHI_MIN_LOGS, LIMITS, TRIGGER_GRAPH_MIN_DAYS } from '../constants/dataThresholds';

export async function computeCutisHealthIndex(): Promise<{
  score: number;
  trend: 'up' | 'down' | 'flat';
  contributors: string[];
  dataPoints: number;
  minRequired: number;
  sufficient: boolean;
}> {
  const [sleep, food, stress, hydration, symptoms] = await Promise.all([
    SleepLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    FoodLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    StressLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    HydrationLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    SymptomLogEntity.list({ limit: LIMITS.DAILY_LOG }),
  ]);
  const totalLogs =
    sleep.total + food.total + stress.total + hydration.total + symptoms.total;

  if (totalLogs < CHI_MIN_LOGS) {
    return {
      score: 0,
      trend: 'flat',
      contributors: [],
      dataPoints: totalLogs,
      minRequired: CHI_MIN_LOGS,
      sufficient: false,
    };
  }

  const sleepAvg =
    sleep.records.length > 0
      ? sleep.records.reduce((s, r) => s + (r.hours as number), 0) / sleep.records.length
      : 0;
  const stressAvg =
    stress.records.length > 0
      ? stress.records.reduce((s, r) => s + (r.level as number), 0) / stress.records.length
      : 0;
  const hydrationAvg =
    hydration.records.length > 0
      ? hydration.records.reduce((s, r) => s + (r.waterLiters as number), 0) / hydration.records.length
      : 0;
  const inflammationAvg =
    symptoms.records.length > 0
      ? symptoms.records.reduce((s, r) => s + (r.inflammation ?? 0), 0) / symptoms.records.length
      : 0;

  const sleepScore = clamp01((sleepAvg - 4) / 4);
  const stressScore = clamp01(1 - stressAvg / 10);
  const hydrationScore = clamp01(hydrationAvg / 3);
  const symptomScore = clamp01(1 - inflammationAvg / 10);
  const contributors: string[] = [];
  if (sleepScore < 0.5) contributors.push('Insufficient sleep');
  if (stressScore < 0.5) contributors.push('Elevated stress');
  if (hydrationScore < 0.5) contributors.push('Low hydration');
  if (symptomScore < 0.5) contributors.push('Active inflammation');

  const score = clamp01(
    sleepScore * 0.25 + stressScore * 0.25 + hydrationScore * 0.2 + symptomScore * 0.3
  );

  const trend = computeTrendFromSeries([sleepAvg, stressAvg, hydrationAvg, inflammationAvg]);

  return { score, trend, contributors, dataPoints: totalLogs, minRequired: CHI_MIN_LOGS, sufficient: true };
}

export async function computeBarrierScore(): Promise<{
  score: number;
  drivers: string[];
  dataPoints: number;
  minRequired: number;
  sufficient: boolean;
}> {
  const [hydrationList, symptoms, contact, products, sleep] = await Promise.all([
    HydrationLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    SymptomLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    ContactLogEntity.list({ limit: LIMITS.DAILY_LOG }),
    ProductScanEntity.list({ limit: 10 }),
    SleepLogEntity.list({ limit: LIMITS.DAILY_LOG }),
  ]);

  const days =
    new Set([
      ...hydrationList.records.map((r) => r.logDate as string),
      ...symptoms.records.map((r) => r.logDate as string),
      ...contact.records.map((r) => r.logDate as string),
    ]).size;

  if (days < BARRIER_MIN_DAYS) {
    return { score: 0, drivers: [], dataPoints: days, minRequired: BARRIER_MIN_DAYS, sufficient: false };
  }

  const dryness =
    symptoms.records.length > 0
      ? symptoms.records.reduce((s, r) => s + (r.dryness ?? 0), 0) / symptoms.records.length
      : 0;
  const hydration =
    hydrationList.records.length > 0
      ? hydrationList.records.reduce((s, r) => s + (r.waterLiters as number), 0) / hydrationList.records.length
      : 0;
  const contactLoad =
    contact.records.filter((r) => r.helmet || r.mask || r.handsToFace).length /
    Math.max(1, contact.records.length);
  const harshProducts = products.records.filter((p) => p.verdict === 'avoid' || p.verdict === 'caution').length;
  const sleepAvg =
    sleep.records.length > 0
      ? sleep.records.reduce((s, r) => s + (r.hours as number), 0) / sleep.records.length
      : 8;

  const score = clamp01(
    1 -
      (dryness / 10) * 0.4 -
      (1 - clamp01(hydration / 3)) * 0.3 -
      contactLoad * 0.2 -
      clamp01(harshProducts / 5) * 0.2 +
      (sleepAvg >= 7 ? 0.1 : 0) -
      0.1
  );

  const drivers: string[] = [];
  if (dryness >= 5) drivers.push('Skin dryness');
  if (hydration < 1.5) drivers.push('Low hydration');
  if (contactLoad > 0.4) drivers.push('Frequent contact friction');
  if (harshProducts > 0) drivers.push('Harsh products in routine');

  return { score, drivers, dataPoints: days, minRequired: BARRIER_MIN_DAYS, sufficient: true };
}

export async function computeTriggerGraph(): Promise<{
  factors: { factor: string; correlation: number }[];
  dataPoints: number;
  minRequired: number;
  sufficient: boolean;
}> {
  const cutoff = format(subDays(new Date(), TRIGGER_GRAPH_MIN_DAYS + 14), 'yyyy-MM-dd');
  const [sleep, food, stress, hydrationList, symptoms] = await Promise.all([
    SleepLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: LIMITS.DAILY_LOG }),
    FoodLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: LIMITS.DAILY_LOG }),
    StressLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: LIMITS.DAILY_LOG }),
    HydrationLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: LIMITS.DAILY_LOG }),
    SymptomLogEntity.filter((r) => (r.logDate as string) >= cutoff, { limit: LIMITS.DAILY_LOG }),
  ]);

  const totalDays = new Set([
    ...sleep.records.map((r) => r.logDate as string),
    ...food.records.map((r) => r.logDate as string),
    ...stress.records.map((r) => r.logDate as string),
    ...hydrationList.records.map((r) => r.logDate as string),
    ...symptoms.records.map((r) => r.logDate as string),
  ]).size;

  if (totalDays < TRIGGER_GRAPH_MIN_DAYS) {
    return { factors: [], dataPoints: totalDays, minRequired: TRIGGER_GRAPH_MIN_DAYS, sufficient: false };
  }

  const factors: { factor: string; correlation: number }[] = [];

  factors.push({
    factor: 'High glycemic load',
    correlation: correlate(
      food.records
        .filter((r) => r.glycemicLoad === 'high')
        .map((r) => ({ date: r.logDate as string, v: 1 })),
      symptoms.records.map((r) => ({ date: r.logDate as string, v: r.inflammation ?? 0 }))
    ),
  });
  factors.push({
    factor: 'Dairy intake',
    correlation: correlate(
      food.records
        .filter((r) => r.dairyLevel === 'high' || r.dairyLevel === 'medium')
        .map((r) => ({ date: r.logDate as string, v: 1 })),
      symptoms.records.map((r) => ({ date: r.logDate as string, v: r.inflammation ?? 0 }))
    ),
  });
  factors.push({
    factor: 'Poor sleep',
    correlation: correlate(
      sleep.records
        .filter((r) => (r.hours as number) < 6)
        .map((r) => ({ date: r.logDate as string, v: 1 })),
      symptoms.records.map((r) => ({ date: r.logDate as string, v: r.inflammation ?? 0 }))
    ),
  });
  factors.push({
    factor: 'Elevated stress',
    correlation: correlate(
      stress.records
        .filter((r) => (r.level as number) >= 7)
        .map((r) => ({ date: r.logDate as string, v: 1 })),
      symptoms.records.map((r) => ({ date: r.logDate as string, v: r.inflammation ?? 0 }))
    ),
  });
  factors.push({
    factor: 'Low hydration',
    correlation: correlate(
      hydrationList.records
        .filter((r) => (r.waterLiters as number) < 1.5)
        .map((r) => ({ date: r.logDate as string, v: 1 })),
      symptoms.records.map((r) => ({ date: r.logDate as string, v: r.inflammation ?? 0 }))
    ),
  });

  factors.sort((a, b) => Math.abs(b.correlation) - Math.abs(a.correlation));
  return { factors, dataPoints: totalDays, minRequired: TRIGGER_GRAPH_MIN_DAYS, sufficient: true };
}

export async function computeSkinTwin(): Promise<{
  scanCount: number;
  zoneScores: Record<string, number>;
  trend: { date: string; score: number }[];
  counterfactuals: { intervention: string; expectedDelta: number; rationale: string }[];
  sufficient: boolean;
}> {
  const scans = await FaceScanEntity.list({ limit: LIMITS.FACE_SCAN });
  if (scans.records.length < 10) {
    return {
      scanCount: scans.total,
      zoneScores: {},
      trend: [],
      counterfactuals: [],
      sufficient: false,
    };
  }

  const zoneScores: Record<string, number> = {};
  for (const s of scans.records) {
    const zs = (s.zoneScores as Record<string, number>) ?? {};
    for (const [k, v] of Object.entries(zs)) {
      zoneScores[k] = (zoneScores[k] ?? 0) + (v as number);
    }
  }
  for (const k of Object.keys(zoneScores)) {
    zoneScores[k] = zoneScores[k] / scans.records.length;
  }

  const trend = scans.records
    .slice()
    .sort((a, b) => (a.logDate as string).localeCompare(b.logDate as string))
    .map((s) => ({
      date: s.logDate as string,
      score: clamp01(((s.redness ?? 0) + (s.oiliness ?? 0) + (s.dryness ?? 0)) / 3),
    }));

  const avg = trend.reduce((s, r) => s + r.score, 0) / Math.max(1, trend.length);

  const counterfactuals: { intervention: string; expectedDelta: number; rationale: string }[] = [];

  const [barrier, triggers] = await Promise.all([computeBarrierScore(), computeTriggerGraph()]);
  if (barrier.sufficient && barrier.score < 0.6) {
    counterfactuals.push({
      intervention: 'Restore barrier with gentle cleanser + ceramide moisturizer',
      expectedDelta: +(0.6 - barrier.score).toFixed(2),
      rationale: `Current barrier score ${barrier.score.toFixed(2)} is below 0.6; barrier restoration is the highest-leverage move.`,
    });
  }
  if (triggers.sufficient) {
    const top = triggers.factors.find((f) => f.correlation > 0.2);
    if (top) {
      counterfactuals.push({
        intervention: `Reduce ${top.factor.toLowerCase()}`,
        expectedDelta: +(top.correlation * 0.5).toFixed(2),
        rationale: `Strongest positive correlation with inflammation in your logs (r=${top.correlation.toFixed(2)}).`,
      });
    }
  }

  counterfactuals.forEach((c) => {
    c.expectedDelta = +Math.min(c.expectedDelta, avg).toFixed(2);
  });

  return {
    scanCount: scans.total,
    zoneScores,
    trend,
    counterfactuals,
    sufficient: true,
  };
}

export async function computeForecastTrend() {
  const scans = await FaceScanEntity.list({ limit: LIMITS.FACE_SCAN });
  const byDay = new Map<string, { inflammation: number; count: number }>();
  for (let i = 0; i < 30; i++) {
    const d = format(subDays(new Date(), i), 'yyyy-MM-dd');
    byDay.set(d, { inflammation: 0, count: 0 });
  }
  for (const s of scans.records) {
    const day = s.logDate as string;
    if (byDay.has(day)) {
      const cur = byDay.get(day)!;
      cur.inflammation += s.redness ?? 0;
      cur.count += 1;
    }
  }
  return Array.from(byDay.entries())
    .map(([date, v]) => ({ date, inflammation: v.count > 0 ? v.inflammation / v.count : null }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

function correlate(events: { date: string; v: number }[], outcomes: { date: string; v: number }[]) {
  if (events.length < 2 || outcomes.length < 2) return 0;
  const dayMap = new Map<string, number>();
  for (const o of outcomes) dayMap.set(o.date, o.v);
  const aligned = events
    .map((e) => ({ e: e.v, o: dayMap.get(e.date) }))
    .filter((x): x is { e: number; o: number } => typeof x.o === 'number');
  if (aligned.length < 2) return 0;
  const meanE = aligned.reduce((s, x) => s + x.e, 0) / aligned.length;
  const meanO = aligned.reduce((s, x) => s + x.o, 0) / aligned.length;
  let num = 0;
  let denE = 0;
  let denO = 0;
  for (const x of aligned) {
    num += (x.e - meanE) * (x.o - meanO);
    denE += (x.e - meanE) ** 2;
    denO += (x.o - meanO) ** 2;
  }
  const den = Math.sqrt(denE * denO);
  if (den === 0) return 0;
  return clamp(num / den, -1, 1);
}

function computeTrendFromSeries(values: number[]): 'up' | 'down' | 'flat' {
  if (values.length < 2) return 'flat';
  const half = Math.floor(values.length / 2);
  const first = values.slice(0, half).reduce((s, v) => s + v, 0) / Math.max(1, half);
  const last = values.slice(half).reduce((s, v) => s + v, 0) / Math.max(1, values.length - half);
  const diff = last - first;
  if (diff > 0.05) return 'down';
  if (diff < -0.05) return 'up';
  return 'flat';
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function clamp01(n: number) {
  if (Number.isNaN(n)) return 0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

export async function getRecentCyclePhase(): Promise<string | null> {
  const cycles = await CycleLogEntity.list({ limit: 1 });
  if (cycles.records.length === 0) return null;
  return cycles.records[0].phase as string;
}