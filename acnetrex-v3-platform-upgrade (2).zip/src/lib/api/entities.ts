// Base44-style entity facade.
// All UI code consumes these. Each call validates the shape with Zod before returning.

import { z } from 'zod';
import { db, type BaaSRecord, type StoreName } from '../storage/db';
import { APP_VERSION, SCHEMA_VERSION, LIMITS } from '../constants/dataThresholds';
import { randomId } from '../crypto';
import { writeAudit } from './audit';
import { getSession } from './session';

export interface EntityOptions {
  limit?: number;
  offset?: number;
}

export interface ListResult<T> {
  records: T[];
  total: number;
  limit: number;
  offset: number;
}

export interface CreateInput {
  [k: string]: unknown;
}

function nowIso() {
  return new Date().toISOString();
}

function makeRecord(input: CreateInput): BaaSRecord {
  const session = getSession();
  if (!session) throw new Error('Not authenticated');
  const id = (input.id as string) ?? randomId();
  const now = nowIso();
  const r: BaaSRecord = {
    ...input,
    id,
    created_by_id: session.userId,
    created_date: now,
    updated_date: now,
    app_version: APP_VERSION,
    schema_version: SCHEMA_VERSION,
    source: (input.source as string) ?? 'user',
  };
  return r;
}

export function makeEntity<T extends z.ZodTypeAny>(store: StoreName, schema: T) {
  const validate = (record: unknown) => schema.safeParse(record);

  return {
    store,
    schema,

    async create(input: CreateInput): Promise<z.infer<T>> {
      const record = makeRecord(input);
      const result = validate(record);
      if (!result.success) {
        throw new Error(`Invalid ${store} record: ${result.error.message}`);
      }
      await db.put(store, record);
      await writeAudit({
        entityType: store,
        entityId: record.id,
        operation: 'create',
        changedFields: Object.keys(record).filter((k) => k !== 'id'),
      });
      return result.data;
    },

    async update(id: string, patch: CreateInput): Promise<z.infer<T>> {
      const existing = await db.get(store, id);
      if (!existing) throw new Error(`${store} ${id} not found`);
      const merged: BaaSRecord = {
        ...existing,
        ...patch,
        id,
        updated_date: nowIso(),
      };
      const result = validate(merged);
      if (!result.success) {
        throw new Error(`Invalid ${store} record: ${result.error.message}`);
      }
      await db.put(store, merged);
      const changedFields = Object.keys(patch).filter(
        (k) => JSON.stringify(patch[k]) !== JSON.stringify(existing[k])
      );
      await writeAudit({
        entityType: store,
        entityId: id,
        operation: 'update',
        changedFields,
      });
      return result.data;
    },

    async delete(id: string): Promise<void> {
      await db.delete(store, id);
      await writeAudit({
        entityType: store,
        entityId: id,
        operation: 'delete',
        changedFields: ['id'],
      });
    },

    async get(id: string): Promise<z.infer<T> | null> {
      const r = await db.get(store, id);
      if (!r) return null;
      const result = validate(r);
      if (!result.success) return null;
      return result.data;
    },

    async list(opts: EntityOptions = {}): Promise<ListResult<z.infer<T>>> {
      const limit = opts.limit ?? LIMITS.DAILY_LOG;
      const offset = opts.offset ?? 0;
      const all = await db.list(store, { limit: 9999 });
      const total = all.length;
      const records = all.slice(offset, offset + limit);
      const validated: z.infer<T>[] = [];
      for (const r of records) {
        const result = validate(r);
        if (result.success) validated.push(result.data);
      }
      return { records: validated, total, limit, offset };
    },

    async filter(
      predicate: (r: z.infer<T>) => boolean,
      opts: EntityOptions = {}
    ): Promise<ListResult<z.infer<T>>> {
      const limit = opts.limit ?? LIMITS.DAILY_LOG;
      const offset = opts.offset ?? 0;
      const all = await db.list(store, { limit: 9999 });
      const total = all.length;
      const matched = all.filter((r) => predicate(r as z.infer<T>));
      const sliced = matched.slice(offset, offset + limit);
      const validated: z.infer<T>[] = [];
      for (const r of sliced) {
        const result = validate(r);
        if (result.success) validated.push(result.data);
      }
      return { records: validated, total, limit, offset };
    },
  };
}

export type Entity<T extends z.ZodTypeAny> = ReturnType<typeof makeEntity<T>>;