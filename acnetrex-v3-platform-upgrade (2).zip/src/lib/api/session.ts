// Session storage. Stored in localStorage for convenience,
// but the canonical source of truth is the User entity record
// matched against an active session token.

import { z } from 'zod';

const SESSION_KEY = 'acnetrex_session_v3';

export const sessionSchema = z.object({
  userId: z.string(),
  email: z.string().email(),
  displayName: z.string(),
  createdAt: z.string(),
  rememberMe: z.boolean(),
});

export type Session = z.infer<typeof sessionSchema>;

let cached: Session | null | undefined;

export function getSession(): Session | null {
  if (cached !== undefined) return cached;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) {
      cached = null;
      return null;
    }
    const parsed = sessionSchema.safeParse(JSON.parse(raw));
    cached = parsed.success ? parsed.data : null;
    return cached;
  } catch {
    cached = null;
    return null;
  }
}

export function setSession(s: Session | null): void {
  cached = s ?? undefined;
  if (s) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(s));
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

export function requireSession(): Session {
  const s = getSession();
  if (!s) throw new Error('Authentication required');
  return s;
}