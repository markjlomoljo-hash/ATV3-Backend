// All entity definitions in one place.
// Every UI service consumes these. No other module should construct entities directly.

import { makeEntity } from './entities';
import {
  userSchema,
  onboardingProfileSchema,
  faceScanSchema,
  productScanSchema,
  sleepLogSchema,
  foodLogSchema,
  stressLogSchema,
  activityLogSchema,
  hydrationLogSchema,
  cycleLogSchema,
  contactLogSchema,
  treatmentLogSchema,
  routineLogSchema,
  symptomLogSchema,
  sunscreenLogSchema,
  cleansingLogSchema,
  exfoliationLogSchema,
  makeupLogSchema,
  hyperpigmentationLogSchema,
  assistantMessageSchema,
  forecastSchema,
  whatIfScenarioSchema,
  healthIndexSnapshotSchema,
  evidenceBookmarkSchema,
  consentRecordSchema,
  intelligenceEventSchema,
  reportExportSchema,
  taskProgressSchema,
  skinTwinSnapshotSchema,
  barrierSnapshotSchema,
  triggerSnapshotSchema,
  forecastSnapshotSchema,
  indexSnapshotSchema,
} from '../schemas/entities';

export const UserEntity = makeEntity('User', userSchema);
export const OnboardingProfileEntity = makeEntity('OnboardingProfile', onboardingProfileSchema);
export const FaceScanEntity = makeEntity('FaceScan', faceScanSchema);
export const ProductScanEntity = makeEntity('ProductScan', productScanSchema);
export const SleepLogEntity = makeEntity('SleepLog', sleepLogSchema);
export const FoodLogEntity = makeEntity('FoodLog', foodLogSchema);
export const StressLogEntity = makeEntity('StressLog', stressLogSchema);
export const ActivityLogEntity = makeEntity('ActivityLog', activityLogSchema);
export const HydrationLogEntity = makeEntity('HydrationLog', hydrationLogSchema);
export const CycleLogEntity = makeEntity('CycleLog', cycleLogSchema);
export const ContactLogEntity = makeEntity('ContactLog', contactLogSchema);
export const TreatmentLogEntity = makeEntity('TreatmentLog', treatmentLogSchema);
export const RoutineLogEntity = makeEntity('RoutineLog', routineLogSchema);
export const SymptomLogEntity = makeEntity('SymptomLog', symptomLogSchema);
export const SunscreenLogEntity = makeEntity('SunscreenLog', sunscreenLogSchema);
export const CleansingLogEntity = makeEntity('CleansingLog', cleansingLogSchema);
export const ExfoliationLogEntity = makeEntity('ExfoliationLog', exfoliationLogSchema);
export const MakeupLogEntity = makeEntity('MakeupLog', makeupLogSchema);
export const HyperpigmentationLogEntity = makeEntity('HyperpigmentationLog', hyperpigmentationLogSchema);
export const AssistantMessageEntity = makeEntity('AssistantMessage', assistantMessageSchema);
export const ForecastEntity = makeEntity('Forecast', forecastSchema);
export const WhatIfScenarioEntity = makeEntity('WhatIfScenario', whatIfScenarioSchema);
export const HealthIndexSnapshotEntity = makeEntity('HealthIndexSnapshot', healthIndexSnapshotSchema);
export const EvidenceBookmarkEntity = makeEntity('EvidenceBookmark', evidenceBookmarkSchema);
export const ConsentRecordEntity = makeEntity('ConsentRecord', consentRecordSchema);
export const IntelligenceEventEntity = makeEntity('IntelligenceEvent', intelligenceEventSchema);
export const ReportExportEntity = makeEntity('ReportExport', reportExportSchema);
export const TaskProgressEntity = makeEntity('TaskProgress', taskProgressSchema);
export const SkinTwinSnapshotEntity = makeEntity('SkinTwinSnapshot', skinTwinSnapshotSchema);
export const BarrierSnapshotEntity = makeEntity('BarrierSnapshot', barrierSnapshotSchema);
export const TriggerSnapshotEntity = makeEntity('TriggerSnapshot', triggerSnapshotSchema);
export const ForecastSnapshotEntity = makeEntity('ForecastSnapshot', forecastSnapshotSchema);
export const IndexSnapshotEntity = makeEntity('IndexSnapshot', indexSnapshotSchema);