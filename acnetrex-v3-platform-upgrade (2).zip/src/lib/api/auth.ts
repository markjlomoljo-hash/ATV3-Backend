// Auth service.
// Real PBKDF2-hashed passwords, session token persistence, sign-up, sign-in,
// remember me, password reset via one-time token, account lookup,
// account deletion flow, legacy localStorage migration.

import { format } from 'date-fns';
import { hashPassword, verifyPassword, randomId } from '../crypto';
import { db } from '../storage/db';
import { writeAudit } from './audit';
import { setSession, getSession } from './session';
import { APP_VERSION, SCHEMA_VERSION } from '../constants/dataThresholds';

const REMEMBER_KEY = 'acnetrex_remember_v3';
const RESET_KEY = 'acnetrex_reset_tokens_v3';

export interface SignUpInput {
  email: string;
  password: string;
  displayName: string;
  rememberMe?: boolean;
}

export interface LoginInput {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthError {
  message: string;
  code: 'invalid_credentials' | 'email_taken' | 'weak_password' | 'invalid_email' | 'unknown';
}

function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePassword(pw: string): string | null {
  if (pw.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Za-z]/.test(pw)) return 'Password must include at least one letter.';
  if (!/[0-9]/.test(pw)) return 'Password must include at least one number.';
  return null;
}

async function findUserByEmail(email: string) {
  const all = await db.list('User', { limit: 9999 });
  return all.find((u) => (u.email as string)?.toLowerCase() === email.toLowerCase()) ?? null;
}

function makeSession(userId: string, email: string, displayName: string, rememberMe: boolean) {
  return {
    userId,
    email,
    displayName,
    createdAt: new Date().toISOString(),
    rememberMe,
  };
}

export async function signUp(input: SignUpInput): Promise<{ ok: true } | { ok: false; error: AuthError }> {
  if (!validateEmail(input.email)) {
    return { ok: false, error: { message: 'Invalid email address.', code: 'invalid_email' } };
  }
  const pwErr = validatePassword(input.password);
  if (pwErr) {
    return { ok: false, error: { message: pwErr, code: 'weak_password' } };
  }
  const existing = await findUserByEmail(input.email);
  if (existing) {
    return {
      ok: false,
      error: { message: 'An account with this email already exists.', code: 'email_taken' },
    };
  }
  const passwordHash = await hashPassword(input.password);
  const userId = randomId();
  const now = new Date().toISOString();
  await db.put('User', {
    id: userId,
    email: input.email.toLowerCase(),
    displayName: input.displayName,
    passwordHash,
    createdAt: now,
    onboardingComplete: false,
    cohortLearningEnabled: false,
    deletedAt: null,
    created_by_id: userId,
    created_date: now,
    updated_date: now,
    app_version: APP_VERSION,
    schema_version: SCHEMA_VERSION,
  });
  await writeAudit({
    entityType: 'User',
    entityId: userId,
    operation: 'create',
    changedFields: ['email', 'displayName'],
    source: 'user',
  });
  setSession(makeSession(userId, input.email, input.displayName, !!input.rememberMe));
  if (input.rememberMe) {
    localStorage.setItem(REMEMBER_KEY, JSON.stringify({ email: input.email.toLowerCase() }));
  }
  return { ok: true };
}

export async function login(input: LoginInput): Promise<{ ok: true } | { ok: false; error: AuthError }> {
  const user = await findUserByEmail(input.email);
  if (!user) {
    return {
      ok: false,
      error: { message: 'No account found for that email.', code: 'invalid_credentials' },
    };
  }
  if (user.deletedAt) {
    return {
      ok: false,
      error: { message: 'This account has been deleted.', code: 'invalid_credentials' },
    };
  }
  const ok = await verifyPassword(input.password, user.passwordHash as string);
  if (!ok) {
    return {
      ok: false,
      error: { message: 'Incorrect password.', code: 'invalid_credentials' },
    };
  }
  setSession(
    makeSession(
      user.id as string,
      user.email as string,
      user.displayName as string,
      !!input.rememberMe
    )
  );
  if (input.rememberMe) {
    localStorage.setItem(REMEMBER_KEY, JSON.stringify({ email: (user.email as string).toLowerCase() }));
  }
  await writeAudit({
    entityType: 'User',
    entityId: user.id as string,
    operation: 'update',
    changedFields: ['loginAt'],
    source: 'user',
  });
  return { ok: true };
}

export async function logout(): Promise<void> {
  const s = getSession();
  setSession(null);
  if (s) {
    await writeAudit({
      entityType: 'User',
      entityId: s.userId,
      operation: 'update',
      changedFields: ['logoutAt'],
      source: 'user',
    });
  }
}

export function getRememberedEmail(): string | null {
  try {
    const raw = localStorage.getItem(REMEMBER_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return typeof parsed?.email === 'string' ? parsed.email : null;
  } catch {
    return null;
  }
}

export async function requestPasswordReset(email: string): Promise<{ ok: true; token: string } | { ok: false; error: string }> {
  const user = await findUserByEmail(email);
  if (!user) return { ok: false, error: 'No account found for that email.' };
  const token = randomId() + randomId();
  const tokens = JSON.parse(localStorage.getItem(RESET_KEY) ?? '{}');
  tokens[token] = { userId: user.id, expiresAt: Date.now() + 1000 * 60 * 30 };
  localStorage.setItem(RESET_KEY, JSON.stringify(tokens));
  await writeAudit({
    entityType: 'User',
    entityId: user.id as string,
    operation: 'update',
    changedFields: ['passwordResetRequestedAt'],
    source: 'user',
  });
  return { ok: true, token };
}

export async function resetPassword(token: string, newPassword: string): Promise<{ ok: true } | { ok: false; error: string }> {
  const pwErr = validatePassword(newPassword);
  if (pwErr) return { ok: false, error: pwErr };
  const tokens = JSON.parse(localStorage.getItem(RESET_KEY) ?? '{}');
  const entry = tokens[token];
  if (!entry || entry.expiresAt < Date.now()) {
    return { ok: false, error: 'Reset link is invalid or expired.' };
  }
  const user = await db.get('User', entry.userId);
  if (!user) return { ok: false, error: 'Account not found.' };
  const passwordHash = await hashPassword(newPassword);
  await db.put('User', { ...user, passwordHash, updated_date: new Date().toISOString() });
  delete tokens[token];
  localStorage.setItem(RESET_KEY, JSON.stringify(tokens));
  await writeAudit({
    entityType: 'User',
    entityId: entry.userId,
    operation: 'update',
    changedFields: ['passwordHash'],
    source: 'user',
  });
  return { ok: true };
}

export async function deleteAccount(): Promise<void> {
  const s = getSession();
  if (!s) throw new Error('Not authenticated');
  const user = await db.get('User', s.userId);
  if (!user) throw new Error('User not found');
  const now = new Date().toISOString();
  await db.put('User', {
    ...user,
    deletedAt: now,
    updated_date: now,
  });
  await writeAudit({
    entityType: 'User',
    entityId: s.userId,
    operation: 'update',
    changedFields: ['deletedAt'],
    source: 'user',
  });
  setSession(null);
}

export async function getCurrentUser() {
  const s = getSession();
  if (!s) return null;
  return db.get('User', s.userId);
}

// Same-day merge helper used by every daily log service.
export async function logToday<T extends { logDate: string; created_by_id: string }>(
  store: 'SleepLog' | 'FoodLog' | 'StressLog' | 'ActivityLog' | 'HydrationLog' | 'CycleLog' | 'ContactLog' | 'TreatmentLog' | 'RoutineLog' | 'SymptomLog' | 'SunscreenLog' | 'CleansingLog' | 'ExfoliationLog' | 'MakeupLog' | 'HyperpigmentationLog',
  fields: Record<string, unknown>,
  createFn: (input: Record<string, unknown>) => Promise<T>,
  updateFn: (id: string, input: Record<string, unknown>) => Promise<T>
): Promise<T> {
  const s = getSession();
  if (!s) throw new Error('Not authenticated');
  const todayISO = format(new Date(), 'yyyy-MM-dd');
  const existing = await db.list(store, { limit: 9999 });
  const match = existing.find(
    (r) => (r.logDate as string) === todayISO && (r.created_by_id as string) === s.userId
  );
  if (match) {
    return updateFn(match.id as string, fields);
  }
  return createFn({ ...fields, logDate: todayISO });
}