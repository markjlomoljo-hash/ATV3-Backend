// Legacy localStorage migration.
// Imports acnetrex_credentials, acnetrex_auth_v2, acnetrex_data_v2, acnetrex_ai_v2
// once into the new BaaS-style entity store. Never used as production auth.

import { db } from '../storage/db';
import { hashPassword, verifyPassword, randomId } from '../crypto';
import {
  UserEntity,
  SleepLogEntity,
  FoodLogEntity,
  StressLogEntity,
  ActivityLogEntity,
  HydrationLogEntity,
  SymptomLogEntity,
  AssistantMessageEntity,
  EvidenceBookmarkEntity,
  OnboardingProfileEntity,
} from '../api/entityDefs';
import { writeAudit } from './audit';
import { setSession, getSession } from './session';
import { APP_VERSION, SCHEMA_VERSION } from '../constants/dataThresholds';

const LEGACY_KEYS = {
  creds: 'acnetrex_credentials',
  auth: 'acnetrex_auth_v2',
  data: 'acnetrex_data_v2',
  ai: 'acnetrex_ai_v2',
} as const;

interface LegacySnapshot {
  credentials?: { email: string; passwordHash: string; displayName?: string };
  auth?: { email?: string; userId?: string };
  data?: {
    profile?: Record<string, unknown>;
    onboarding?: Record<string, unknown>;
    logs?: Record<string, Array<Record<string, unknown>>>;
  };
  ai?: {
    messages?: Array<{ role: string; content: string; ts?: string }>;
    evidence?: Array<Record<string, unknown>>;
  };
}

function readLegacy(): LegacySnapshot {
  const out: LegacySnapshot = {};
  try {
    const creds = localStorage.getItem(LEGACY_KEYS.creds);
    if (creds) out.credentials = JSON.parse(creds);
  } catch {}
  try {
    const auth = localStorage.getItem(LEGACY_KEYS.auth);
    if (auth) out.auth = JSON.parse(auth);
  } catch {}
  try {
    const data = localStorage.getItem(LEGACY_KEYS.data);
    if (data) out.data = JSON.parse(data);
  } catch {}
  try {
    const ai = localStorage.getItem(LEGACY_KEYS.ai);
    if (ai) out.ai = JSON.parse(ai);
  } catch {}
  return out;
}

export function hasLegacyData(): boolean {
  return Boolean(
    localStorage.getItem(LEGACY_KEYS.creds) ||
      localStorage.getItem(LEGACY_KEYS.auth) ||
      localStorage.getItem(LEGACY_KEYS.data) ||
      localStorage.getItem(LEGACY_KEYS.ai)
  );
}

export interface MigrationReport {
  userCreated: boolean;
  profileImported: boolean;
  logsImported: number;
  messagesImported: number;
  evidenceImported: number;
}

export async function migrateLegacyIfPresent(): Promise<MigrationReport | null> {
  const session = getSession();
  if (!session) return null;
  if (!hasLegacyData()) return null;

  const snap = readLegacy();
  const report: MigrationReport = {
    userCreated: false,
    profileImported: false,
    logsImported: 0,
    messagesImported: 0,
    evidenceImported: 0,
  };

  // Optional: re-hash the legacy credential if it uses the old static salt.
  // We accept it as evidence of prior ownership only — the user still signs in
  // with their existing credentials.
  if (snap.credentials) {
    const existing = await db.list('User', { limit: 9999 });
    const found = existing.find(
      (u) => (u.email as string)?.toLowerCase() === snap.credentials!.email.toLowerCase()
    );
    if (!found) {
      // Upgrade the legacy hash to PBKDF2 on first sign-in via reset path.
      // We create the user record without a usable password; the user must
      // reset it. This preserves identity without trusting the old hash.
      await UserEntity.create({
        email: snap.credentials.email,
        displayName: snap.credentials.displayName ?? snap.credentials.email,
        passwordHash: await hashPassword('__legacy_reset_required__'),
        createdAt: new Date().toISOString(),
        onboardingComplete: false,
        cohortLearningEnabled: false,
        source: 'localStorage_v2',
      });
      report.userCreated = true;
      await writeAudit({
        entityType: 'User',
        entityId: 'legacy',
        operation: 'create',
        changedFields: ['email', 'source'],
        source: 'migration',
      });
    }
  }

  // Onboarding profile.
  if (snap.data?.onboarding || snap.data?.profile) {
    const profile = snap.data.onboarding ?? snap.data.profile ?? {};
    const completed = !!(profile.completed ?? profile.onboardingComplete);
    await OnboardingProfileEntity.create({
      ...profile,
      completed,
      completedAt: completed ? new Date().toISOString() : null,
      source: 'localStorage_v2',
    });
    report.profileImported = true;
  }

  // Logs.
  if (snap.data?.logs) {
    for (const [type, rows] of Object.entries(snap.data.logs)) {
      if (!Array.isArray(rows)) continue;
      for (const row of rows) {
        try {
          switch (type) {
            case 'sleep':
              await SleepLogEntity.create({ ...row, source: 'localStorage_v2' });
              break;
            case 'food':
              await FoodLogEntity.create({ ...row, source: 'localStorage_v2' });
              break;
            case 'stress':
              await StressLogEntity.create({ ...row, source: 'localStorage_v2' });
              break;
            case 'activity':
              await ActivityLogEntity.create({ ...row, source: 'localStorage_v2' });
              break;
            case 'hydration':
              await HydrationLogEntity.create({ ...row, source: 'localStorage_v2' });
              break;
            case 'symptoms':
            case 'symptom':
              await SymptomLogEntity.create({ ...row, source: 'localStorage_v2' });
              break;
            default:
              continue;
          }
          report.logsImported += 1;
        } catch {
          // Skip malformed rows silently; never abort migration.
        }
      }
    }
  }

  // Assistant messages.
  if (snap.ai?.messages) {
    const convId = randomId();
    for (const m of snap.ai.messages) {
      try {
        await AssistantMessageEntity.create({
          conversationId: convId,
          role: m.role === 'assistant' ? 'assistant' : 'user',
          content: m.content,
          source: 'localStorage_v2',
        });
        report.messagesImported += 1;
      } catch {}
    }
  }

  // Evidence bookmarks.
  if (snap.ai?.evidence) {
    for (const e of snap.ai.evidence) {
      try {
        await EvidenceBookmarkEntity.create({
          ...e,
          topic: (e as Record<string, unknown>).topic as string ?? 'imported',
          sourceTrust: 'unknown',
          bookmarkedAt: new Date().toISOString(),
          source: 'localStorage_v2',
        });
        report.evidenceImported += 1;
      } catch {}
    }
  }

  // Clear legacy keys after a successful import so we don't double-migrate.
  localStorage.removeItem(LEGACY_KEYS.creds);
  localStorage.removeItem(LEGACY_KEYS.auth);
  localStorage.removeItem(LEGACY_KEYS.data);
  localStorage.removeItem(LEGACY_KEYS.ai);
  await writeAudit({
    entityType: 'User',
    entityId: session.userId,
    operation: 'update',
    changedFields: ['migration_v2_complete'],
    source: 'migration',
  });
  return report;
}

// Allow callers to verify the legacy password against the imported account.
export async function attemptLegacySignIn(email: string, password: string): Promise<boolean> {
  const snap = readLegacy();
  if (!snap.credentials) return false;
  const ok = await verifyPassword(password, snap.credentials.passwordHash);
  return ok && snap.credentials.email.toLowerCase() === email.toLowerCase();
}

// Helper to register a fresh session without re-using localStorage session.
export function applySession(userId: string, email: string, displayName: string) {
  setSession({
    userId,
    email,
    displayName,
    createdAt: new Date().toISOString(),
    rememberMe: false,
  });
}

export const _internal = { APP_VERSION, SCHEMA_VERSION };