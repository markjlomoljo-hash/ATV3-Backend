// Audit log writer. Every entity create/update/delete produces an audit row.
// Stores field names only — never field values — to protect privacy.

import { z } from 'zod';
import { makeEntity } from './entities';
import { APP_VERSION, SCHEMA_VERSION } from '../constants/dataThresholds';

export const auditLogSchema = z.object({
  id: z.string(),
  created_by_id: z.string(),
  created_date: z.string(),
  updated_date: z.string(),
  app_version: z.string(),
  schema_version: z.string(),
  entityType: z.string(),
  entityId: z.string(),
  operation: z.enum(['create', 'update', 'delete']),
  userId: z.string(),
  timestamp: z.string(),
  appVersion: z.string(),
  changedFields: z.array(z.string()),
  source: z.enum(['user', 'migration', 'ai_engine', 'system']),
});

export type AuditLog = z.infer<typeof auditLogSchema>;

export const AuditLogEntity = makeEntity('AuditLog', auditLogSchema);

export interface AuditInput {
  entityType: string;
  entityId: string;
  operation: 'create' | 'update' | 'delete';
  changedFields: string[];
  source?: 'user' | 'migration' | 'ai_engine' | 'system';
}

export async function writeAudit(input: AuditInput): Promise<void> {
  const session = (await import('./session')).getSession();
  const userId = session?.userId ?? 'anonymous';
  await AuditLogEntity.create({
    entityType: input.entityType,
    entityId: input.entityId,
    operation: input.operation,
    userId,
    timestamp: new Date().toISOString(),
    appVersion: APP_VERSION,
    schemaVersion: SCHEMA_VERSION,
    changedFields: input.changedFields,
    source: input.source ?? 'user',
  });
}