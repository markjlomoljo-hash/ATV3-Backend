// Minimum data thresholds for meaningful analysis.
// Real values - any number below these triggers an InsufficientDataState.

export const FORECAST_MIN_DAYS = 7;
export const TRIGGER_GRAPH_MIN_DAYS = 14;
export const SKIN_TWIN_MIN_SCANS = 10;
export const BARRIER_MIN_DAYS = 5;
export const CHI_MIN_LOGS = 3;

export const APP_VERSION = '3.0.0';
export const SCHEMA_VERSION = '3';

// Pagination defaults per entity.
export const LIMITS = {
  DAILY_LOG: 20,
  FACE_SCAN: 10,
  INTELLIGENCE_EVENT: 50,
  ASSISTANT_MESSAGE: 30,
  EVIDENCE_BOOKMARK: 20,
  FORECAST: 10,
  HEALTH_INDEX: 10,
};

// AI model routing per task class.
export const AI_MODELS = {
  ASSISTANT: 'claude_sonnet_4_6',
  FORECAST: 'gemini_3_1_pro',
  FACE_ANALYSIS: 'gemini_3_flash',
  PRODUCT: 'gemini_3_flash',
  RESEARCH: 'gemini_3_flash',
  EXTRACTION: 'gemini_3_flash',
} as const;

// Confidence thresholds for surfacing outputs.
export const CONFIDENCE = {
  SURFACE: 0.6,
  DISPLAY: 0.4,
  MIN: 0.0,
} as const;