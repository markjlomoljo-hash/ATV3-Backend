// IndexedDB-backed BaaS-style persistence layer.
// Each "entity" is an object store keyed by id. This is a real durable store,
// not localStorage. Records survive reloads and are versioned.

const DB_NAME = 'acnetrex_v3';
const DB_VERSION = 1;

export const STORES = [
  'User',
  'OnboardingProfile',
  'FaceScan',
  'ProductScan',
  'SleepLog',
  'FoodLog',
  'StressLog',
  'ActivityLog',
  'HydrationLog',
  'CycleLog',
  'ContactLog',
  'TreatmentLog',
  'RoutineLog',
  'SymptomLog',
  'SunscreenLog',
  'CleansingLog',
  'ExfoliationLog',
  'MakeupLog',
  'HyperpigmentationLog',
  'AssistantMessage',
  'Forecast',
  'WhatIfScenario',
  'HealthIndexSnapshot',
  'EvidenceBookmark',
  'ConsentRecord',
  'IntelligenceEvent',
  'AuditLog',
  'ReportExport',
  'TaskProgress',
  'SkinTwinSnapshot',
  'BarrierSnapshot',
  'TriggerSnapshot',
  'ForecastSnapshot',
  'IndexSnapshot',
] as const;

export type StoreName = (typeof STORES)[number];

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const s of STORES) {
        if (!db.objectStoreNames.contains(s)) {
          const store = db.createObjectStore(s, { keyPath: 'id' });
          store.createIndex('created_by_id', 'created_by_id', { unique: false });
          store.createIndex('created_date', 'created_date', { unique: false });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

export interface BaaSRecord {
  id: string;
  created_by_id: string;
  created_date: string;
  updated_date: string;
  app_version: string;
  schema_version: string;
  source?: string;
  [k: string]: unknown;
}

async function openStoreCursor(
  store: StoreName,
  direction: IDBCursorDirection
): Promise<BaaSRecord[]> {
  const d = await openDb();
  return new Promise((resolve, reject) => {
    const out: BaaSRecord[] = [];
    const t = d.transaction(store, 'readonly');
    const r = t.objectStore(store).openCursor(null, direction);
    r.onsuccess = () => {
      const cur = r.result;
      if (cur) {
        out.push(cur.value as BaaSRecord);
        cur.continue();
      }
    };
    t.oncomplete = () => resolve(out);
    t.onerror = () => reject(t.error);
  });
}

export const db = {
  async list(store: StoreName, opts?: { limit?: number; offset?: number }): Promise<BaaSRecord[]> {
    const all = await openStoreCursor(store, 'prev');
    const skip = opts?.offset ?? 0;
    const limit = opts?.limit ?? 100;
    return all.slice(skip, skip + limit);
  },

  async filter(
    store: StoreName,
    predicate: (r: BaaSRecord) => boolean,
    opts?: { limit?: number; offset?: number; sortDesc?: boolean }
  ): Promise<BaaSRecord[]> {
    const all = await openStoreCursor(store, 'prev');
    const filtered = all.filter(predicate);
    if (!(opts?.sortDesc ?? true)) {
      filtered.reverse();
    }
    const skip = opts?.offset ?? 0;
    const limit = opts?.limit ?? 20;
    return filtered.slice(skip, skip + limit);
  },

  async get(store: StoreName, id: string): Promise<BaaSRecord | null> {
    const d = await openDb();
    return new Promise((resolve, reject) => {
      const t = d.transaction(store, 'readonly');
      const r = t.objectStore(store).get(id);
      r.onsuccess = () => resolve((r.result as BaaSRecord) ?? null);
      r.onerror = () => reject(r.error);
    });
  },

  async put(store: StoreName, record: BaaSRecord): Promise<BaaSRecord> {
    const d = await openDb();
    return new Promise((resolve, reject) => {
      const t = d.transaction(store, 'readwrite');
      t.objectStore(store).put(record);
      t.oncomplete = () => resolve(record);
      t.onerror = () => reject(t.error);
    });
  },

  async delete(store: StoreName, id: string): Promise<void> {
    const d = await openDb();
    return new Promise((resolve, reject) => {
      const t = d.transaction(store, 'readwrite');
      t.objectStore(store).delete(id);
      t.oncomplete = () => resolve();
      t.onerror = () => reject(t.error);
    });
  },

  async clear(store: StoreName): Promise<void> {
    const d = await openDb();
    return new Promise((resolve, reject) => {
      const t = d.transaction(store, 'readwrite');
      t.objectStore(store).clear();
      t.oncomplete = () => resolve();
      t.onerror = () => reject(t.error);
    });
  },
};

export async function dumpStore(store: StoreName): Promise<BaaSRecord[]> {
  return db.list(store, { limit: 9999 });
}