// Centralized Zod schemas for every entity.
// Every entity record that reaches the display layer is validated through these.
// All fields optional on create; required ones enforced at the call site.

import { z } from 'zod';

const isoString = z.string();

const baseRecord = z.object({
  id: z.string(),
  created_by_id: z.string(),
  created_date: isoString,
  updated_date: isoString,
  app_version: z.string(),
  schema_version: z.string(),
  source: z.string().optional(),
});

export const userSchema = baseRecord.extend({
  email: z.string().email(),
  displayName: z.string(),
  passwordHash: z.string(),
  createdAt: isoString,
  onboardingComplete: z.boolean(),
  cohortLearningEnabled: z.boolean(),
  deletedAt: isoString.nullable().optional(),
});

export const onboardingProfileSchema = baseRecord.extend({
  skinType: z.enum(['oily', 'dry', 'combination', 'normal', 'sensitive']).optional(),
  acneSeverity: z.enum(['mild', 'moderate', 'severe']).optional(),
  ageRange: z.string().optional(),
  concerns: z.array(z.string()).optional(),
  routine: z.array(z.string()).optional(),
  goals: z.array(z.string()).optional(),
  climate: z.string().optional(),
  dietPattern: z.string().optional(),
  stressBaseline: z.number().optional(),
  sleepBaseline: z.number().optional(),
  hormonal: z.boolean().optional(),
  completed: z.boolean(),
  completedAt: isoString.nullable().optional(),
});

export const faceScanSchema = baseRecord.extend({
  logDate: z.string(),
  photoFront: z.string().optional(),
  photoLeft: z.string().optional(),
  photoRight: z.string().optional(),
  photoForehead: z.string().optional(),
  photoChin: z.string().optional(),
  imageQualityScore: z.number().optional(),
  faceDetected: z.boolean().optional(),
  alignmentOk: z.boolean().optional(),
  redness: z.number().optional(),
  oiliness: z.number().optional(),
  dryness: z.number().optional(),
  pihPhe: z.number().optional(),
  scarVisibility: z.number().optional(),
  inflammatoryCount: z.number().optional(),
  comedonalCount: z.number().optional(),
  zoneScores: z.record(z.string(), z.number()).optional(),
  validationStatus: z.enum(['pending', 'valid', 'invalid', 'insufficient']).default('pending'),
  confidence: z.number().min(0).max(1).default(0),
  modelVersion: z.string().optional(),
  rationale: z.string().optional(),
  notes: z.string().optional(),
});

export const productScanSchema = baseRecord.extend({
  brand: z.string(),
  productName: z.string(),
  ingredientsText: z.string().optional(),
  imageUrl: z.string().optional(),
  comedogenicRisk: z.number().min(0).max(1).optional(),
  irritantRisk: z.number().min(0).max(1).optional(),
  hormonalRisk: z.number().min(0).max(1).optional(),
  occlusiveRisk: z.number().min(0).max(1).optional(),
  barrierRisk: z.number().min(0).max(1).optional(),
  verdict: z.enum(['favorable', 'caution', 'avoid', 'insufficient_data']).optional(),
  rationale: z.string().optional(),
  flaggedIngredients: z.array(z.string()).optional(),
  favorableIngredients: z.array(z.string()).optional(),
  evidenceRefs: z.array(z.string()).optional(),
  confidence: z.number().min(0).max(1).default(0),
  validationStatus: z.enum(['pending', 'valid', 'invalid', 'insufficient']).default('pending'),
  modelVersion: z.string().optional(),
});

export const sleepLogSchema = baseRecord.extend({
  logDate: z.string(),
  hours: z.number(),
  quality: z.number().min(0).max(10).optional(),
  notes: z.string().optional(),
});

export const foodLogSchema = baseRecord.extend({
  logDate: z.string(),
  glycemicLoad: z.enum(['low', 'medium', 'high']).optional(),
  dairyLevel: z.enum(['none', 'low', 'medium', 'high']).optional(),
  wheyLevel: z.enum(['none', 'low', 'medium', 'high']).optional(),
  sugarLevel: z.enum(['none', 'low', 'medium', 'high']).optional(),
  omega3: z.boolean().optional(),
  vegetables: z.boolean().optional(),
  processed: z.boolean().optional(),
  notes: z.string().optional(),
});

export const stressLogSchema = baseRecord.extend({
  logDate: z.string(),
  level: z.number().min(0).max(10),
  triggers: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

export const activityLogSchema = baseRecord.extend({
  logDate: z.string(),
  sweatLevel: z.enum(['none', 'low', 'medium', 'high']).optional(),
  durationMinutes: z.number().optional(),
  type: z.string().optional(),
  notes: z.string().optional(),
});

export const hydrationLogSchema = baseRecord.extend({
  logDate: z.string(),
  waterLiters: z.number(),
  notes: z.string().optional(),
});

export const cycleLogSchema = baseRecord.extend({
  logDate: z.string(),
  phase: z.enum(['menstrual', 'follicular', 'ovulatory', 'luteal']),
  day: z.number().optional(),
  notes: z.string().optional(),
});

export const contactLogSchema = baseRecord.extend({
  logDate: z.string(),
  helmet: z.boolean().optional(),
  mask: z.boolean().optional(),
  phone: z.boolean().optional(),
  pillowcase: z.boolean().optional(),
  handsToFace: z.boolean().optional(),
  notes: z.string().optional(),
});

export const treatmentLogSchema = baseRecord.extend({
  logDate: z.string(),
  treatment: z.string(),
  applied: z.boolean(),
  notes: z.string().optional(),
});

export const routineLogSchema = baseRecord.extend({
  logDate: z.string(),
  am: z.boolean().optional(),
  pm: z.boolean().optional(),
  steps: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

export const symptomLogSchema = baseRecord.extend({
  logDate: z.string(),
  inflammation: z.number().min(0).max(10).optional(),
  oiliness: z.number().min(0).max(10).optional(),
  dryness: z.number().min(0).max(10).optional(),
  redness: z.number().min(0).max(10).optional(),
  lesions: z.number().int().min(0).optional(),
  notes: z.string().optional(),
});

export const sunscreenLogSchema = baseRecord.extend({
  logDate: z.string(),
  applied: z.boolean(),
  spf: z.number().optional(),
  reapplied: z.boolean().optional(),
  notes: z.string().optional(),
});

export const cleansingLogSchema = baseRecord.extend({
  logDate: z.string(),
  times: z.number().int().min(0),
  cleanserType: z.string().optional(),
  notes: z.string().optional(),
});

export const exfoliationLogSchema = baseRecord.extend({
  logDate: z.string(),
  active: z.string().optional(),
  strength: z.enum(['mild', 'medium', 'strong']).optional(),
  notes: z.string().optional(),
});

export const makeupLogSchema = baseRecord.extend({
  logDate: z.string(),
  foundation: z.boolean().optional(),
  nonComedogenic: z.boolean().optional(),
  removedAtNight: z.boolean().optional(),
  notes: z.string().optional(),
});

export const hyperpigmentationLogSchema = baseRecord.extend({
  logDate: z.string(),
  marks: z.number().int().min(0).optional(),
  severity: z.number().min(0).max(10).optional(),
  notes: z.string().optional(),
});

export const assistantMessageSchema = baseRecord.extend({
  conversationId: z.string(),
  role: z.enum(['user', 'assistant']),
  content: z.string(),
  citations: z
    .array(z.object({ title: z.string(), source: z.string().optional(), url: z.string().optional() }))
    .optional(),
  confidence: z.number().min(0).max(1).default(0),
  modelVersion: z.string().optional(),
  feedback: z.enum(['helpful', 'unhelpful']).optional(),
});

export const forecastSchema = baseRecord.extend({
  generatedAt: isoString,
  horizonDays: z.number().int().min(1).max(30),
  overallRisk: z.number().min(0).max(1),
  confidence: z.number().min(0).max(1),
  contributors: z.array(
    z.object({
      factor: z.string(),
      impact: z.number(),
      rationale: z.string(),
    })
  ),
  daily: z.array(
    z.object({
      date: z.string(),
      risk: z.number(),
      confidence: z.number(),
    })
  ),
  modelVersion: z.string(),
  validationStatus: z.enum(['valid', 'invalid', 'insufficient']),
});

export const whatIfScenarioSchema = baseRecord.extend({
  baseForecastId: z.string(),
  scenario: z.string(),
  delta: z.number(),
  newRisk: z.number(),
  confidence: z.number(),
  rationale: z.string(),
});

export const healthIndexSnapshotSchema = baseRecord.extend({
  date: z.string(),
  chi: z.number(),
  barrier: z.number(),
  triggers: z.number(),
  trend: z.enum(['up', 'down', 'flat']),
  contributors: z.array(z.string()).optional(),
  computedAt: isoString,
  inputsHash: z.string(),
});

export const evidenceBookmarkSchema = baseRecord.extend({
  title: z.string(),
  authors: z.string().optional(),
  journal: z.string().optional(),
  year: z.number().int().optional(),
  abstract: z.string().optional(),
  url: z.string().optional(),
  topic: z.string(),
  sourceTrust: z.enum(['peer_reviewed', 'preprint', 'database', 'vendor', 'unknown']).default('unknown'),
  bookmarkedAt: isoString,
});

export const consentRecordSchema = baseRecord.extend({
  consentType: z.enum(['research', 'cohort_learning', 'analytics', 'media_storage']),
  status: z.enum(['granted', 'revoked']),
  grantedAt: isoString,
  revokedAt: isoString.nullable().optional(),
  version: z.string(),
});

export const intelligenceEventSchema = baseRecord.extend({
  eventType: z.enum([
    'inference',
    'retrieval',
    'validation',
    'learning',
    'error',
    'milestone',
    'truncation',
  ]),
  engine: z.string(),
  status: z.enum(['started', 'succeeded', 'failed', 'degraded']),
  confidence: z.number().min(0).max(1).optional(),
  message: z.string().optional(),
  consentStatus: z.enum(['granted', 'revoked', 'unknown']).default('unknown'),
  modelVersion: z.string().optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

export const reportExportSchema = baseRecord.extend({
  title: z.string(),
  generatedAt: isoString,
  sections: z.array(z.string()),
  payload: z.string(),
  range: z.object({ from: z.string(), to: z.string() }),
});

export const taskProgressSchema = baseRecord.extend({
  taskKey: z.string(),
  lastCompletedAt: isoString.nullable().optional(),
  streak: z.number().int().default(0),
  count: z.number().int().default(0),
  points: z.number().int().default(0),
});

export const skinTwinSnapshotSchema = baseRecord.extend({
  computedAt: isoString,
  scanCount: z.number().int(),
  zoneScores: z.record(z.string(), z.number()),
  trend: z.array(z.object({ date: z.string(), score: z.number() })),
  counterfactuals: z.array(
    z.object({
      intervention: z.string(),
      expectedDelta: z.number(),
      rationale: z.string(),
    })
  ),
  confidence: z.number(),
});

export const barrierSnapshotSchema = baseRecord.extend({
  date: z.string(),
  score: z.number(),
  confidence: z.number(),
  drivers: z.array(z.string()),
});

export const triggerSnapshotSchema = baseRecord.extend({
  date: z.string(),
  score: z.number(),
  topTriggers: z.array(z.object({ factor: z.string(), correlation: z.number() })),
});

export const forecastSnapshotSchema = baseRecord.extend({
  date: z.string(),
  horizonDays: z.number(),
  points: z.array(z.object({ date: z.string(), risk: z.number(), confidence: z.number() })),
});

export const indexSnapshotSchema = baseRecord.extend({
  date: z.string(),
  chi: z.number(),
  barrier: z.number(),
  triggers: z.number(),
});