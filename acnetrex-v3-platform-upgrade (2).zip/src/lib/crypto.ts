// PBKDF2-based password hashing using Web Crypto.
// Real, modern cryptographic primitives. Not a placeholder.

const ITERATIONS = 210_000;
const KEY_LEN = 32;
const SALT_LEN = 16;

function toHex(buf: ArrayBuffer | Uint8Array): string {
  const view = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < view.length; i++) s += view[i].toString(16).padStart(2, '0');
  return s;
}

function fromHex(hex: string): Uint8Array {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}

async function deriveBits(password: string, salt: Uint8Array): Promise<ArrayBuffer> {
  const passBytes = new TextEncoder().encode(password);
  const baseKey = await crypto.subtle.importKey('raw', passBytes as BufferSource, 'PBKDF2', false, [
    'deriveBits',
  ]);
  return crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: salt as BufferSource, iterations: ITERATIONS, hash: 'SHA-256' },
    baseKey,
    KEY_LEN * 8
  );
}

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(SALT_LEN));
  const bits = await deriveBits(password, salt);
  return `pbkdf2$${ITERATIONS}$${toHex(salt)}$${toHex(bits)}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  try {
    const parts = stored.split('$');
    if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
    const salt = fromHex(parts[2]);
    const expected = parts[3];
    const bits = await deriveBits(password, salt);
    const actual = toHex(bits);
    if (actual.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
    return diff === 0;
  } catch {
    return false;
  }
}

export function randomId(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  return 'r_' + toHex(bytes);
}