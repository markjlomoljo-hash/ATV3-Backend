# AcneTrex recovered artifacts

This folder contains the isolated/recovered deployable source artifacts and an upgrade handoff for rebuilding AcneTrex.

## Important files

- `docs/ACNETREX_UPGRADE_HANDOFF.md` — main document to give another AI/developer.
- `artifacts/deployed-singlefile.html` — fetched deployed single-file app.
- `artifacts/deployed-bundle.pretty.js` — prettified deployed JS bundle; use as behavioral reference.
- `artifacts/deployed-styles.pretty.css` — prettified deployed CSS.
- `artifacts/package.json` — attached project dependencies.
- `artifacts/tsconfig.json` — attached TypeScript config.
- `artifacts/original-index.html` — attached Vite HTML entry.

## Extraction notes

The public URL serves an Arena wrapper page by default. The actual app was recoverable by requesting `?embed=true` with iframe-like headers. The recovered app is a Vite single-file build with no sourcemap, so the original `src/` directory cannot be perfectly reconstructed from the public deploy.

Use the bundle as a reference and rebuild clean source modules rather than editing the minified/prettified bundle directly.
