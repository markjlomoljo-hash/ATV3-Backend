# AcneTrex Website Recovery + Upgrade Handoff

Prepared from the deployed Arena site and attached project files.

## 1) What was recovered / isolated

The public Arena URL serves a wrapper page unless it is requested as an iframe. The actual app is a Vite single-file build with all JavaScript and CSS inlined.

Recovered artifacts are in `acnetrex_recovered/artifacts/`:

- `original-index.html` — user-attached Vite entry HTML.
- `package.json` — user-attached dependencies/scripts.
- `tsconfig.json` — user-attached TypeScript config.
- `deployed-singlefile.html` — fetched deployed application, single-file build.
- `deployed-bundle.min.js` — inlined production JS bundle extracted from the deployed HTML.
- `deployed-bundle.pretty.js` — prettified extracted JS bundle for reverse engineering.
- `deployed-styles.min.css` — inlined production CSS extracted from the deployed HTML.
- `deployed-styles.pretty.css` — prettified extracted CSS.
- `SHA256SUMS.txt` — hashes for verification.

Important limitation: the original `/src` directory was not available, and the deployed build has no sourcemap. Therefore `deployed-bundle.pretty.js` is recovered bundle code, not the original clean component files. It is still the best reference for behavior, routes, data schema, UI copy, formulas, and feature logic.

## 2) Current stack from attached `package.json`

Project type: React + Vite + Tailwind CSS single-page application.

Scripts:

```json
{
  "dev": "vite",
  "build": "vite build",
  "preview": "vite preview"
}
```

Main dependencies:

- React `19.2.6`
- React DOM `19.2.6`
- React Router DOM `^7.18.0`
- Zustand `^5.0.14`
- React Hook Form `^7.80.0`
- Zod `^4.4.3`
- Framer Motion `^12.40.0`
- Lucide React `^1.21.0`
- Recharts `^3.8.1`
- Date-fns `^4.4.0`
- React Dropzone `^15.0.0`
- Tailwind Merge `3.4.0`
- clsx `2.1.1`

Dev dependencies:

- Vite `7.3.2`
- TypeScript `5.9.3`
- Tailwind CSS `4.1.17`
- `@tailwindcss/vite` `4.1.17`
- `@vitejs/plugin-react` `5.1.1`
- `vite-plugin-singlefile` `2.3.0`
- React/Node type packages

Node requirement implied by Vite/React Router: Node `>=20.19` or preferably current LTS `22+` for upgrade work.

## 3) Current product summary

Brand: **AcneTrex**

Deployed title: `AcneTrex — AI-Powered Skin Intelligence Platform`

Positioning/copy:

- “Skin Intelligence Platform”
- “AcneTrex v2.0 · Clinical-grade skin intelligence · All data stored locally”
- App version constant in bundle: `2.0.0`
- Schema version constant in bundle: `2`

The current app is mobile-first, dark themed, max-width mobile container, and behaves like a local-only PWA-style SPA.

## 4) Current architecture reality

This is currently a **client-only demo/prototype**.

There is no real backend, no server-side authentication, no live model inference, no hosted ML service, no true online learning, and no API integration in the recovered bundle.

Everything important is stored in browser `localStorage` through Zustand persist stores.

### Local storage keys

1. `acnetrex_credentials`
   - Plain object keyed by lowercased email.
   - Value is SHA-256 of `password + "acnetrex_salt_v2"`.
   - This is insecure and must be replaced.

2. `acnetrex_auth_v2`
   - Zustand auth/profile state.
   - Contains user, onboarding profile, authentication flag, schema version.

3. `acnetrex_data_v2`
   - Zustand health/logging/product/forecast/intelligence data.

4. `acnetrex_ai_v2`
   - Zustand CutisAI conversation data.

## 5) Current route map

Routes from the recovered bundle:

- `/auth` — Sign in/create account screen.
- `/onboarding` — multi-step setup flow.
- `/` — dashboard/home.
- `/log/face` — daily face scan.
- `/log/sleep` — sleep log.
- `/log/food` — food/diet log.
- `/log/stress` — stress/mood log.
- `/log/activity` — activity/sweat log.
- `/face-atlas` — face scan analytics.
- `/triggers` — trigger correlation screen.
- `/forecast` — ClearPath forecast.
- `/barrier` — BarrierGuard/barrier monitor.
- `/products` — FormulaLens product/ingredient analyzer.
- `/research` — evidence/research library.
- `/ai` — CutisAI assistant/chat.
- `/intelligence` — intelligence readiness/core screen.
- `/skin-twin` — skin digital twin.
- `/sleep` — SleepDerm analytics.
- `/diet` — DermDiet intelligence.
- `/activity` — SweatFlow index.
- `/cycle` — CycleSync tracker placeholder.
- `/contact` — ContactGuard hygiene/contact monitor.
- `/climate` — ClimateSkin radar placeholder.
- `/reports` — reports/export.
- `/profile` — profile and data summary.
- `*` — redirects depending on auth/onboarding state.

Bottom nav:

- Home `/`
- Scan `/log/face`
- Products `/products`
- CutisAI `/ai`
- Profile `/profile`

## 6) Current screens/features

Current named features visible in code/UI:

- **FaceAtlas** / Daily Face Scan
- **Cutis Health Index**
- **TriggerGraph** / Trigger Correlation Engine
- **ClearPath Forecast**
- **BarrierGuard** / Barrier Monitor
- **FormulaLens** product ingredient analyzer
- **CutisAI** assistant
- **SleepDerm** analytics
- **DermDiet** intelligence
- **SweatFlow** index
- **CycleSync** tracker
- **ContactGuard** hygiene/contact tracking
- **ClimateSkin** radar
- **Skin Digital Twin**
- **Reports & Export**
- Research/evidence library

## 7) Current auth/profile behavior

Current auth functions in the recovered code:

- `signUp(email, password, displayName)`
  - Checks `acnetrex_credentials` for existing email.
  - Hashes password client-side with SHA-256 and static salt.
  - Creates local user:
    - `id`
    - `email`
    - `displayName`
    - `createdAt`
    - `lastLoginAt`
    - `appVersion`
    - `consentPrivacy: true`
    - `consentResearch: false`
    - `consentFederated: false`
  - Creates onboarding profile `{ completed: false, currentStep: 0 }`.

- `signIn(email, password)`
  - Compares client-side hash.
  - Updates `lastLoginAt` only if a user profile exists in persisted auth store.

- `signOut()`
  - Sets `isAuthenticated: false` but keeps local data.

Critical upgrade note: this auth is not secure and should not be retained except as migration/import logic for old local demo users.

## 8) Current onboarding profile fields

The onboarding flow appears to have 8 steps. Fields inferred from recovered code:

Personal profile:

- `age`
- `sex`
- `height`
- `weight`
- `lifeStatus`

Skin profile:

- `skinType`
- `acneType`
- `acneSeverity`
- `skinGoals[]`
- `familyAcneHistory`

Lifestyle:

- `sleepHours`
- `bedtime`
- `stressLevel`
- `exerciseFrequency`
- `dietType`
- `showerFrequency`

Skincare routine:

- `currentProducts[]`
- `sunscreenHabit`
- `exfoliationFrequency`

Health context:

- `healthConditions[]`
- `maintenanceMedications[]`
- `trackCycle`

Baseline scan:

- `baselineScanCompleted`
- `baselineScanData`

Metadata:

- `completed`
- `currentStep`
- `completedAt`

## 9) Current main data store shape

The recovered `acnetrex_data_v2` Zustand state initializes:

```ts
{
  faceScans: [],
  sleepLogs: [],
  foodLogs: [],
  activityLogs: [],
  stressLogs: [],
  hydrationLogs: [],
  cycleLogs: [],
  contactLogs: [],
  productScans: [],
  healthIndex: null,
  healthIndexHistory: [],
  triggerCorrelations: [],
  forecasts: [],
  whatIfScenarios: [],
  intelligence: {
    status: "idle",
    readinessScore: 0,
    personalizedDataPoints: 0,
    activeModels: [],
    recentEvents: [],
    milestones: [],
    modelTier: "bootstrap"
  },
  weatherContext: null,
  savedEvidence: [],
  schemaVersion: 2
}
```

ID format helper:

```ts
`${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`
```

Store size limits:

- Sleep/food/activity/stress/hydration/contact logs: keep most recent ~365.
- Cycle logs: keep most recent 730.
- Forecasts: keep most recent 100.
- What-if scenarios: keep most recent 50.
- Intelligence events: keep most recent 50.

## 10) Current log record fields

### Face scan

Generated by a mock function named `m5` in the prettified bundle.

Fields:

- `id`
- `userId`
- `timestamp`
- `type` (`baseline` or `daily`)
- `zones`
  - `forehead`
  - `leftCheek`
  - `rightCheek`
  - `nose`
  - `chin`
  - `jawline`
  - Each zone has `zone`, `condition`, `lesionCount`, `redness`, `oiliness`, `observations[]`.
- `overallCondition`: `none | mild | moderate | severe`
- `lesionCount`
- `lesionTypes[]` e.g. `{ type: "papule", count }`, `{ type: "comedone", count }`
- `rednessScore`
- `oilinessScore`
- `drynessScore`
- `postInflammatoryMarks`
- `scarVisibility`
- `scanQuality`: `good | fair`
- `confidence`
- `validationStatus`
- `healthIndex`
- `notes`
- `imageStored: false`
- `imageConsent: false`
- `appVersion`

Important: current camera/image analysis is fake. It uses seconds from the timestamp and random-ish deterministic formulas; it does not inspect the image.

### Sleep log

- `id`
- `userId`
- `date`
- `bedtime`
- `wakeTime`
- `netSleepHours`
- `quality`
- `fragmented`
- `lateNightShift`
- `sleepDebt`
- `createdAt`

### Food log

- `id`
- `userId`
- `date`
- `meals[]` with meal objects like `{ id, name, category: "meal", riskScore }`
- `hydrationLiters`
- `glycemicLoad`
- `dairyIntake`
- `wheyProtein`
- `sugarLoad`: likely `low | moderate | high`
- `processedFoodLevel`: likely `minimal | moderate | high`
- `overallRisk`
- `createdAt`

### Stress log

- `id`
- `userId`
- `date`
- `stressLevel`
- `mood`
- `anxietyLevel`
- `workload`
- `majorEvent?`
- `createdAt`

### Activity log

- `id`
- `userId`
- `date`
- `activityType`
- `intensity`: `light | moderate | vigorous`
- `durationMinutes`
- `sweatLevel`: `none | light | heavy` or similar
- `postWorkoutCleansDelay`
- `frictionFactors[]`
- `breakoutRisk`
- `createdAt`

### Contact log

- `id`
- `userId`
- `date`
- `pillowcaseChanged`
- `phoneScreenCleaned`
- `maskWorn`
- `helmetWorn`
- `touchedFace`
- `hairProductContact`
- `makeupWorn`
- `makeupRemoved`
- `createdAt`

### Product scan

- `id`
- `userId`
- `timestamp`
- `productName`
- `brand?`
- `category`
- `inputMethod: "manual"`
- `ingredients[]`
- `overallRisk`
- `comedogenicScore`
- `irritationRisk`
- `barrierSupportScore`
- `acneTriggerLikelihood`
- `conclusion`
- `confidenceLevel`
- `inRoutine`
- `addedAt`
- `appVersion`

## 11) Current AI/ML/analytics logic

### Intelligence readiness

The app calculates readiness locally based on counts:

- Face scans weighted `* 8`
- Sleep logs `* 3`
- Food logs `* 3`
- Activity logs `* 2`
- Stress logs `* 2`
- Product scans `* 4`
- Trigger correlations `* 5`
- Capped at 100

Model tier:

- `<20`: `bootstrap`
- `<50`: `developing`
- `<80`: `calibrated`
- otherwise: `advanced`

### Cutis Health Index

Local deterministic formula function in bundle: `ZW(...)`.

Components:

- `barrierIntegrity`
- `inflammationLoad`
- `breakoutPressure`
- `oilDryBalance`
- `healingVelocity`
- `sensitivityRisk`

Overall weighted score:

- Barrier integrity: 25%
- Inflammation load: 20%
- Breakout pressure: 20%
- Oil/dry balance: 15%
- Healing velocity: 10%
- Sensitivity risk: 10%

Statuses:

- `healthy` >= 80
- `stable` >= 65
- `watchlist` >= 50
- `at_risk` >= 35
- `compromised` below 35

### Trigger correlation

Local formula function in bundle: `WW(...)`.

Detected triggers:

- Poor Sleep Quality
- High Glycemic Diet
- Dairy Consumption
- Elevated Stress

It uses simple averages/correlation and needs only a few points. This is not a validated ML model.

### Forecasting

Local formula function in bundle: `h5(...)`.

Fields returned:

- `userId`
- `generatedAt`
- `horizon` (`7d` etc.)
- `currentRisk`
- `forecastedRisk`
- `bestCaseRisk`
- `worstCaseRisk`
- `confidence`
- `validationStatus`
- `keyDrivers[]`
- `recommendations[]`
- `scenario`
- `estimatedImprovementDays`

This is a deterministic heuristic, not a trained model.

### What-if scenarios

Local formula function in bundle: `XW(...)`.

It adjusts risk by changed factors and magnitudes, then returns `simulatedRisk`, `estimatedImprovementDays`, and explanation.

### FormulaLens ingredient analyzer

Ingredient dictionary is hardcoded in the bundle. It includes acne/comedogenic/barrier notes for ingredients such as:

- cocoa butter
- coconut oil
- mineral oil
- niacinamide
- retinol/retinoids
- salicylic acid
- benzoyl peroxide
- hyaluronic acid
- ceramides
- isopropyl myristate
- fragrance/parfum
- alcohol/ethanol
- squalane
- petrolatum
- lanolin
- sunflower oil
- glycerin
- and others

Functions:

- `QW(ingredientText)` extracts known ingredients.
- `JW(ingredients)` calculates `overallRisk`, `comedogenicScore`, `irritationRisk`, `barrierSupportScore`, `acneTriggerLikelihood`, `conclusion`, `confidenceLevel`.

### CutisAI chat

The current CutisAI is local and fake-live:

- Store key: `acnetrex_ai_v2`
- Conversations are persisted locally.
- User message triggers a timeout of ~800–2000ms.
- Response generated by local keyword/rule function `eX(question, context)`.
- No LLM call.
- No server-side RAG.
- No actual live learning.

## 12) Current research library

Hardcoded `gb` evidence library contains dermatology references and PubMed URLs. Topics include:

- Diet and acne
- Low glycemic diet RCT
- Milk consumption and acne
- Sleep and skin aging/barrier recovery
- Stress and skin disease
- Niacinamide
- Salicylic acid
- Ceramides/barrier
- Exercise and acne mechanica
- Isotretinoin
- Pollution and skin
- Comedogenic ingredients

Upgrade recommendation: move this to a curated, versioned evidence database/knowledge base, with source metadata, DOI/PubMed IDs, retrieval embeddings, clinical review status, and update workflow.

## 13) Major issues to fix

### Security

- Client-side password hashing with static salt in localStorage is insecure.
- No real auth sessions/tokens.
- No account recovery/email verification.
- Sensitive health data is entirely in localStorage.
- No backend authorization checks because there is no backend.
- Images are not stored now, but future storage must be consent-based, encrypted, and access-controlled.

### AI/ML truthfulness

- App markets itself as “AI-powered” and “clinical-grade,” but current AI/ML is mostly heuristic/random/local.
- Camera analysis does not inspect image pixels.
- Chat assistant is keyword templates, not an embedded live model.
- Forecasting is a hand-coded formula, not trained/validated.
- “Learns” means readiness counters and recalculations, not model learning.

### Medical/compliance risk

- Avoid claiming diagnosis or clinical-grade accuracy without validation.
- Add medical disclaimer and dermatologist escalation guidance.
- Treat data as sensitive health data.
- Add consent/audit trails for research/federated learning.
- If targeting Philippines/users in Asia, align with the Data Privacy Act and general health-data best practices; if serving US/EU users, plan HIPAA/GDPR-style controls as needed.

### Engineering

- Original source is unavailable, only bundle recovered.
- Need rebuild clean source structure instead of editing minified bundle.
- Need typed domain models, API boundaries, tests, and migration from localStorage.

## 14) Upgrade target architecture

Recommended direction: keep React/Vite frontend as foundation, but introduce real backend + ML services.

### Frontend

- React 19 + Vite + TypeScript.
- Keep mobile-first UI/branding/features.
- Split code into modules:
  - `src/app/` routing/layouts/providers
  - `src/features/auth/`
  - `src/features/onboarding/`
  - `src/features/scans/`
  - `src/features/logs/`
  - `src/features/products/`
  - `src/features/forecast/`
  - `src/features/assistant/`
  - `src/features/research/`
  - `src/features/reports/`
  - `src/lib/api/`
  - `src/lib/ml/`
  - `src/types/`
  - `src/stores/`

Use Zustand only for UI/session cache, not as the source of truth for health data.

### Backend/API

Options:

- TypeScript backend: NestJS/Fastify/Express + Prisma.
- Python ML-first backend: FastAPI + SQLAlchemy/Pydantic.
- Hybrid: Node API gateway + Python ML microservice.

Recommended for real ML: FastAPI for ML service plus TypeScript frontend. Use REST or tRPC/OpenAPI clients.

Core services:

- Auth service
- User/profile service
- Logging service
- Image scan service
- Product ingredient service
- Forecast service
- AI assistant service
- Evidence/RAG service
- Report export service
- Notification/reminder service
- Audit/consent service

### Database/storage

- PostgreSQL for users, profiles, logs, products, forecasts, conversations, evidence metadata.
- Object storage for user-uploaded images if consented: S3/R2/GCS/Supabase Storage.
- Redis/queue for async image analysis jobs.
- Vector database for evidence retrieval: pgvector, Qdrant, Pinecone, Weaviate, or Supabase Vector.

### AI/ML service

Separate responsibilities:

1. **Computer vision scan engine**
   - Validate image quality.
   - Face detection/alignment.
   - Region segmentation: forehead, cheeks, nose, chin, jawline.
   - Acne lesion detection/classification: comedones, papules, pustules, nodules/cysts, PIH marks.
   - Output confidence, bounding boxes/masks, zone metrics, severity estimates.
   - Store model version and inference metadata.

2. **Forecast/personalization engine**
   - Start with transparent baseline model: logistic regression, gradient boosting, or calibrated Bayesian model.
   - Inputs: recent lesion count, sleep, stress, diet, hydration, activity/sweat, product risks, cycle, climate, contact factors.
   - Outputs: risk score, confidence intervals, feature contributions, recommendations.
   - Add per-user calibration only after enough data.
   - Do not silently self-modify production models. Use safe online personalization: user-specific calibration parameters, not uncontrolled model training.

3. **CutisAI assistant**
   - LLM call through backend only, never directly from browser with secret keys.
   - RAG over curated dermatology evidence and user’s own data.
   - Tool/function calls:
     - get latest CHI
     - get trend summaries
     - get trigger correlations
     - get product analysis
     - get forecast
     - retrieve evidence
   - Guardrails:
     - no diagnosis
     - no prescription advice beyond general education
     - dermatologist escalation for severe/cystic acne, infection, scarring, medication questions, isotretinoin, pregnancy, etc.
   - Return citations/sources and confidence.

4. **Learning system**
   - Event tracking of predictions vs actual outcomes.
   - Feedback capture: “Was this helpful?”, “Did breakout occur?”, user corrections.
   - Model monitoring: calibration, drift, bias, error rates by skin tone/lighting/image quality.
   - Federated learning only if explicit consent, privacy protections, secure aggregation, and a real governance plan.

## 15) Suggested database model names

Minimum tables/entities:

- `users`
- `auth_accounts` or managed auth provider users
- `user_profiles`
- `consents`
- `onboarding_profiles`
- `face_scans`
- `face_scan_zones`
- `face_scan_lesions`
- `sleep_logs`
- `food_logs`
- `food_items`
- `stress_logs`
- `activity_logs`
- `contact_logs`
- `cycle_logs`
- `weather_contexts`
- `product_scans`
- `product_ingredients`
- `health_index_snapshots`
- `trigger_correlations`
- `forecasts`
- `what_if_scenarios`
- `assistant_conversations`
- `assistant_messages`
- `evidence_sources`
- `model_runs`
- `model_versions`
- `prediction_feedback`
- `audit_logs`

## 16) API endpoints to implement

Suggested REST shape:

Auth:

- `POST /auth/signup`
- `POST /auth/login`
- `POST /auth/logout`
- `GET /auth/me`

Profile/onboarding:

- `GET /profile`
- `PATCH /profile`
- `GET /onboarding`
- `PATCH /onboarding`
- `POST /onboarding/complete`

Logs:

- `GET /logs/today`
- `POST /logs/sleep`
- `POST /logs/food`
- `POST /logs/stress`
- `POST /logs/activity`
- `POST /logs/contact`
- `POST /logs/cycle`

Scans:

- `POST /scans` multipart upload
- `GET /scans`
- `GET /scans/:id`
- `POST /scans/:id/analyze`

Products:

- `POST /products/analyze`
- `POST /products`
- `GET /products`
- `PATCH /products/:id`

Analytics:

- `GET /health-index/latest`
- `GET /health-index/history`
- `POST /health-index/recalculate`
- `GET /triggers`
- `POST /forecast`
- `POST /what-if`

Assistant:

- `POST /assistant/conversations`
- `GET /assistant/conversations`
- `POST /assistant/conversations/:id/messages`

Evidence:

- `GET /evidence/search?q=`
- `GET /evidence/:id`

Reports:

- `GET /reports/export.json`
- `GET /reports/export.pdf`

## 17) Migration plan from current localStorage

1. On first launch after upgrade, detect old local keys:
   - `acnetrex_auth_v2`
   - `acnetrex_data_v2`
   - `acnetrex_ai_v2`
2. Ask user to sign in/create a secure account.
3. Ask explicit consent to import local demo data.
4. Parse Zustand persisted payloads and map to backend entities.
5. Mark imported records with:
   - `source: "localStorage_v2"`
   - `importedAt`
   - `legacyId`
6. Do not import old password hashes as real credentials.
7. After successful import, keep a local backup/export option and then clear/disable legacy auth.

## 18) What Claude should preserve from existing site

Preserve:

- Name/brand: AcneTrex.
- Dark, polished mobile-first look.
- The main feature map and route names.
- The user journey: auth → onboarding → dashboard → daily logs/scans → insights/forecast/assistant.
- The domain concepts:
  - Cutis Health Index
  - FaceAtlas
  - TriggerGraph
  - ClearPath Forecast
  - BarrierGuard
  - FormulaLens
  - CutisAI
  - SleepDerm/DermDiet/SweatFlow
  - Skin Digital Twin
- The current local data schemas as migration-compatible fields.
- Evidence-backed tone.

Replace:

- Client-side auth.
- Fake camera inference.
- Keyword/template chat.
- Heuristic-only forecasting marketed as AI.
- LocalStorage as source of truth.
- Hardcoded evidence as the only knowledge source.

## 19) Upgrade acceptance criteria

A real upgraded version should satisfy:

- Secure server-side auth with proper password/session handling.
- Data stored in database with user-level authorization.
- Optional encrypted image storage with explicit consent.
- Actual image analysis pipeline, even if initially a hosted API or baseline ML model.
- CutisAI calls backend assistant service and uses user data + evidence retrieval.
- Forecasts persist model version, confidence, feature drivers, and prediction feedback.
- Responsive UI beyond mobile: excellent mobile, tablet, desktop layouts.
- Offline/local-first mode can cache logs, but must sync to backend.
- Privacy controls: export data, delete account/data, consent toggles.
- Test coverage for scoring formulas, API schema, auth flows, and critical UI.
- No unsupported clinical claims.

## 20) Suggested prompt to give Claude

Use this with the recovered artifacts:

```text
You are upgrading an existing React/Vite/Tailwind app called AcneTrex. I do not have the original src folder, but I have recovered the deployed single-file build and a prettified JS bundle. Treat `acnetrex_recovered/artifacts/deployed-bundle.pretty.js` as the behavioral reference, not as code to edit directly.

Goal: rebuild AcneTrex as a maintainable, modern, responsive, production-ready app while preserving the existing product foundation, UI concepts, route structure, data fields, and feature names. Current app is a client-only prototype using localStorage/Zustand and fake AI/ML. Upgrade it so auth, storage, AI assistant, image analysis, forecasting, and learning are real services with safe privacy controls.

Current stack from package.json: React 19.2.6, Vite 7.3.2, TypeScript 5.9.3, Tailwind CSS 4.1.17, Zustand 5, React Router DOM 7, React Hook Form, Zod, Framer Motion, Lucide, Recharts, date-fns.

Preserve routes: /auth, /onboarding, /, /log/face, /log/sleep, /log/food, /log/stress, /log/activity, /face-atlas, /triggers, /forecast, /barrier, /products, /research, /ai, /intelligence, /skin-twin, /sleep, /diet, /activity, /cycle, /contact, /climate, /reports, /profile.

Preserve feature names: FaceAtlas, Cutis Health Index, TriggerGraph, ClearPath Forecast, BarrierGuard, FormulaLens, CutisAI, SleepDerm, DermDiet, SweatFlow, CycleSync, ContactGuard, ClimateSkin, Skin Digital Twin, Reports.

Important current localStorage keys for migration: acnetrex_credentials, acnetrex_auth_v2, acnetrex_data_v2, acnetrex_ai_v2. Do not keep client-side password hashing; only build import/migration support for old local demo data.

Build a clean source architecture. Create typed domain models matching the current store fields. Implement an API layer and backend integration points. If backend cannot be fully implemented in this pass, create clean adapters/mocks that exactly match the intended API contracts.

AI/ML requirements:
1. Replace fake face scan function with an inference API interface that can call a real CV model/service. Return zones, lesion counts/types, redness/oiliness/dryness scores, quality, confidence, and model version.
2. Replace CutisAI template function with backend LLM/RAG service interface. It must use user data context and curated evidence retrieval, return citations, confidence, and safe medical disclaimers.
3. Replace heuristic-only forecast with a forecast service interface that returns risk, confidence interval, drivers, recommendations, model version, and feedback hooks.
4. Implement safe learning: collect prediction feedback and per-user calibration; do not create uncontrolled self-modifying model behavior.

Security/privacy requirements: server-side auth, database persistence, user authorization, consent for images/research/federated learning, export/delete data, audit logging, no unsupported clinical diagnosis claims.

Responsiveness: keep mobile-first polish but add tablet/desktop layouts with adaptive dashboard grids, responsive charts, and accessible forms.

Start by reconstructing the app structure, then migrate features incrementally from the recovered bundle behavior into clean modules.
```
