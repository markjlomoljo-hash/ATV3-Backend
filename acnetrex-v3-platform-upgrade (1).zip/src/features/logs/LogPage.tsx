import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { format } from "date-fns";
import { Moon, Apple, Activity, Droplet, type LucideIcon } from "lucide-react";
import { upsertDailyLog, getTodayLog } from "../../lib/api/entities";
import type { StoreName } from "../../lib/db";
import { useAuthStore } from "../../stores/auth";
import { Button, Card, ErrorBanner } from "../../components/shared/ui";
import { cn } from "../../utils/cn";

type FieldType = "slider" | "segmented" | "toggle";
interface Field {
  key: string;
  label: string;
  type: FieldType;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  options?: { label: string; value: number }[];
  default: number;
}

interface LogConfig {
  store: StoreName;
  title: string;
  type: string;
  icon: LucideIcon;
  intro: string;
  fields: Field[];
}

const GLY = [
  { label: "None", value: 0 },
  { label: "Low", value: 1 },
  { label: "Moderate", value: 2 },
  { label: "High", value: 3 },
];

const CONFIGS: Record<string, LogConfig> = {
  sleep: {
    store: "SleepLog",
    title: "Log Sleep",
    type: "sleep",
    icon: Moon,
    intro: "Sleep quality affects barrier recovery and inflammation.",
    fields: [
      { key: "hours", label: "Hours slept", type: "slider", min: 0, max: 12, step: 0.5, unit: "h", default: 7 },
      { key: "quality", label: "Sleep quality", type: "segmented", options: [
        { label: "Poor", value: 1 }, { label: "Fair", value: 2 }, { label: "OK", value: 3 }, { label: "Good", value: 4 }, { label: "Great", value: 5 },
      ], default: 3 },
    ],
  },
  food: {
    store: "FoodLog",
    title: "Log Diet",
    type: "food",
    icon: Apple,
    intro: "High-glycemic and dairy intake are common dietary triggers.",
    fields: [
      { key: "glycemic", label: "High-glycemic foods today", type: "segmented", options: GLY, default: 1 },
      { key: "dairy", label: "Dairy consumed", type: "toggle", default: 0 },
      { key: "greasy", label: "Greasy / fried foods", type: "toggle", default: 0 },
    ],
  },
  stress: {
    store: "StressLog",
    title: "Log Stress",
    type: "stress",
    icon: Activity,
    intro: "Stress drives cortisol and can worsen inflammatory acne.",
    fields: [{ key: "level", label: "Stress level", type: "slider", min: 0, max: 100, step: 5, unit: "/100", default: 40 }],
  },
  activity: {
    store: "ActivityLog",
    title: "Log Activity",
    type: "activity",
    icon: Droplet,
    intro: "Movement, sweat and hydration all shape your skin context.",
    fields: [
      { key: "minutes", label: "Active minutes", type: "slider", min: 0, max: 180, step: 10, unit: "min", default: 30 },
      { key: "sweat", label: "Sweat intensity", type: "slider", min: 0, max: 100, step: 10, unit: "/100", default: 40 },
    ],
  },
};

export default function LogPage() {
  const { type } = useParams<{ type: string }>();
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);

  // /log/face redirects to FaceAtlas (no scanning in generic log form)
  useEffect(() => {
    if (type === "face") navigate("/face-atlas", { replace: true });
  }, [type, navigate]);

  const config = type ? CONFIGS[type] : undefined;
  const [values, setValues] = useState<Record<string, number>>({});
  const [note, setNote] = useState("");
  const [hydration, setHydration] = useState(2);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedToday, setSavedToday] = useState(false);
  const savingRef = useRef(false);

  useEffect(() => {
    if (!config || !user) return;
    setValues(Object.fromEntries(config.fields.map((f) => [f.key, f.default])));
    void (async () => {
      const existing = await getTodayLog(config.store, user.id);
      if (existing) {
        setValues((existing.values as Record<string, number>) ?? {});
        setNote((existing.note as string) ?? "");
        setSavedToday(true);
      }
    })();
  }, [type]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!config) {
    return type === "face" ? null : <p className="py-10 text-center text-sm text-muted">Unknown log type.</p>;
  }

  const save = async () => {
    if (savingRef.current || !user) return;
    savingRef.current = true;
    setSaving(true);
    setError(null);
    try {
      await upsertDailyLog(config.store, user.id, { type: config.type, values, note });
      if (type === "activity") {
        await upsertDailyLog("HydrationLog", user.id, { type: "hydration", values: { liters: hydration }, note: "" });
      }
      navigate(-1);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save log");
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };

  const Icon = config.icon;

  return (
    <div className="space-y-4 pb-6">
      <Card className="flex items-center gap-3 p-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-soft text-primary">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-semibold text-ink">{format(new Date(), "EEEE, MMM d")}</p>
          <p className="text-xs text-muted">{savedToday ? "Updating today's entry" : config.intro}</p>
        </div>
      </Card>

      {config.fields.map((f) => (
        <Card key={f.key} className="space-y-3 p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-ink">{f.label}</span>
            {f.type === "slider" && <span className="text-sm font-semibold text-primary">{values[f.key] ?? f.default}{f.unit}</span>}
          </div>
          {f.type === "slider" && (
            <input type="range" min={f.min} max={f.max} step={f.step} value={values[f.key] ?? f.default} onChange={(e) => setValues((v) => ({ ...v, [f.key]: Number(e.target.value) }))} className="w-full accent-[#7C6EE6]" />
          )}
          {f.type === "segmented" && (
            <div className="grid grid-cols-4 gap-1.5">
              {f.options!.map((o) => (
                <button key={o.value} onClick={() => setValues((v) => ({ ...v, [f.key]: o.value }))} className={cn("min-h-[2.5rem] rounded-lg border text-xs font-medium", (values[f.key] ?? f.default) === o.value ? "border-primary bg-primary-soft text-primary" : "border-line text-ink")}>
                  {o.label}
                </button>
              ))}
            </div>
          )}
          {f.type === "toggle" && (
            <button onClick={() => setValues((v) => ({ ...v, [f.key]: (values[f.key] ?? 0) ? 0 : 1 }))} className={cn("flex h-11 w-full items-center justify-between rounded-xl border px-4 text-sm font-medium", (values[f.key] ?? 0) ? "border-primary bg-primary-soft text-primary" : "border-line text-ink")}>
              {(values[f.key] ?? 0) ? "Yes" : "No"}
              <span className={cn("h-6 w-11 rounded-full p-0.5 transition-colors", (values[f.key] ?? 0) ? "bg-primary" : "bg-line")}>
                <span className={cn("block h-5 w-5 rounded-full bg-white transition-transform", (values[f.key] ?? 0) && "translate-x-5")} />
              </span>
            </button>
          )}
        </Card>
      ))}

      {type === "activity" && (
        <Card className="space-y-3 p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-ink">Water intake</span>
            <span className="text-sm font-semibold text-primary">{hydration}L</span>
          </div>
          <input type="range" min={0} max={5} step={0.25} value={hydration} onChange={(e) => setHydration(Number(e.target.value))} className="w-full accent-[#7C6EE6]" />
        </Card>
      )}

      <Card className="p-4">
        <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Notes (optional)" rows={2} className="w-full resize-none text-sm text-ink outline-none placeholder:text-muted" />
      </Card>

      {error && <ErrorBanner message={error} />}

      <Button full size="lg" loading={saving} onClick={save}>
        {savedToday ? "Update today's log" : "Save log"}
      </Button>
    </div>
  );
}
