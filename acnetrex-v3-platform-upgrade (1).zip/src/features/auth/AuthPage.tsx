import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { auth } from "../../lib/api/auth";
import { useAuthStore } from "../../stores/auth";
import { Button, ErrorBanner } from "../../components/shared/ui";
import { cn } from "../../utils/cn";

type Mode = "login" | "signup" | "reset";

export default function AuthPage() {
  const navigate = useNavigate();
  const setUser = useAuthStore((s) => s.setUser);
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const submittingRef = useRef(false);

  const submit = async () => {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSubmitting(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === "signup") {
        const u = await auth.signUp(name, email, password, remember);
        setUser(u);
        navigate("/onboarding");
      } else if (mode === "login") {
        const u = await auth.login(email, password, remember);
        setUser(u);
        navigate("/");
      } else {
        await auth.resetPassword(email, password);
        setInfo("Password updated. You can now sign in.");
        setMode("login");
        setPassword("");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  };

  const inputCls = "h-12 w-full rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none focus:border-primary";

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col justify-center px-6 py-10">
      <div className="mb-8 flex flex-col items-center text-center">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-white shadow-lg shadow-primary/20">
          <Sparkles className="h-8 w-8" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-ink">AcneTrex</h1>
        <p className="mt-1 text-sm text-muted">AI skin intelligence & breakout forecasting</p>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
        className="space-y-3"
      >
        {mode === "signup" && (
          <input className={inputCls} placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" />
        )}
        <input className={inputCls} type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
        <input
          className={inputCls}
          type="password"
          placeholder={mode === "reset" ? "New password" : "Password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete={mode === "login" ? "current-password" : "new-password"}
        />

        {mode !== "reset" && (
          <label className="flex items-center gap-2 px-1 text-sm text-muted">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="h-4 w-4 accent-[#7C6EE6]" />
            Remember me
          </label>
        )}

        {error && <ErrorBanner message={error} />}
        {info && <div className="rounded-xl border border-[#cdeede] bg-[#eafaf3] px-4 py-3 text-sm text-clear">{info}</div>}

        <Button type="submit" full size="lg" loading={submitting}>
          {mode === "signup" ? "Create account" : mode === "reset" ? "Reset password" : "Sign in"}
        </Button>
      </form>

      <div className="mt-6 flex flex-col items-center gap-2 text-sm">
        {mode === "login" && (
          <>
            <button onClick={() => { setMode("signup"); setError(null); }} className="text-muted">
              New to AcneTrex? <span className="font-semibold text-primary">Create an account</span>
            </button>
            <button onClick={() => { setMode("reset"); setError(null); }} className="text-muted">
              Forgot password?
            </button>
          </>
        )}
        {mode !== "login" && (
          <button onClick={() => { setMode("login"); setError(null); }} className={cn("font-semibold text-primary")}>
            Back to sign in
          </button>
        )}
      </div>
    </div>
  );
}
