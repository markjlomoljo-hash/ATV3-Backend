import { useCallback, useEffect, useRef, useState } from "react";
import { useDropzone } from "react-dropzone";
import { FlaskConical, Upload, AlertTriangle, CheckCircle2 } from "lucide-react";
import { useAuthStore } from "../../stores/auth";
import { useEngineData } from "../../hooks/useEngineData";
import { analyzeProduct, type ProductAnalysis } from "../../lib/ml/product";
import { createRecord, listRecords } from "../../lib/api/entities";
import { emitEvent } from "../../lib/ai/intelligence";
import { ENGINE_VERSIONS } from "../../lib/constants";
import { productScanSchema, type ProductScan } from "../../lib/schemas";
import { Badge, Button, Card, ConfidenceBadge, ErrorBanner, Progress, Spinner } from "../../components/shared/ui";
import { EmptyState } from "../../components/shared/states";

export default function Products() {
  const user = useAuthStore((s) => s.user);
  const { bundle } = useEngineData();
  const [brand, setBrand] = useState("");
  const [name, setName] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [result, setResult] = useState<ProductAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [history, setHistory] = useState<ProductScan[]>([]);
  const [loaded, setLoaded] = useState(false);
  const submittingRef = useRef(false);

  const load = useCallback(async () => {
    if (!user) return;
    const rows = await listRecords("ProductScan", productScanSchema, { created_by_id: user.id }, { limit: 10, sort: "-created_date" });
    setHistory(rows as ProductScan[]);
    setLoaded(true);
  }, [user]);

  useEffect(() => { void load(); }, [load]);

  const onDrop = useCallback((files: File[]) => {
    const f = files[0];
    if (f) setIngredients((p) => p + (p ? "\n" : "") + `[Label image attached: ${f.name}] — paste the ingredient text here for analysis.`);
  }, []);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { "image/*": [] }, maxFiles: 1 });

  const run = async () => {
    if (submittingRef.current || !user) return;
    if (!ingredients.trim()) { setError("Add an ingredient list to analyse."); return; }
    submittingRef.current = true;
    setAnalyzing(true);
    setError(null);
    try {
      await emitEvent({ userId: user.id, engineType: "FormulaLens", operation: "analyze", status: "started", modelVersion: ENGINE_VERSIONS.product });
      const analysis = analyzeProduct(ingredients, bundle?.profile ?? null);
      const rec = (await createRecord(
        "ProductScan",
        { brand: brand || "Unknown", productName: name || "Unnamed product", category: "skincare", ...analysis },
        { userId: user.id, source: "ai_engine" },
      )) as unknown as ProductScan;
      const parsed = productScanSchema.safeParse(rec);
      if (!parsed.success) throw new Error("Analysis failed validation.");
      await emitEvent({
        userId: user.id, engineType: "FormulaLens", operation: "analyze",
        status: analysis.validationStatus === "insufficient" ? "rejected" : "validated",
        modelVersion: ENGINE_VERSIONS.product, confidence: analysis.confidence, validationStatus: analysis.validationStatus,
        inputRefs: [rec.id], downstreamConsumers: ["CutisAI", "ClearPath"],
      });
      setResult(analysis);
      await load();
    } catch (e) {
      await emitEvent({ userId: user.id, engineType: "FormulaLens", operation: "analyze", status: "failed" }).catch(() => undefined);
      setError(e instanceof Error ? e.message : "Analysis failed");
    } finally {
      submittingRef.current = false;
      setAnalyzing(false);
    }
  };

  const inputCls = "h-11 w-full rounded-xl border border-line bg-surface px-4 text-sm outline-none focus:border-primary";

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-3 p-4">
        <div className="flex items-center gap-2"><FlaskConical className="h-5 w-5 text-primary" /><span className="font-semibold text-ink">FormulaLens</span></div>
        <p className="text-xs text-muted">Enter a product or paste its ingredient list. We score comedogenic, irritant and barrier risk against your skin profile.</p>
        <div className="grid grid-cols-2 gap-2">
          <input className={inputCls} placeholder="Brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
          <input className={inputCls} placeholder="Product name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div {...getRootProps()} className={`flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed py-4 text-sm ${isDragActive ? "border-primary bg-primary-soft text-primary" : "border-line text-muted"}`}>
          <input {...getInputProps()} />
          <Upload className="h-4 w-4" /> Drop a label photo or tap
        </div>
        <textarea className="w-full resize-none rounded-xl border border-line bg-surface p-3 text-sm outline-none focus:border-primary" rows={4} placeholder="Paste ingredients, e.g. Water, Glycerin, Coconut Oil, Fragrance…" value={ingredients} onChange={(e) => setIngredients(e.target.value)} />
        {error && <ErrorBanner message={error} />}
        <Button full loading={analyzing} onClick={run}>Analyze ingredients</Button>
      </Card>

      {analyzing && <Spinner label="Cross-referencing ingredients…" />}

      {result && (
        <Card className="space-y-3 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {result.acneContribution === "high" ? <AlertTriangle className="h-5 w-5 text-flare" /> : <CheckCircle2 className="h-5 w-5 text-clear" />}
              <span className="font-semibold text-ink">{result.verdict}</span>
            </div>
            <ConfidenceBadge confidence={result.confidence} />
          </div>
          <Badge tone={result.acneContribution === "high" ? "flare" : result.acneContribution === "moderate" ? "accent" : "clear"}>{result.acneContribution} acne contribution</Badge>
          <div className="space-y-2 pt-1">
            <RiskBar label="Comedogenic" value={result.comedogenicRisk} />
            <RiskBar label="Irritant" value={result.irritantRisk} />
            <RiskBar label="Barrier" value={result.barrierRisk} />
          </div>
          <p className="text-xs text-muted">{result.rationale}</p>
          <div className="space-y-1 border-t border-line pt-2">
            <span className="text-xs font-semibold text-ink">Flagged ingredients</span>
            {result.ingredients.filter((i) => i.comedogenic >= 3 || i.irritant).slice(0, 6).map((i) => (
              <div key={i.name} className="flex items-center justify-between text-xs">
                <span className="capitalize text-ink">{i.name}</span>
                <span className="text-muted">{i.function}{i.comedogenic >= 3 ? ` · comedo ${i.comedogenic}/5` : ""}</span>
              </div>
            ))}
            {result.ingredients.filter((i) => i.comedogenic >= 3 || i.irritant).length === 0 && <p className="text-xs text-muted">No high-risk ingredients flagged.</p>}
          </div>
          <p className="text-[10px] text-muted">Evidence: {result.evidenceRefs.join(", ")}</p>
        </Card>
      )}

      {loaded && history.length === 0 && !result ? (
        <EmptyState icon={FlaskConical} title="No products analysed yet" description="Analyse your skincare to see which formulas may be feeding breakouts." ctaLabel="Analyze a product" ctaRoute="/products" />
      ) : (
        history.length > 0 && (
          <Card className="space-y-2 p-4">
            <span className="text-sm font-semibold text-ink">Your product history</span>
            {history.map((h) => (
              <div key={h.id} className="flex items-center justify-between border-b border-line py-2 last:border-0">
                <div>
                  <p className="text-sm font-medium text-ink">{h.brand} · {h.productName}</p>
                  <p className="text-xs text-muted">{h.verdict}</p>
                </div>
                <Badge tone={h.acneContribution === "high" ? "flare" : h.acneContribution === "moderate" ? "accent" : "clear"}>{h.acneContribution}</Badge>
              </div>
            ))}
          </Card>
        )
      )}
    </div>
  );
}

function RiskBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs"><span className="text-muted">{label} risk</span><span className="font-semibold text-ink">{value}</span></div>
      <Progress value={value} tone={value > 60 ? "flare" : value > 32 ? "accent" : "clear"} />
    </div>
  );
}
