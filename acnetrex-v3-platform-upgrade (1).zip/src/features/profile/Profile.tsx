import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, ShieldCheck, Trash2, LogOut, Download } from "lucide-react";
import { useAuthStore } from "../../stores/auth";
import { useConsent } from "../../hooks/useConsent";
import { listRecords, softDeleteOwner } from "../../lib/api/entities";
import { db, STORES } from "../../lib/db";
import { onboardingProfileSchema, type OnboardingProfile } from "../../lib/schemas";
import { Badge, Button, Card, Spinner } from "../../components/shared/ui";

export default function Profile() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { consentStatus, canContributeToNetwork, grantConsent, revokeConsent } = useConsent();
  const [profile, setProfile] = useState<OnboardingProfile | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!user) return;
    void (async () => {
      const rows = await listRecords("OnboardingProfile", onboardingProfileSchema, { created_by_id: user.id }, { limit: 1, sort: "-created_date" });
      setProfile((rows[0] as OnboardingProfile) ?? null);
      setLoaded(true);
    })();
  }, [user]);

  const exportData = async () => {
    if (!user) return;
    const dump: Record<string, unknown> = { exportedAt: new Date().toISOString(), userId: user.id };
    for (const store of STORES) {
      if (store === "users") continue;
      const all = await db.getAll(store);
      dump[store] = all.filter((r) => (r as { created_by_id?: string }).created_by_id === user.id);
    }
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "acnetrex_data_export.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const deleteAccount = async () => {
    if (!user) return;
    if (!confirm("Delete your account? Your records will be marked deleted and hidden immediately, then purged after the grace period. This cannot be undone.")) return;
    const now = new Date().toISOString();
    const u = await db.get("users", user.id);
    if (u) await db.put("users", { ...u, deletedAt: now, deletionRequestedAt: now, ownerDeleted: true });
    await softDeleteOwner(user.id, STORES.filter((s) => s !== "users") as never);
    await logout();
    navigate("/auth");
  };

  if (!loaded) return <Spinner />;

  return (
    <div className="space-y-4 pb-6">
      <Card className="flex items-center gap-3 p-5">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-xl font-bold text-white">
          {user?.name?.[0]?.toUpperCase() ?? "U"}
        </div>
        <div>
          <p className="font-semibold text-ink">{user?.name}</p>
          <p className="text-sm text-muted">{user?.email}</p>
        </div>
      </Card>

      {profile && (
        <Card className="space-y-2 p-4">
          <div className="flex items-center gap-2"><User className="h-4 w-4 text-primary" /><span className="text-sm font-semibold text-ink">Skin profile</span></div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <Field label="Skin type" value={profile.skinType} />
            <Field label="Severity" value={profile.acneSeverity} />
            <Field label="Age" value={String(profile.age)} />
            <Field label="Concern" value={profile.primaryConcern} />
          </div>
          {profile.knownTriggers.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {profile.knownTriggers.map((t) => <Badge key={t} tone="neutral">{t}</Badge>)}
            </div>
          )}
          <Button variant="ghost" full onClick={() => navigate("/onboarding")}>Edit profile</Button>
        </Card>
      )}

      <Card className="space-y-3 p-4">
        <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-clear" /><span className="text-sm font-semibold text-ink">Privacy & data control</span></div>
        <div className="flex items-center justify-between rounded-xl bg-canvas p-3">
          <div>
            <p className="text-sm font-medium text-ink">Research network</p>
            <p className="text-xs text-muted">Privacy-preserving cohort learning</p>
          </div>
          <Badge tone={canContributeToNetwork ? "clear" : "neutral"}>{consentStatus}</Badge>
        </div>
        {canContributeToNetwork ? (
          <Button variant="secondary" full onClick={() => { if (confirm("Revoke research consent? Past anonymous aggregates cannot be retracted, but no new data will be shared.")) void revokeConsent(); }}>Revoke consent</Button>
        ) : (
          <Button variant="secondary" full onClick={() => void grantConsent()}>Enable research participation</Button>
        )}
        <Button variant="ghost" full onClick={exportData}><Download className="h-4 w-4" /> Export my data (JSON)</Button>
      </Card>

      <Card className="space-y-2 p-4">
        <Button variant="ghost" full onClick={async () => { await logout(); navigate("/auth"); }}><LogOut className="h-4 w-4" /> Log out</Button>
        <Button variant="danger" full onClick={deleteAccount}><Trash2 className="h-4 w-4" /> Delete account</Button>
      </Card>

      <p className="px-2 text-center text-[10px] text-muted">AcneTrex v3.0.0 · Informational use only. Not a substitute for professional medical advice.</p>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-canvas p-2">
      <p className="text-[10px] uppercase tracking-wide text-muted">{label}</p>
      <p className="font-medium capitalize text-ink">{value}</p>
    </div>
  );
}
