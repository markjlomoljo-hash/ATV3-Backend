import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { Sparkles, TrendingUp, ScanFace, ChevronRight, Flame, ShieldCheck } from "lucide-react";
import { useAuthStore } from "../../stores/auth";
import { useEngineData } from "../../hooks/useEngineData";
import { computeCHI, computeForecast } from "../../lib/ml/engines";
import { DAILY_TASKS, DATA_THRESHOLDS } from "../../lib/constants";
import { Badge, Button, Card, Progress, Ring, Spinner } from "../../components/shared/ui";
import { EmptyState } from "../../components/shared/states";

export default function Dashboard() {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const { bundle, loading } = useEngineData();

  const today = format(new Date(), "yyyy-MM-dd");

  const taskState = useMemo(() => {
    if (!bundle) return { done: new Set<string>(), points: 0, total: 0 };
    const done = new Set<string>();
    for (const t of DAILY_TASKS) {
      const list = t.store === "FaceScan" ? bundle.scans : bundle.logsByType[t.store] ?? [];
      if (list.some((r) => (r as { logDate?: string }).logDate === today)) done.add(t.id);
    }
    const points = DAILY_TASKS.filter((t) => done.has(t.id)).reduce((a, t) => a + t.points, 0);
    const total = DAILY_TASKS.reduce((a, t) => a + t.points, 0);
    return { done, points, total };
  }, [bundle, today]);

  if (loading || !bundle) return <Spinner label="Loading your skin intelligence…" />;

  const totalData = bundle.scans.length + Object.values(bundle.logsByType).flat().length;
  const hasAny = totalData > 0;
  const chi = computeCHI(bundle);
  const forecast = computeForecast(bundle);
  const chiReady = chi.contributingLogs >= DATA_THRESHOLDS.CHI_MIN_LOGS;

  return (
    <div className="space-y-5 pb-6">
      <div className="flex items-center justify-between px-1">
        <div>
          <p className="text-sm text-muted">{format(new Date(), "EEEE, MMMM d")}</p>
          <h1 className="text-xl font-bold text-ink">Hi, {user?.name?.split(" ")[0] ?? "there"}</h1>
        </div>
        <button onClick={() => navigate("/ai")} className="flex h-11 items-center gap-1.5 rounded-full bg-primary-soft px-4 text-sm font-semibold text-primary">
          <Sparkles className="h-4 w-4" /> Ask CutisAI
        </button>
      </div>

      {!hasAny && (
        <EmptyState
          icon={ScanFace}
          title="Let's build your skin profile"
          description="Run your first FaceAtlas scan and log a few daily factors. Every engine below activates with real data."
          ctaLabel="Start a FaceAtlas scan"
          ctaRoute="/face-atlas"
        />
      )}

      {/* CHI hero */}
      <Card className="p-5">
        <div className="flex items-center gap-5">
          {chiReady ? (
            <Ring value={chi.chi} sublabel="CHI" tone={chi.chi >= 70 ? "#3FBF8F" : chi.chi >= 45 ? "#7C6EE6" : "#F26D7D"} />
          ) : (
            <div className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-dashed border-line text-center text-[10px] font-medium text-muted">
              Need {DATA_THRESHOLDS.CHI_MIN_LOGS} logs
            </div>
          )}
          <div className="flex-1 space-y-1">
            <p className="text-sm font-semibold text-ink">Cutis Health Index</p>
            {chiReady ? (
              <>
                <Badge tone={chi.trend === "improving" ? "clear" : chi.trend === "worsening" ? "flare" : "neutral"}>{chi.trend}</Badge>
                <p className="text-xs text-muted">Inflammation {chi.inflammation} · Barrier {chi.barrier} · Consistency {chi.consistency}</p>
              </>
            ) : (
              <p className="text-xs text-muted">Log {DATA_THRESHOLDS.CHI_MIN_LOGS - chi.contributingLogs} more data point(s) to unlock your index.</p>
            )}
          </div>
        </div>
      </Card>

      {/* Quick forecast + barrier */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="space-y-2 p-4" onClick={() => navigate("/forecast")}>
          <div className="flex items-center gap-2 text-flare"><Flame className="h-4 w-4" /><span className="text-xs font-semibold">Breakout risk</span></div>
          <p className="text-2xl font-bold text-ink">{forecast.validationStatus === "insufficient" ? "—" : forecast.currentRisk}</p>
          <Progress value={forecast.currentRisk} tone="flare" />
        </Card>
        <Card className="space-y-2 p-4" onClick={() => navigate("/barrier")}>
          <div className="flex items-center gap-2 text-clear"><ShieldCheck className="h-4 w-4" /><span className="text-xs font-semibold">Barrier</span></div>
          <p className="text-2xl font-bold text-ink">{chiReady ? chi.barrier : "—"}</p>
          <Progress value={chi.barrier} tone="clear" />
        </Card>
      </div>

      {/* Task board */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-base font-semibold text-ink">Today's tasks</h2>
          <Badge tone="primary">{taskState.points}/{taskState.total} pts</Badge>
        </div>
        <Card className="divide-y divide-line p-0">
          {DAILY_TASKS.map((t) => {
            const done = taskState.done.has(t.id);
            return (
              <button key={t.id} onClick={() => navigate(t.route)} className="flex min-h-[3.25rem] w-full items-center gap-3 px-4 py-3 text-left active:bg-canvas">
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl text-sm font-bold ${done ? "bg-[#e4f7ef] text-clear" : "bg-primary-soft text-primary"}`}>
                  {done ? "✓" : `+${t.points}`}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${done ? "text-muted line-through" : "text-ink"}`}>{t.label}</p>
                  <p className="text-xs text-muted">{t.description}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted" />
              </button>
            );
          })}
        </Card>
      </div>

      <Button variant="secondary" full onClick={() => navigate("/intelligence")}>
        <TrendingUp className="h-4 w-4" /> View Intelligence Core
      </Button>
    </div>
  );
}
