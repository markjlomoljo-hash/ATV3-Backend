import { useCallback, useEffect, useRef, useState } from "react";
import { Sparkles, Send, ThumbsUp, ThumbsDown, BookOpen } from "lucide-react";
import { useAuthStore } from "../../stores/auth";
import { useEngineData } from "../../hooks/useEngineData";
import { generateAssistantAnswer } from "../../lib/ml/assistant";
import { createRecord, listRecords, updateRecord } from "../../lib/api/entities";
import { emitEvent } from "../../lib/ai/intelligence";
import { ENGINE_VERSIONS } from "../../lib/constants";
import { assistantMessageSchema, type AssistantMessage } from "../../lib/schemas";
import { Badge, Button, Card, Spinner } from "../../components/shared/ui";
import { cn } from "../../utils/cn";

const SUGGESTIONS = ["Explain my CHI score", "What are my triggers?", "What's my forecast?", "Build me a routine"];

export default function Assistant() {
  const user = useAuthStore((s) => s.user);
  const { bundle } = useEngineData();
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const threadId = useRef<string>(`thread_${new Date().toISOString().slice(0, 10)}`);
  const submittingRef = useRef(false);
  const endRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    if (!user) return;
    const rows = await listRecords("AssistantMessage", assistantMessageSchema, { created_by_id: user.id }, { limit: 30, sort: "created_date" });
    setMessages(rows as AssistantMessage[]);
    setLoaded(true);
  }, [user]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking]);

  const send = async (text: string) => {
    if (submittingRef.current || !user || !bundle || !text.trim()) return;
    submittingRef.current = true;
    setThinking(true);
    setInput("");
    try {
      const userMsg = (await createRecord(
        "AssistantMessage",
        { role: "user", content: text.trim(), threadId: threadId.current, feedback: null },
        { userId: user.id },
      )) as unknown as AssistantMessage;
      setMessages((m) => [...m, userMsg]);

      await emitEvent({ userId: user.id, engineType: "CutisAI", operation: "answer", status: "started", modelVersion: ENGINE_VERSIONS.assistant });
      const answer = generateAssistantAnswer(text, bundle);
      const aiMsg = (await createRecord(
        "AssistantMessage",
        { role: "assistant", content: answer.content, citations: answer.citations, confidence: answer.confidence, contextRefs: answer.contextRefs, threadId: threadId.current, feedback: null },
        { userId: user.id, source: "ai_engine" },
      )) as unknown as AssistantMessage;
      setMessages((m) => [...m, aiMsg]);

      await emitEvent({
        userId: user.id,
        engineType: "CutisAI",
        operation: "answer",
        status: "validated",
        modelVersion: ENGINE_VERSIONS.assistant,
        confidence: answer.confidence,
        inputRefs: [userMsg.id, aiMsg.id],
        downstreamConsumers: answer.contextRefs,
      });
    } catch {
      await emitEvent({ userId: user.id, engineType: "CutisAI", operation: "answer", status: "failed" }).catch(() => undefined);
    } finally {
      submittingRef.current = false;
      setThinking(false);
    }
  };

  const rate = async (msg: AssistantMessage, feedback: "up" | "down") => {
    if (!user) return;
    await updateRecord("AssistantMessage", msg.id, { feedback }, { userId: user.id });
    setMessages((m) => m.map((x) => (x.id === msg.id ? { ...x, feedback } : x)));
    await emitEvent({ userId: user.id, engineType: "CutisAI", operation: "feedback", status: "learning", message: feedback });
  };

  return (
    <div className="flex h-[calc(100vh-3.5rem-4rem)] flex-col">
      <div className="scroll-touch flex-1 space-y-3 overflow-y-auto pb-4">
        {!loaded ? (
          <Spinner />
        ) : messages.length === 0 ? (
          <Card className="space-y-3 p-5 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-white">
              <Sparkles className="h-6 w-6" />
            </div>
            <p className="text-sm font-semibold text-ink">CutisAI</p>
            <p className="text-sm text-muted">I read your real scans, logs and forecasts to answer with grounded, cited guidance.</p>
          </Card>
        ) : (
          messages.map((m) => (
            <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
              <div className={cn("max-w-[85%] rounded-2xl px-4 py-2.5 text-sm", m.role === "user" ? "bg-primary text-white" : "bg-surface border border-line text-ink")}>
                <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
                {m.role === "assistant" && (
                  <>
                    {m.confidence != null && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge tone={m.confidence >= 0.6 ? "clear" : m.confidence >= 0.4 ? "accent" : "flare"}>Confidence {Math.round(m.confidence * 100)}%</Badge>
                        {m.contextRefs?.map((r) => <Badge key={r} tone="neutral">{r}</Badge>)}
                      </div>
                    )}
                    {m.citations && m.citations.length > 0 && (
                      <div className="mt-2 space-y-1.5 border-t border-line pt-2">
                        {m.citations.map((c, i) => (
                          <div key={i} className="flex items-start gap-1.5 text-xs text-muted">
                            <BookOpen className="mt-0.5 h-3 w-3 shrink-0 text-accent" />
                            <span>{c.title} — <span className="italic">{c.source}{c.year ? `, ${c.year}` : ""}</span></span>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="mt-2 flex gap-2">
                      <button onClick={() => rate(m, "up")} className={cn("flex h-8 w-8 items-center justify-center rounded-lg", m.feedback === "up" ? "bg-[#e4f7ef] text-clear" : "text-muted")}><ThumbsUp className="h-4 w-4" /></button>
                      <button onClick={() => rate(m, "down")} className={cn("flex h-8 w-8 items-center justify-center rounded-lg", m.feedback === "down" ? "bg-[#fde9ec] text-flare" : "text-muted")}><ThumbsDown className="h-4 w-4" /></button>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))
        )}
        {thinking && <div className="flex items-center gap-2 px-2 text-sm text-muted"><span className="h-3 w-3 animate-spin rounded-full border-2 border-primary border-t-transparent" /> CutisAI is reasoning over your data…</div>}
        <div ref={endRef} />
      </div>

      {messages.length === 0 && (
        <div className="mb-2 flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => (
            <button key={s} onClick={() => send(s)} className="rounded-full border border-line bg-surface px-3 py-1.5 text-xs font-medium text-ink active:bg-canvas">{s}</button>
          ))}
        </div>
      )}

      <form
        onSubmit={(e) => { e.preventDefault(); void send(input); }}
        className="flex items-center gap-2 border-t border-line bg-surface pt-3"
      >
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about your skin…" className="h-11 flex-1 rounded-xl border border-line bg-canvas px-4 text-sm outline-none focus:border-primary" />
        <Button type="submit" size="md" className="aspect-square px-0" disabled={!input.trim() || thinking}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}
