import { useMemo, useRef, useState } from "react";
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip, ReferenceLine } from "recharts";
import { TrendingUp, Wand2, ArrowDownRight, ArrowUpRight } from "lucide-react";
import { useEngineData } from "../../hooks/useEngineData";
import { useAuthStore } from "../../stores/auth";
import { computeForecast, simulateWhatIf, computeRiskFactors } from "../../lib/ml/engines";
import { createRecord } from "../../lib/api/entities";
import { emitEvent } from "../../lib/ai/intelligence";
import { ENGINE_VERSIONS, DATA_THRESHOLDS } from "../../lib/constants";
import { Badge, Button, Card, ConfidenceBadge, Spinner } from "../../components/shared/ui";
import { InsufficientDataState } from "../../components/shared/states";

export default function Forecast() {
  const user = useAuthStore((s) => s.user);
  const { bundle, loading } = useEngineData();
  const [saved, setSaved] = useState(false);
  const [whatIf, setWhatIf] = useState<{ changedFactor: string; baselineRisk: number; projectedRisk: number; deltaPct: number; rationale: string } | null>(null);
  const savingRef = useRef(false);

  const dataDays = useMemo(() => (bundle ? new Set(Object.values(bundle.logsByType).flat().map((l) => l.logDate)).size : 0), [bundle]);

  if (loading || !bundle) return <Spinner label="Computing your forecast…" />;

  const forecast = computeForecast(bundle);
  const factors = computeRiskFactors(bundle);

  if (forecast.validationStatus === "insufficient") {
    return (
      <InsufficientDataState
        moduleName="Skin Horizon forecast"
        requiredDataPoints={DATA_THRESHOLDS.FORECAST_MIN_DAYS}
        currentDataPoints={dataDays}
        ctaLabel="Log today's factors"
        ctaRoute="/log/sleep"
      />
    );
  }

  const chartData = [
    { label: "Now", risk: forecast.currentRisk, lower: forecast.currentRisk, upper: forecast.currentRisk },
    ...forecast.horizons.map((h) => ({ label: h.label, risk: h.riskScore, lower: h.lower, upper: h.upper })),
  ];

  const persist = async () => {
    if (savingRef.current || !user) return;
    savingRef.current = true;
    try {
      await emitEvent({ userId: user.id, engineType: "Forecast", operation: "generate", status: "started", modelVersion: ENGINE_VERSIONS.forecast });
      const rec = await createRecord("Forecast", { ...forecast }, { userId: user.id, source: "ai_engine" });
      await emitEvent({
        userId: user.id,
        engineType: "Forecast",
        operation: "generate",
        status: "validated",
        modelVersion: ENGINE_VERSIONS.forecast,
        confidence: forecast.confidence,
        validationStatus: forecast.validationStatus,
        inputRefs: [rec.id],
        downstreamConsumers: ["CutisAI", "ClearPath"],
      });
      setSaved(true);
    } finally {
      savingRef.current = false;
    }
  };

  const runWhatIf = (factor: string) => setWhatIf(simulateWhatIf(bundle, factor));

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-3 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2"><TrendingUp className="h-5 w-5 text-primary" /><span className="font-semibold text-ink">Skin Horizon</span></div>
          <ConfidenceBadge confidence={forecast.confidence} />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-bold text-ink">{forecast.currentRisk}</span>
          <span className="text-sm text-muted">current breakout risk /100</span>
        </div>
        <div className="h-44 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
              <defs>
                <linearGradient id="band" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7C6EE6" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#7C6EE6" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #ECECF1", fontSize: 12 }} />
              <ReferenceLine y={50} stroke="#ECECF1" strokeDasharray="3 3" />
              <Area type="monotone" dataKey="upper" stroke="none" fill="url(#band)" />
              <Area type="monotone" dataKey="risk" stroke="#7C6EE6" strokeWidth={2.5} fill="none" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <p className="text-xs text-muted">{forecast.rationale}</p>
        {forecast.timeToImprovementDays && (
          <Badge tone="clear">Est. improvement in ~{forecast.timeToImprovementDays} days if top driver corrected</Badge>
        )}
        <Button variant={saved ? "secondary" : "primary"} full onClick={persist} disabled={saved}>
          {saved ? "Forecast saved to history" : "Save this forecast"}
        </Button>
      </Card>

      <Card className="space-y-3 p-4">
        <span className="text-sm font-semibold text-ink">Contributing factors</span>
        {forecast.drivers.length === 0 && <p className="text-sm text-muted">Log more daily factors to surface drivers.</p>}
        {forecast.drivers.map((d) => (
          <div key={d.factor} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {d.direction === "raises" ? <ArrowUpRight className="h-4 w-4 text-flare" /> : <ArrowDownRight className="h-4 w-4 text-clear" />}
              <span className="text-sm text-ink">{d.factor}</span>
            </div>
            <Badge tone={d.direction === "raises" ? "flare" : "clear"}>{Math.round(d.weight * 100)}%</Badge>
          </div>
        ))}
      </Card>

      {/* What-If Simulator */}
      <Card className="space-y-3 p-4">
        <div className="flex items-center gap-2"><Wand2 className="h-4 w-4 text-accent" /><span className="text-sm font-semibold text-ink">What-If Simulator</span></div>
        <p className="text-xs text-muted">Tap a raising factor to simulate correcting it.</p>
        <div className="flex flex-wrap gap-2">
          {factors.filter((f) => f.direction === "raises").map((f) => (
            <button key={f.factor} onClick={() => runWhatIf(f.factor)} className="min-h-[2.5rem] rounded-xl border border-line px-3 text-sm font-medium text-ink active:bg-canvas">
              {f.factor}
            </button>
          ))}
          {factors.filter((f) => f.direction === "raises").length === 0 && <p className="text-sm text-muted">No high-risk factors detected — keep it up.</p>}
        </div>
        {whatIf && (
          <div className="rounded-xl bg-canvas p-3">
            <p className="text-sm font-medium text-ink">{whatIf.changedFactor}</p>
            <div className="mt-1 flex items-center gap-2 text-sm">
              <span className="text-muted">{whatIf.baselineRisk}</span>
              <ArrowDownRight className="h-4 w-4 text-clear" />
              <span className="font-bold text-clear">{whatIf.projectedRisk}</span>
              <Badge tone="clear">{whatIf.deltaPct}%</Badge>
            </div>
            <p className="mt-1 text-xs text-muted">{whatIf.rationale}</p>
          </div>
        )}
      </Card>
    </div>
  );
}
