import { useCallback, useEffect, useRef, useState } from "react";
import { BookOpen, Search, Bookmark, BookmarkCheck } from "lucide-react";
import { useAuthStore } from "../../stores/auth";
import { searchEvidence, EVIDENCE_INDEX, type ScoredEvidence } from "../../lib/ml/evidence";
import { createRecord, listRecords } from "../../lib/api/entities";
import { emitEvent } from "../../lib/ai/intelligence";
import { evidenceBookmarkSchema, type EvidenceBookmark } from "../../lib/schemas";
import { Badge, Card } from "../../components/shared/ui";

const TOPICS = ["All", "Diet", "Stress", "Sleep", "Ingredients", "Barrier", "Hormonal", "Activity"];
const TRUST: Record<string, { label: string; tone: "clear" | "accent" | "primary" | "neutral" }> = {
  peer_reviewed: { label: "Peer-reviewed", tone: "clear" },
  guideline: { label: "Guideline", tone: "primary" },
  review: { label: "Review", tone: "accent" },
  general: { label: "General", tone: "neutral" },
};

export default function Research() {
  const user = useAuthStore((s) => s.user);
  const [query, setQuery] = useState("");
  const [topic, setTopic] = useState("All");
  const [results, setResults] = useState<ScoredEvidence[]>(EVIDENCE_INDEX.map((e) => ({ ...e, score: 0 })));
  const [bookmarks, setBookmarks] = useState<EvidenceBookmark[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const searchedRef = useRef(false);

  const loadBookmarks = useCallback(async () => {
    if (!user) return;
    const rows = await listRecords("EvidenceBookmark", evidenceBookmarkSchema, { created_by_id: user.id }, { limit: 20, sort: "-created_date" });
    setBookmarks(rows as EvidenceBookmark[]);
  }, [user]);

  useEffect(() => { void loadBookmarks(); }, [loadBookmarks]);

  const runSearch = useCallback(async () => {
    const res = searchEvidence(query, topic === "All" ? undefined : topic, 10);
    setResults(res);
    if (user && query && !searchedRef.current) {
      searchedRef.current = true;
      await emitEvent({ userId: user.id, engineType: "DermVault", operation: "retrieval", status: "succeeded", message: query }).catch(() => undefined);
      searchedRef.current = false;
    }
  }, [query, topic, user]);

  useEffect(() => { void runSearch(); }, [runSearch]);

  const isBookmarked = (title: string) => bookmarks.some((b) => b.title === title);

  const toggleBookmark = async (e: ScoredEvidence) => {
    if (!user) return;
    if (isBookmarked(e.title)) return;
    await createRecord(
      "EvidenceBookmark",
      { title: e.title, authors: e.authors, journal: e.journal, year: e.year, topic: e.topic, summary: e.summary, trustLabel: e.trustLabel, url: e.url, bookmarked: true },
      { userId: user.id },
    );
    await loadBookmarks();
  };

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-3 p-4">
        <div className="flex items-center gap-2"><BookOpen className="h-5 w-5 text-primary" /><span className="font-semibold text-ink">DermVault</span></div>
        <div className="flex items-center gap-2 rounded-xl border border-line bg-canvas px-3">
          <Search className="h-4 w-4 text-muted" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search evidence (e.g. dairy, retinoid, stress)" className="h-11 flex-1 bg-transparent text-sm outline-none" />
        </div>
        <div className="no-scrollbar flex gap-2 overflow-x-auto">
          {TOPICS.map((t) => (
            <button key={t} onClick={() => setTopic(t)} className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-medium ${topic === t ? "bg-primary text-white" : "bg-canvas text-muted"}`}>{t}</button>
          ))}
        </div>
      </Card>

      {bookmarks.length > 0 && (
        <div>
          <p className="mb-2 px-1 text-sm font-semibold text-ink">Saved ({bookmarks.length})</p>
          <div className="no-scrollbar flex gap-2 overflow-x-auto">
            {bookmarks.map((b) => (
              <div key={b.id} className="w-56 shrink-0 rounded-xl border border-line bg-surface p-3">
                <Badge tone={TRUST[b.trustLabel]?.tone ?? "neutral"}>{TRUST[b.trustLabel]?.label}</Badge>
                <p className="mt-1.5 line-clamp-2 text-xs font-medium text-ink">{b.title}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-2">
        {results.map((e) => (
          <Card key={e.id} className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <div className="mb-1 flex items-center gap-2">
                  <Badge tone={TRUST[e.trustLabel]?.tone ?? "neutral"}>{TRUST[e.trustLabel]?.label}</Badge>
                  <span className="text-xs text-muted">{e.topic} · {e.year}</span>
                </div>
                <p className="text-sm font-semibold text-ink">{e.title}</p>
                <p className="text-xs text-muted">{e.authors} · {e.journal}</p>
              </div>
              <button onClick={() => toggleBookmark(e)} className="flex h-9 w-9 items-center justify-center rounded-lg text-primary active:bg-canvas">
                {isBookmarked(e.title) ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
              </button>
            </div>
            <button onClick={() => setOpen(open === e.id ? null : e.id)} className="mt-2 text-xs font-semibold text-primary">
              {open === e.id ? "Hide abstract" : "Read abstract"}
            </button>
            {open === e.id && <p className="mt-2 rounded-xl bg-canvas p-3 text-xs leading-relaxed text-ink">{e.summary}</p>}
          </Card>
        ))}
        {results.length === 0 && <p className="py-8 text-center text-sm text-muted">No matching evidence. Try a different term.</p>}
      </div>
    </div>
  );
}
