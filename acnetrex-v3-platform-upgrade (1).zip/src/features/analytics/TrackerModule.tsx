import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Moon, Apple, Activity, CalendarHeart, Hand, CloudSun, type LucideIcon } from "lucide-react";
import { format } from "date-fns";
import { listRecords, upsertDailyLog } from "../../lib/api/entities";
import type { StoreName } from "../../lib/db";
import { dailyLogSchema, type DailyLog } from "../../lib/schemas";
import { useAuthStore } from "../../stores/auth";
import { Button, Card, Spinner } from "../../components/shared/ui";
import { EmptyState } from "../../components/shared/states";

interface InlineField { key: string; label: string; min: number; max: number; step: number; unit?: string; default: number }
export interface TrackerConfig {
  store: StoreName;
  type: string;
  title: string;
  description: string;
  icon: LucideIcon;
  metricKey: string;
  metricLabel: string;
  logRoute?: string;
  inline?: InlineField[];
}

const CONFIGS: Record<string, TrackerConfig> = {
  sleep: { store: "SleepLog", type: "sleep", title: "SleepDerm Analytics", description: "Sleep duration vs skin recovery.", icon: Moon, metricKey: "hours", metricLabel: "Hours", logRoute: "/log/sleep" },
  diet: { store: "FoodLog", type: "food", title: "DermDiet Intelligence", description: "Glycemic load trend over time.", icon: Apple, metricKey: "glycemic", metricLabel: "Glycemic load", logRoute: "/log/food" },
  activity: { store: "ActivityLog", type: "activity", title: "SweatFlow Index", description: "Activity & sweat exposure.", icon: Activity, metricKey: "minutes", metricLabel: "Active minutes", logRoute: "/log/activity" },
  cycle: { store: "CycleLog", type: "cycle", title: "CycleSync Skin Tracker", description: "Track your cycle day to anticipate hormonal flares.", icon: CalendarHeart, metricKey: "cycleDay", metricLabel: "Cycle day", inline: [{ key: "cycleDay", label: "Cycle day", min: 1, max: 35, step: 1, default: 14 }, { key: "flareSeverity", label: "Flare severity", min: 0, max: 100, step: 10, unit: "/100", default: 0 }] },
  contact: { store: "ContactLog", type: "contact", title: "ContactGuard", description: "Log irritant/allergen contact exposure.", icon: Hand, metricKey: "irritantScore", metricLabel: "Irritant exposure", inline: [{ key: "irritantScore", label: "Irritant exposure", min: 0, max: 100, step: 10, unit: "/100", default: 0 }] },
  climate: { store: "ClimateLog", type: "climate", title: "ClimateSkin Radar", description: "Log humidity & UV — environmental skin stressors.", icon: CloudSun, metricKey: "humidity", metricLabel: "Humidity", inline: [{ key: "humidity", label: "Humidity", min: 0, max: 100, step: 5, unit: "%", default: 50 }, { key: "uvIndex", label: "UV index", min: 0, max: 11, step: 1, default: 3 }] },
};

export default function TrackerModule({ routeKey }: { routeKey: string }) {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const config = CONFIGS[routeKey];
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [values, setValues] = useState<Record<string, number>>({});
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);

  const load = useCallback(async () => {
    if (!user || !config) return;
    const rows = await listRecords(config.store, dailyLogSchema, { created_by_id: user.id }, { limit: 20, sort: "-logDate" });
    setLogs(rows as DailyLog[]);
    setLoaded(true);
  }, [user, config]);

  useEffect(() => {
    if (config?.inline) setValues(Object.fromEntries(config.inline.map((f) => [f.key, f.default])));
    void load();
  }, [load]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!config) return <p className="py-10 text-center text-sm text-muted">Unknown tracker.</p>;

  const saveInline = async () => {
    if (savingRef.current || !user) return;
    savingRef.current = true;
    setSaving(true);
    try {
      await upsertDailyLog(config.store, user.id, { type: config.type, values, note: "" });
      await load();
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };

  const chartData = [...logs].reverse().map((l) => ({ date: l.logDate.slice(5), value: typeof l.values[config.metricKey] === "number" ? (l.values[config.metricKey] as number) : 0 }));
  const Icon = config.icon;

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-1 p-5">
        <div className="flex items-center gap-2"><Icon className="h-5 w-5 text-primary" /><span className="font-semibold text-ink">{config.title}</span></div>
        <p className="text-xs text-muted">{config.description}</p>
      </Card>

      {config.inline && (
        <Card className="space-y-3 p-4">
          <p className="text-sm font-semibold text-ink">Quick log · {format(new Date(), "MMM d")}</p>
          {config.inline.map((f) => (
            <div key={f.key} className="space-y-1.5">
              <div className="flex justify-between text-sm"><span className="text-muted">{f.label}</span><span className="font-semibold text-primary">{values[f.key] ?? f.default}{f.unit ?? ""}</span></div>
              <input type="range" min={f.min} max={f.max} step={f.step} value={values[f.key] ?? f.default} onChange={(e) => setValues((v) => ({ ...v, [f.key]: Number(e.target.value) }))} className="w-full accent-[#7C6EE6]" />
            </div>
          ))}
          <Button full loading={saving} onClick={saveInline}>Save today's entry</Button>
        </Card>
      )}

      {!loaded ? (
        <Spinner />
      ) : logs.length === 0 ? (
        <EmptyState icon={Icon} title="No entries yet" description={`Start logging to see your ${config.metricLabel.toLowerCase()} trend and how it relates to your skin.`} ctaLabel={config.logRoute ? "Log now" : "Add first entry above"} ctaRoute={config.logRoute ?? routeKey} />
      ) : (
        <Card className="space-y-2 p-4">
          <span className="text-sm font-semibold text-ink">{config.metricLabel} — last {chartData.length} entries</span>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #ECECF1", fontSize: 12 }} />
                <Bar dataKey="value" fill="#7C6EE6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {config.logRoute && <Button variant="secondary" full onClick={() => navigate(config.logRoute!)}>Add / update today</Button>}
        </Card>
      )}
    </div>
  );
}
