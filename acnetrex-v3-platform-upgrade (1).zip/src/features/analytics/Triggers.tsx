import { useMemo } from "react";
import { Activity, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { useEngineData } from "../../hooks/useEngineData";
import { computeTriggers } from "../../lib/ml/engines";
import { DATA_THRESHOLDS } from "../../lib/constants";
import { Badge, Card, Progress, Spinner } from "../../components/shared/ui";
import { InsufficientDataState } from "../../components/shared/states";

export default function Triggers() {
  const { bundle, loading } = useEngineData();
  const days = useMemo(() => (bundle ? new Set(Object.values(bundle.logsByType).flat().map((l) => l.logDate)).size : 0), [bundle]);

  if (loading || !bundle) return <Spinner label="Correlating triggers…" />;

  const triggers = computeTriggers(bundle);

  if (bundle.scans.length < 3 || triggers.length === 0) {
    return (
      <InsufficientDataState
        moduleName="TriggerGraph"
        requiredDataPoints={DATA_THRESHOLDS.TRIGGER_GRAPH_MIN_DAYS}
        currentDataPoints={days}
        ctaLabel="Log + scan to build correlations"
        ctaRoute="/face-atlas"
      />
    );
  }

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-2 p-5">
        <div className="flex items-center gap-2"><Activity className="h-5 w-5 text-primary" /><span className="font-semibold text-ink">TriggerGraph</span></div>
        <p className="text-xs text-muted">Pearson correlation between your daily factors and same-day scan severity. Correlation isn't causation — use the What-If simulator to test.</p>
      </Card>
      {triggers.map((t) => {
        const positive = t.correlation > 0;
        return (
          <Card key={t.factor} className="space-y-2 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {positive ? <ArrowUpRight className="h-4 w-4 text-flare" /> : <ArrowDownRight className="h-4 w-4 text-clear" />}
                <span className="text-sm font-medium text-ink">{t.factor}</span>
              </div>
              <Badge tone={t.strength === "strong" ? (positive ? "flare" : "clear") : "neutral"}>{t.strength}</Badge>
            </div>
            <Progress value={Math.abs(t.correlation) * 100} tone={positive ? "flare" : "clear"} />
            <p className="text-xs text-muted">r = {t.correlation} · {t.samples} matched days {positive ? "· higher values track with worse skin" : "· higher values track with better skin"}</p>
          </Card>
        );
      })}
    </div>
  );
}
