import { Boxes, ArrowRight } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { useEngineData } from "../../hooks/useEngineData";
import { computeForecast, simulateWhatIf, computeRiskFactors } from "../../lib/ml/engines";
import { DATA_THRESHOLDS } from "../../lib/constants";
import { Badge, Card, Spinner } from "../../components/shared/ui";
import { InsufficientDataState } from "../../components/shared/states";

export default function SkinTwin() {
  const { bundle, loading } = useEngineData();
  if (loading || !bundle) return <Spinner label="Building your Skin Twin…" />;

  if (bundle.scans.length < DATA_THRESHOLDS.SKIN_TWIN_MIN_SCANS) {
    return (
      <InsufficientDataState
        moduleName="Skin Twin Lab"
        requiredDataPoints={DATA_THRESHOLDS.SKIN_TWIN_MIN_SCANS}
        currentDataPoints={bundle.scans.length}
        ctaLabel="Run more FaceAtlas scans"
        ctaRoute="/face-atlas"
      />
    );
  }

  const forecast = computeForecast(bundle);
  const factors = computeRiskFactors(bundle).filter((f) => f.direction === "raises");
  const series = [...bundle.scans].reverse().map((s) => ({ date: s.logDate.slice(5), severity: s.overallSeverity }));

  const noChange = forecast.horizons.map((h) => ({ label: h.label, value: h.riskScore }));
  const corrected = factors.length
    ? forecast.horizons.map((h, i) => ({ label: h.label, value: Math.max(0, h.riskScore - factors[0].weight * 18 * (1 + i * 0.2)) }))
    : noChange;

  const merged = noChange.map((n, i) => ({ label: n.label, noChange: n.value, corrected: Math.round(corrected[i].value) }));

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-2 p-5">
        <div className="flex items-center gap-2"><Boxes className="h-5 w-5 text-primary" /><span className="font-semibold text-ink">Skin Twin Lab</span></div>
        <p className="text-xs text-muted">A causal/counterfactual layer over your forecast: it models a digital twin of your skin and compares "do nothing" vs "fix your top driver."</p>
      </Card>

      <Card className="space-y-2 p-4">
        <span className="text-sm font-semibold text-ink">Historical severity</span>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={series} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #ECECF1", fontSize: 12 }} />
              <Line type="monotone" dataKey="severity" stroke="#7C6EE6" strokeWidth={2.5} dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="space-y-2 p-4">
        <span className="text-sm font-semibold text-ink">Counterfactual projection</span>
        <div className="h-44">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={merged} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
              <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#8A8A99" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #ECECF1", fontSize: 12 }} />
              <Line type="monotone" name="No change" dataKey="noChange" stroke="#F26D7D" strokeWidth={2.5} dot={false} />
              <Line type="monotone" name="Top driver fixed" dataKey="corrected" stroke="#3FBF8F" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-4 text-xs">
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-flare" /> No change</span>
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-clear" /> Top driver fixed</span>
        </div>
      </Card>

      {factors.length > 0 && (
        <Card className="space-y-2 p-4">
          <span className="text-sm font-semibold text-ink">Highest-leverage change</span>
          {(() => {
            const sim = simulateWhatIf(bundle, factors[0].factor);
            return (
              <div className="flex items-center gap-2">
                <span className="text-sm text-ink">{sim.baselineRisk}</span>
                <ArrowRight className="h-4 w-4 text-muted" />
                <span className="text-lg font-bold text-clear">{sim.projectedRisk}</span>
                <Badge tone="clear">{sim.deltaPct}%</Badge>
                <span className="text-xs text-muted">if you fix {factors[0].factor.toLowerCase()}</span>
              </div>
            );
          })()}
        </Card>
      )}
    </div>
  );
}
