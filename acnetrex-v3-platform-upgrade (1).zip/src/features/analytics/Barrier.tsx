import { useMemo } from "react";
import { Droplets } from "lucide-react";
import { useEngineData } from "../../hooks/useEngineData";
import { computeBarrier } from "../../lib/ml/engines";
import { DATA_THRESHOLDS } from "../../lib/constants";
import { Badge, Card, ConfidenceBadge, Progress, Ring, Spinner } from "../../components/shared/ui";
import { InsufficientDataState } from "../../components/shared/states";

export default function Barrier() {
  const { bundle, loading } = useEngineData();
  const points = useMemo(() => (bundle ? bundle.scans.length + new Set(Object.values(bundle.logsByType).flat().map((l) => l.logDate)).size : 0), [bundle]);

  if (loading || !bundle) return <Spinner label="Assessing barrier…" />;

  if (points < DATA_THRESHOLDS.BARRIER_MIN_DAYS) {
    return (
      <InsufficientDataState
        moduleName="BarrierGuard"
        requiredDataPoints={DATA_THRESHOLDS.BARRIER_MIN_DAYS}
        currentDataPoints={points}
        ctaLabel="Add a scan or log"
        ctaRoute="/face-atlas"
      />
    );
  }

  const b = computeBarrier(bundle);

  return (
    <div className="space-y-4 pb-6">
      <Card className="flex items-center gap-5 p-5">
        <Ring value={b.score} sublabel="Barrier" tone={b.score >= 70 ? "#3FBF8F" : b.score >= 45 ? "#7C6EE6" : "#F26D7D"} />
        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-2"><Droplets className="h-4 w-4 text-accent" /><span className="font-semibold text-ink">BarrierGuard</span></div>
          <Badge tone={b.trend === "improving" ? "clear" : b.trend === "worsening" ? "flare" : "neutral"}>{b.trend}</Badge>
          <div className="pt-1"><ConfidenceBadge confidence={b.confidence} /></div>
        </div>
      </Card>
      <Card className="space-y-3 p-4">
        <Row label="Dryness signal" value={b.dryness} tone="accent" />
        <Row label="Irritation exposure" value={b.irritation} tone="flare" />
        <p className="text-xs text-muted">Lower dryness and irritation protect the barrier, improving active-ingredient tolerance and reducing inflammatory acne.</p>
      </Card>
    </div>
  );
}

function Row({ label, value, tone }: { label: string; value: number; tone: "accent" | "flare" }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs"><span className="text-muted">{label}</span><span className="font-semibold text-ink">{value}</span></div>
      <Progress value={value} tone={tone} />
    </div>
  );
}
