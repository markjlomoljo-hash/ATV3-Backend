import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { createRecord } from "../../lib/api/entities";
import { useAuthStore } from "../../stores/auth";
import { Button, Card, ErrorBanner } from "../../components/shared/ui";
import { cn } from "../../utils/cn";

const SKIN_TYPES = ["oily", "dry", "combination", "normal", "sensitive"] as const;
const SEVERITIES = ["none", "mild", "moderate", "severe"] as const;
const SEXES = ["female", "male", "other", "prefer_not"] as const;
const GOALS = ["Clear breakouts", "Fade marks (PIH)", "Reduce oil", "Calm redness", "Prevent flares", "Repair barrier"];
const TRIGGERS = ["Stress", "Dairy", "Sugar / high-GI", "Poor sleep", "Sweat", "Hormonal cycle", "New products", "Weather"];

export default function OnboardingPage() {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const [step, setStep] = useState(0);
  const [skinType, setSkinType] = useState<(typeof SKIN_TYPES)[number]>("combination");
  const [acneSeverity, setAcneSeverity] = useState<(typeof SEVERITIES)[number]>("mild");
  const [primaryConcern, setPrimaryConcern] = useState("Clear breakouts");
  const [age, setAge] = useState(22);
  const [biologicalSex, setBiologicalSex] = useState<(typeof SEXES)[number]>("prefer_not");
  const [goals, setGoals] = useState<string[]>([]);
  const [knownTriggers, setKnownTriggers] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);

  const toggle = (arr: string[], set: (v: string[]) => void, v: string) =>
    set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const finish = async () => {
    if (savingRef.current || !user) return;
    savingRef.current = true;
    setSaving(true);
    setError(null);
    try {
      await createRecord(
        "OnboardingProfile",
        {
          skinType,
          acneSeverity,
          primaryConcern,
          age,
          biologicalSex,
          goals,
          knownTriggers,
          completed: true,
          completedAt: new Date().toISOString(),
        },
        { userId: user.id },
      );
      navigate("/");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save profile");
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };

  const Chip = ({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) => (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "min-h-[2.75rem] rounded-xl border px-3 text-sm font-medium transition-colors",
        active ? "border-primary bg-primary-soft text-primary" : "border-line bg-surface text-ink",
      )}
    >
      {label}
    </button>
  );

  const steps = [
    {
      title: "Your skin type",
      body: (
        <div className="grid grid-cols-2 gap-2">
          {SKIN_TYPES.map((t) => (
            <Chip key={t} active={skinType === t} label={t[0].toUpperCase() + t.slice(1)} onClick={() => setSkinType(t)} />
          ))}
        </div>
      ),
    },
    {
      title: "Current acne severity",
      body: (
        <div className="grid grid-cols-2 gap-2">
          {SEVERITIES.map((t) => (
            <Chip key={t} active={acneSeverity === t} label={t[0].toUpperCase() + t.slice(1)} onClick={() => setAcneSeverity(t)} />
          ))}
        </div>
      ),
    },
    {
      title: "About you",
      body: (
        <div className="space-y-3">
          <label className="block text-sm font-medium text-muted">Age: {age}</label>
          <input type="range" min={10} max={70} value={age} onChange={(e) => setAge(Number(e.target.value))} className="w-full accent-[#7C6EE6]" />
          <div className="grid grid-cols-2 gap-2 pt-2">
            {SEXES.map((t) => (
              <Chip key={t} active={biologicalSex === t} label={t === "prefer_not" ? "Prefer not" : t[0].toUpperCase() + t.slice(1)} onClick={() => setBiologicalSex(t)} />
            ))}
          </div>
        </div>
      ),
    },
    {
      title: "Your goals",
      body: (
        <div className="grid grid-cols-2 gap-2">
          {GOALS.map((g) => (
            <Chip key={g} active={goals.includes(g)} label={g} onClick={() => { toggle(goals, setGoals, g); setPrimaryConcern(goals[0] ?? g); }} />
          ))}
        </div>
      ),
    },
    {
      title: "Suspected triggers",
      body: (
        <div className="grid grid-cols-2 gap-2">
          {TRIGGERS.map((g) => (
            <Chip key={g} active={knownTriggers.includes(g)} label={g} onClick={() => toggle(knownTriggers, setKnownTriggers, g)} />
          ))}
        </div>
      ),
    },
  ];

  const current = steps[step];
  const last = step === steps.length - 1;

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col px-6 py-8">
      <div className="mb-6">
        <div className="mb-2 flex gap-1.5">
          {steps.map((_, i) => (
            <div key={i} className={cn("h-1.5 flex-1 rounded-full", i <= step ? "bg-primary" : "bg-line")} />
          ))}
        </div>
        <p className="text-xs font-medium text-muted">Step {step + 1} of {steps.length}</p>
      </div>

      <h2 className="mb-1 text-xl font-bold text-ink">{current.title}</h2>
      <p className="mb-6 text-sm text-muted">This personalises every engine. No face photos here — capture those later in FaceAtlas.</p>

      <AnimatePresence mode="wait">
        <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.15 }}>
          <Card className="p-4">{current.body}</Card>
        </motion.div>
      </AnimatePresence>

      {error && <div className="mt-4"><ErrorBanner message={error} /></div>}

      <div className="mt-auto flex gap-3 pt-8">
        {step > 0 && (
          <Button variant="secondary" full onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
        )}
        {!last ? (
          <Button full onClick={() => setStep((s) => s + 1)}>
            Continue
          </Button>
        ) : (
          <Button full loading={saving} onClick={finish}>
            Finish setup
          </Button>
        )}
      </div>
    </div>
  );
}
