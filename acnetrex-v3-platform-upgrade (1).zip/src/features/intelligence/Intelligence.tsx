import { useCallback, useEffect, useState } from "react";
import { Brain, Activity, ShieldCheck, Users, Zap, GitBranch } from "lucide-react";
import { useAuthStore } from "../../stores/auth";
import { coreStatus, recentEvents, type CoreStatus } from "../../lib/ai/intelligence";
import { useConsent } from "../../hooks/useConsent";
import type { IntelligenceEvent } from "../../lib/schemas";
import { Badge, Button, Card, Progress, Spinner } from "../../components/shared/ui";
import { formatDistanceToNow } from "date-fns";

export default function Intelligence() {
  const user = useAuthStore((s) => s.user);
  const { consentStatus, canContributeToNetwork, grantConsent, revokeConsent } = useConsent();
  const [status, setStatus] = useState<CoreStatus | null>(null);
  const [events, setEvents] = useState<IntelligenceEvent[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [s, e] = await Promise.all([coreStatus(user.id), recentEvents(user.id, 20)]);
    setStatus(s);
    setEvents(e);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading || !status) return <Spinner label="Reading Intelligence Core…" />;

  const heartbeat = status.lastHeartbeat ? formatDistanceToNow(new Date(status.lastHeartbeat), { addSuffix: true }) : "no activity yet";
  const readiness = Math.min(100, status.totalInferences * 4);

  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-4 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary-soft text-primary">
              <Brain className="h-5 w-5" />
              {status.totalInferences > 0 && <span className="at-pulse absolute inset-0 text-primary/30" />}
            </div>
            <div>
              <p className="text-sm font-semibold text-ink">Intelligence Core</p>
              <p className="text-xs text-muted">Heartbeat: {heartbeat}</p>
            </div>
          </div>
          <Badge tone={status.totalInferences > 0 ? "clear" : "neutral"}>{status.totalInferences > 0 ? "Active" : "Idle"}</Badge>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <Stat icon={Zap} label="Inferences" value={status.totalInferences} />
          <Stat icon={ShieldCheck} label="Validation" value={`${status.validationRate}%`} />
          <Stat icon={GitBranch} label="Learning" value={status.learningEvents} />
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-muted"><span>Model readiness</span><span>{readiness}%</span></div>
          <Progress value={readiness} />
        </div>
        {status.enginesActive.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {status.enginesActive.map((e) => <Badge key={e} tone="primary">{e}</Badge>)}
          </div>
        )}
      </Card>

      {/* Research network */}
      <Card className="space-y-3 p-5">
        <div className="flex items-center gap-2"><Users className="h-5 w-5 text-accent" /><span className="font-semibold text-ink">AcneTrex Research Network™</span></div>
        <p className="text-sm text-muted">
          Opt in to privacy-preserving cohort learning. Only de-identified, aggregated signals are shared — never your raw photos or raw logs. This sharpens population-level intelligence for everyone.
        </p>
        <div className="flex items-center justify-between rounded-xl bg-canvas p-3">
          <div>
            <p className="text-sm font-medium text-ink">Participation</p>
            <p className="text-xs text-muted">
              {consentStatus === "granted" ? "You are contributing anonymised signals." : consentStatus === "revoked" ? "Revoked — no new contributions." : "Not yet enrolled."}
            </p>
          </div>
          <Badge tone={canContributeToNetwork ? "clear" : "neutral"}>{consentStatus}</Badge>
        </div>
        {canContributeToNetwork ? (
          <Button variant="secondary" full onClick={async () => { if (confirm("Revoke research consent? Historical aggregates already contributed cannot be retracted, but no new data will be shared.")) { await revokeConsent(); await load(); } }}>
            Revoke participation
          </Button>
        ) : (
          <Button full onClick={async () => { await grantConsent(); await load(); }}>
            Enable privacy-preserving learning
          </Button>
        )}
      </Card>

      {/* Telemetry feed */}
      <Card className="space-y-2 p-4">
        <div className="flex items-center gap-2"><Activity className="h-4 w-4 text-primary" /><span className="text-sm font-semibold text-ink">Live telemetry</span></div>
        {events.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted">No engine events yet. Run a scan, forecast, or ask CutisAI to generate telemetry.</p>
        ) : (
          events.map((e) => (
            <div key={e.id} className="flex items-center justify-between border-b border-line py-2 text-xs last:border-0">
              <div>
                <p className="font-medium text-ink">{e.engineType} · {e.operation}</p>
                <p className="text-muted">{formatDistanceToNow(new Date(e.created_date), { addSuffix: true })}{e.confidence != null ? ` · conf ${Math.round(e.confidence * 100)}%` : ""}</p>
              </div>
              <Badge tone={e.status === "validated" || e.status === "succeeded" ? "clear" : e.status === "failed" || e.status === "rejected" ? "flare" : "neutral"}>{e.status}</Badge>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Zap; label: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-canvas p-3">
      <Icon className="mx-auto mb-1 h-4 w-4 text-primary" />
      <p className="text-lg font-bold text-ink">{value}</p>
      <p className="text-[10px] uppercase tracking-wide text-muted">{label}</p>
    </div>
  );
}
