import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { Camera, Check, RotateCcw, ScanFace, AlertTriangle } from "lucide-react";
import { analyzeFaceScan } from "../../lib/ml/faceAnalysis";
import { createRecord } from "../../lib/api/entities";
import { emitEvent } from "../../lib/ai/intelligence";
import { ENGINE_VERSIONS } from "../../lib/constants";
import { listRecords } from "../../lib/api/entities";
import { faceScanSchema, type FaceScan } from "../../lib/schemas";
import { useAuthStore } from "../../stores/auth";
import { useConsent } from "../../hooks/useConsent";
import { Badge, Button, Card, ConfidenceBadge, ErrorBanner, Progress, Spinner } from "../../components/shared/ui";
import { EmptyState } from "../../components/shared/states";

const STEPS = ["Front", "Left 45°", "Right 45°", "Forehead / upper", "Chin / lower"] as const;
type CaptureState = "IDLE" | "CAMERA_OPEN" | "CAPTURING" | "REVIEWING" | "UPLOADING" | "COMPLETE" | "ERROR";

export default function FaceAtlas() {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const { canContributeToNetwork, consentStatus } = useConsent();

  const [state, setState] = useState<CaptureState>("IDLE");
  const [stepIndex, setStepIndex] = useState(0);
  const [photos, setPhotos] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<FaceScan | null>(null);
  const [history, setHistory] = useState<FaceScan[]>([]);
  const [historyLoaded, setHistoryLoaded] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const loadHistory = useCallback(async () => {
    if (!user) return;
    const rows = await listRecords("FaceScan", faceScanSchema, { created_by_id: user.id }, { limit: 10, sort: "-logDate" });
    setHistory(rows as FaceScan[]);
    setHistoryLoaded(true);
  }, [user]);

  useEffect(() => {
    void loadHistory();
  }, [loadHistory]);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => () => stopStream(), [stopStream]);

  const openCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      setState("CAMERA_OPEN");
      // attach after render
      requestAnimationFrame(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play();
        }
      });
      setState("CAPTURING");
    } catch (e) {
      const err = e as DOMException;
      if (err.name === "NotAllowedError") setError("Camera permission denied. Enable camera access in your settings.");
      else if (err.name === "NotFoundError") setError("No camera detected on this device.");
      else if (err.name === "OverconstrainedError") {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          streamRef.current = stream;
          requestAnimationFrame(() => {
            if (videoRef.current) {
              videoRef.current.srcObject = stream;
              void videoRef.current.play();
            }
          });
          setState("CAPTURING");
          return;
        } catch {
          setError("Camera could not start. Please try another device.");
        }
      } else setError("Camera could not be started.");
      setState("ERROR");
    }
  };

  const compress = (canvas: HTMLCanvasElement): Promise<string> =>
    new Promise((resolve) => {
      let quality = 0.85;
      const attempt = () => {
        canvas.toBlob(
          (blob) => {
            if (!blob) return resolve(canvas.toDataURL("image/jpeg", quality));
            if (blob.size > 4 * 1024 * 1024 && quality > 0.4) {
              quality -= 0.05;
              attempt();
            } else {
              const reader = new FileReader();
              reader.onload = () => resolve(reader.result as string);
              reader.readAsDataURL(blob);
            }
          },
          "image/jpeg",
          quality,
        );
      };
      attempt();
    });

  const capture = async () => {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = await compress(canvas);
    const next = [...photos, dataUrl];
    setPhotos(next);
    if (next.length >= STEPS.length) {
      stopStream();
      setState("REVIEWING");
    } else {
      setStepIndex(next.length);
    }
  };

  const retake = () => {
    setPhotos([]);
    setStepIndex(0);
    setResult(null);
    void openCamera();
  };

  const analyze = async () => {
    if (!user) return;
    setState("UPLOADING");
    setError(null);
    try {
      await emitEvent({ userId: user.id, engineType: "FaceAnalysis", operation: "scan_analyze", status: "started", modelVersion: ENGINE_VERSIONS.face, consentStatus });
      const analysis = await analyzeFaceScan(photos);
      const record = (await createRecord(
        "FaceScan",
        {
          logDate: format(new Date(), "yyyy-MM-dd"),
          photoCount: photos.length,
          photos,
          ...analysis,
        },
        { userId: user.id, source: "ai_engine" },
      )) as unknown as FaceScan;

      const parsed = faceScanSchema.safeParse(record);
      if (!parsed.success) throw new Error("Scan result failed validation.");

      await emitEvent({
        userId: user.id,
        engineType: "FaceAnalysis",
        operation: "scan_analyze",
        status: analysis.validationStatus === "insufficient" ? "rejected" : "validated",
        modelVersion: ENGINE_VERSIONS.face,
        confidence: analysis.confidence,
        validationStatus: analysis.validationStatus,
        inputRefs: [record.id],
        downstreamConsumers: ["CHI", "Forecast", "TriggerGraph", "SkinTwin"],
        consentStatus: canContributeToNetwork ? "granted" : "revoked_or_none",
      });

      setResult(parsed.data);
      setState("COMPLETE");
      await loadHistory();
    } catch (e) {
      await emitEvent({ userId: user.id, engineType: "FaceAnalysis", operation: "scan_analyze", status: "failed", message: e instanceof Error ? e.message : "error" }).catch(() => undefined);
      setError(e instanceof Error ? e.message : "Analysis failed");
      setState("ERROR");
    }
  };

  // ---- RENDER ----
  if (state === "CAPTURING" || state === "CAMERA_OPEN") {
    return (
      <div className="space-y-4 pb-6">
        <Card className="overflow-hidden p-0">
          <div className="relative aspect-[3/4] bg-ink">
            <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div className="h-56 w-44 rounded-[45%] border-2 border-white/70" />
            </div>
            <div className="absolute left-0 right-0 top-3 mx-auto w-fit rounded-full bg-ink/60 px-3 py-1 text-xs font-semibold text-white">
              {STEPS[stepIndex]} · {stepIndex + 1}/{STEPS.length}
            </div>
          </div>
        </Card>
        <Progress value={stepIndex} max={STEPS.length} />
        <p className="text-center text-sm text-muted">Align your face in the oval, then capture.</p>
        <Button full size="lg" onClick={capture}>
          <Camera className="h-5 w-5" /> Capture {STEPS[stepIndex]}
        </Button>
      </div>
    );
  }

  if (state === "REVIEWING") {
    return (
      <div className="space-y-4 pb-6">
        <h2 className="px-1 text-base font-semibold text-ink">Review your 5 photos</h2>
        <div className="grid grid-cols-3 gap-2">
          {photos.map((p, i) => (
            <div key={i} className="overflow-hidden rounded-xl border border-line">
              <img src={p} alt={STEPS[i]} className="aspect-square w-full object-cover" />
            </div>
          ))}
        </div>
        {error && <ErrorBanner message={error} />}
        <div className="flex gap-3">
          <Button variant="secondary" full onClick={retake}>
            <RotateCcw className="h-4 w-4" /> Retake
          </Button>
          <Button full onClick={analyze}>
            <ScanFace className="h-4 w-4" /> Analyze
          </Button>
        </div>
      </div>
    );
  }

  if (state === "UPLOADING") return <Spinner label="Running FaceAtlas vision pipeline…" />;

  if (state === "COMPLETE" && result) {
    return (
      <div className="space-y-4 pb-6">
        <Card className="space-y-3 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#e4f7ef] text-clear"><Check className="h-5 w-5" /></div>
              <span className="font-semibold text-ink">Scan complete</span>
            </div>
            <ConfidenceBadge confidence={result.confidence} />
          </div>
          {result.validationStatus !== "passed" && (
            <div className="flex items-start gap-2 rounded-xl bg-[#fff7e8] p-3 text-xs text-[#9a6a00]">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              {result.validationStatus === "insufficient"
                ? "Image quality or face detection was low. Results are not reliable — retake in better lighting."
                : "Confidence is limited. Treat these readings as preliminary."}
            </div>
          )}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <Metric label="Overall severity" value={result.overallSeverity} tone="flare" />
            <Metric label="Quality" value={result.qualityScore} tone="accent" />
            <Metric label="Oiliness" value={result.oiliness} tone="primary" />
            <Metric label="Lesions (est.)" value={result.lesionCount} raw />
          </div>
        </Card>

        <Card className="space-y-3 p-4">
          <span className="text-sm font-semibold text-ink">Zone breakdown</span>
          {result.zones.map((z) => (
            <div key={z.zone} className="space-y-1">
              <div className="flex justify-between text-xs text-muted">
                <span>{z.zone}</span>
                <span>Inflammatory {z.inflammatory} · PIH {z.pih}</span>
              </div>
              <Progress value={z.inflammatory} tone="flare" />
            </div>
          ))}
        </Card>

        <Button full onClick={() => { setState("IDLE"); setPhotos([]); setStepIndex(0); setResult(null); }}>
          Done
        </Button>
        <Button variant="ghost" full onClick={() => navigate("/forecast")}>
          See how this affects your forecast
        </Button>
      </div>
    );
  }

  // IDLE / ERROR
  return (
    <div className="space-y-4 pb-6">
      <Card className="space-y-3 p-5 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-soft text-primary">
          <ScanFace className="h-7 w-7" />
        </div>
        <h2 className="text-base font-semibold text-ink">Daily FaceAtlas scan</h2>
        <p className="mx-auto max-w-xs text-sm text-muted">
          Capture 5 angles — front, left, right, forehead and chin. A real CV pipeline measures redness, oiliness, texture and dark spots per zone.
        </p>
        {error && <ErrorBanner message={error} onRetry={openCamera} />}
        <Button full size="lg" onClick={openCamera}>
          <Camera className="h-5 w-5" /> Start scan
        </Button>
      </Card>

      {historyLoaded && history.length === 0 ? (
        <EmptyState icon={ScanFace} title="No scans yet" description="Your scan history and trends appear here once you complete your first FaceAtlas scan." ctaLabel="Start your first scan" ctaRoute="/face-atlas" />
      ) : (
        history.length > 0 && (
          <Card className="space-y-2 p-4">
            <span className="text-sm font-semibold text-ink">Recent scans</span>
            {history.slice(0, 5).map((h) => (
              <div key={h.id} className="flex items-center justify-between border-b border-line py-2 last:border-0">
                <div>
                  <p className="text-sm font-medium text-ink">{h.logDate}</p>
                  <p className="text-xs text-muted">Severity {h.overallSeverity} · {h.validationStatus.replace("_", " ")}</p>
                </div>
                <Badge tone={h.overallSeverity > 50 ? "flare" : "clear"}>{h.overallSeverity}</Badge>
              </div>
            ))}
          </Card>
        )
      )}
    </div>
  );
}

function Metric({ label, value, tone = "primary", raw }: { label: string; value: number; tone?: "primary" | "accent" | "flare"; raw?: boolean }) {
  return (
    <div className="rounded-xl bg-canvas p-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="text-lg font-bold text-ink">{value}{raw ? "" : ""}</p>
      {!raw && <Progress value={value} tone={tone} className="mt-1.5" />}
    </div>
  );
}
