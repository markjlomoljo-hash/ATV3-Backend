import { create } from "zustand";
import { auth } from "../lib/api/auth";
import type { PublicUser } from "../lib/schemas";

interface AuthState {
  user: PublicUser | null;
  loading: boolean;
  initialized: boolean;
  init: () => Promise<void>;
  setUser: (u: PublicUser | null) => void;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: false,
  initialized: false,
  init: async () => {
    set({ loading: true });
    await auth.migrateLegacy().catch(() => undefined);
    const user = await auth.me().catch(() => null);
    set({ user, loading: false, initialized: true });
  },
  setUser: (user) => set({ user }),
  refresh: async () => {
    const user = await auth.me().catch(() => null);
    set({ user });
  },
  logout: async () => {
    await auth.logout();
    set({ user: null });
  },
}));
