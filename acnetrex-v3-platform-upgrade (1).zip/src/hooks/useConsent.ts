import { useCallback, useEffect, useState } from "react";
import { listRecords, createRecord, updateRecord } from "../lib/api/entities";
import { db } from "../lib/db";
import { consentRecordSchema, type ConsentRecord } from "../lib/schemas";
import { useAuthStore } from "../stores/auth";

/**
 * Consent gate for privacy-preserving network learning. Every intelligence
 * engine consults this before emitting a population-learning event.
 */
export function useConsent() {
  const user = useAuthStore((s) => s.user);
  const [consent, setConsent] = useState<ConsentRecord | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const rows = await listRecords("ConsentRecord", consentRecordSchema, { created_by_id: user.id }, { limit: 1, sort: "-created_date" });
    setConsent(rows[0] ?? null);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    void load();
  }, [load]);

  const grantConsent = useCallback(async () => {
    if (!user) return;
    const rec = (await createRecord(
      "ConsentRecord",
      { status: "granted", scope: "anonymous_cohort_learning", grantedAt: new Date().toISOString(), revokedAt: null },
      { userId: user.id },
    )) as unknown as ConsentRecord;
    const u = await db.get("users", user.id);
    if (u) await db.put("users", { ...u, cohortLearningEnabled: true });
    setConsent(rec);
  }, [user]);

  const revokeConsent = useCallback(async () => {
    if (!user || !consent) return;
    await updateRecord("ConsentRecord", consent.id, { status: "revoked", revokedAt: new Date().toISOString() }, { userId: user.id });
    const u = await db.get("users", user.id);
    if (u) await db.put("users", { ...u, cohortLearningEnabled: false });
    await load();
  }, [user, consent, load]);

  const consentStatus: "granted" | "revoked" | "none" = consent ? consent.status : "none";
  const canContributeToNetwork = consentStatus === "granted";

  return { consent, consentStatus, canContributeToNetwork, loading, grantConsent, revokeConsent, reload: load };
}
