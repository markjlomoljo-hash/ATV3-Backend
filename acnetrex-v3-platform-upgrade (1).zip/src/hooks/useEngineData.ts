import { useCallback, useEffect, useState } from "react";
import { listRecords } from "../lib/api/entities";
import {
  onboardingProfileSchema,
  faceScanSchema,
  dailyLogSchema,
  type OnboardingProfile,
  type FaceScan,
  type DailyLog,
} from "../lib/schemas";
import { DAILY_LOG_STORES } from "../lib/constants";
import type { StoreName } from "../lib/db";
import type { EngineBundle } from "../lib/ml/engines";
import { useAuthStore } from "../stores/auth";

export function useEngineData() {
  const user = useAuthStore((s) => s.user);
  const [bundle, setBundle] = useState<EngineBundle | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const profiles = await listRecords(
        "OnboardingProfile",
        onboardingProfileSchema,
        { created_by_id: user.id },
        { limit: 1, sort: "-created_date" },
      );
      const scans = await listRecords(
        "FaceScan",
        faceScanSchema,
        { created_by_id: user.id },
        { limit: 10, sort: "-logDate" },
      );
      const logsByType: Record<string, DailyLog[]> = {};
      for (const store of DAILY_LOG_STORES) {
        logsByType[store] = await listRecords(
          store as StoreName,
          dailyLogSchema,
          { created_by_id: user.id },
          { limit: 20, sort: "-logDate" },
        ).catch(() => [] as DailyLog[]);
      }
      setBundle({
        profile: (profiles[0] as OnboardingProfile) ?? null,
        scans: scans as FaceScan[],
        logsByType,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load data");
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    void load();
  }, [load]);

  return { bundle, loading, error, reload: load };
}
