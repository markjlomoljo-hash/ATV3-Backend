import type { StoreName } from "../db";

export const APP_VERSION = "3.0.0";

/** Minimum real data points before an engine may produce meaningful output. */
export const DATA_THRESHOLDS = {
  FORECAST_MIN_DAYS: 7,
  TRIGGER_GRAPH_MIN_DAYS: 14,
  SKIN_TWIN_MIN_SCANS: 10,
  BARRIER_MIN_DAYS: 5,
  CHI_MIN_LOGS: 3,
} as const;

/** Default pagination limits per entity to prevent unbounded queries. */
export const QUERY_LIMITS: Partial<Record<StoreName, number>> = {
  SleepLog: 20,
  FoodLog: 20,
  StressLog: 20,
  ActivityLog: 20,
  HydrationLog: 20,
  CycleLog: 20,
  ContactLog: 20,
  ClimateLog: 20,
  FaceScan: 10,
  IntelligenceEvent: 50,
  AssistantMessage: 30,
  EvidenceBookmark: 20,
  Forecast: 10,
  HealthIndexSnapshot: 10,
};

export const DAILY_LOG_STORES: StoreName[] = [
  "SleepLog",
  "FoodLog",
  "StressLog",
  "ActivityLog",
  "HydrationLog",
  "CycleLog",
  "ContactLog",
  "ClimateLog",
];

/** Stores that require an AuditLog write on create/update (health-data). */
export const AUDITED_STORES: StoreName[] = [
  "FaceScan",
  "SleepLog",
  "FoodLog",
  "StressLog",
  "ActivityLog",
  "HydrationLog",
  "CycleLog",
  "ContactLog",
  "ClimateLog",
  "ProductScan",
  "AssistantMessage",
  "Forecast",
  "OnboardingProfile",
  "ConsentRecord",
  "HealthIndexSnapshot",
];

export interface DailyTask {
  id: string;
  label: string;
  description: string;
  points: number;
  route: string;
  store: StoreName;
  icon: string;
}

/** Daily task board — each maps to a real data contribution recorded in backend. */
export const DAILY_TASKS: DailyTask[] = [
  { id: "face", label: "Face Scan", description: "Capture a 5-photo FaceAtlas scan", points: 30, route: "/face-atlas", store: "FaceScan", icon: "ScanFace" },
  { id: "sleep", label: "Log Sleep", description: "Record last night's sleep", points: 15, route: "/log/sleep", store: "SleepLog", icon: "Moon" },
  { id: "food", label: "Log Diet", description: "Log today's triggering foods", points: 15, route: "/log/food", store: "FoodLog", icon: "Apple" },
  { id: "stress", label: "Log Stress", description: "Rate today's stress level", points: 10, route: "/log/stress", store: "StressLog", icon: "Activity" },
  { id: "activity", label: "Log Activity", description: "Record movement & sweat", points: 10, route: "/log/activity", store: "ActivityLog", icon: "Footprints" },
  { id: "hydration", label: "Hydration", description: "Track water intake", points: 10, route: "/log/activity", store: "HydrationLog", icon: "Droplet" },
];

export const ENGINE_VERSIONS = {
  face: "face-cv-1.0.0",
  forecast: "forecast-stat-1.2.0",
  chi: "chi-index-1.1.0",
  trigger: "trigger-corr-1.0.0",
  product: "formula-lens-1.0.0",
  assistant: "cutis-rag-1.0.0",
  barrier: "barrier-guard-1.0.0",
} as const;

export const LEGACY_KEYS = {
  credentials: "acnetrex_credentials",
  auth: "acnetrex_auth_v2",
  data: "acnetrex_data_v2",
  ai: "acnetrex_ai_v2",
} as const;

export const SESSION_KEY = "acnetrex_session_v3";
