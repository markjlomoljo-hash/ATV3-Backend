/**
 * AcneTrex durable persistence layer.
 *
 * In production this maps to a BaaS (Base44 entities). In this environment the
 * single source of truth is IndexedDB — a real, durable, transactional store.
 * All entity records are versioned and owner-scoped. This is NOT localStorage
 * session state; it survives reloads, upgrades, and re-auth.
 */

export const DB_NAME = "acnetrex";
export const DB_VERSION = 1;
export const APP_VERSION = "3.0.0";
export const SCHEMA_VERSION = 1;

/** All persistent entity stores. Keyed by `id`. */
export const STORES = [
  "users",
  "OnboardingProfile",
  "FaceScan",
  "SleepLog",
  "FoodLog",
  "StressLog",
  "ActivityLog",
  "HydrationLog",
  "CycleLog",
  "ContactLog",
  "ClimateLog",
  "ProductScan",
  "Forecast",
  "WhatIfScenario",
  "HealthIndexSnapshot",
  "AssistantMessage",
  "EvidenceBookmark",
  "IntelligenceEvent",
  "ConsentRecord",
  "AuditLog",
  "ReportExport",
] as const;

export type StoreName = (typeof STORES)[number];

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const store of STORES) {
        if (!db.objectStoreNames.contains(store)) {
          db.createObjectStore(store, { keyPath: "id" });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
  });
  return dbPromise;
}

function tx(store: StoreName, mode: IDBTransactionMode): Promise<IDBObjectStore> {
  return openDB().then((db) => db.transaction(store, mode).objectStore(store));
}

function reqToPromise<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB request failed"));
  });
}

export function uid(prefix = "rec"): string {
  const rnd =
    typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.floor(performance.now() * 1000)}`;
  return `${prefix}_${rnd}`;
}

export interface BaseRecord {
  id: string;
  created_by_id?: string;
  created_date: string;
  updated_date: string;
  app_version: string;
  schema_version: number;
  [key: string]: unknown;
}

/** Low-level CRUD. Higher-level services add validation + audit logging. */
export const db = {
  async getAll<T extends BaseRecord>(store: StoreName): Promise<T[]> {
    const s = await tx(store, "readonly");
    return reqToPromise(s.getAll() as IDBRequest<T[]>);
  },

  async get<T extends BaseRecord>(store: StoreName, id: string): Promise<T | undefined> {
    const s = await tx(store, "readonly");
    return reqToPromise(s.get(id) as IDBRequest<T | undefined>);
  },

  async put<T extends BaseRecord>(store: StoreName, record: T): Promise<T> {
    const s = await tx(store, "readwrite");
    await reqToPromise(s.put(record));
    return record;
  },

  async remove(store: StoreName, id: string): Promise<void> {
    const s = await tx(store, "readwrite");
    await reqToPromise(s.delete(id));
  },

  async clear(store: StoreName): Promise<void> {
    const s = await tx(store, "readwrite");
    await reqToPromise(s.clear());
  },
};

export type FilterQuery = Record<string, unknown>;
export interface QueryOptions {
  sort?: string; // e.g. "-created_date" for desc
  limit?: number;
  offset?: number;
}

function matches(record: Record<string, unknown>, query: FilterQuery): boolean {
  return Object.entries(query).every(([k, v]) => record[k] === v);
}

function sortRecords<T extends BaseRecord>(records: T[], sort?: string): T[] {
  if (!sort) return records;
  const desc = sort.startsWith("-");
  const key = desc ? sort.slice(1) : sort;
  return [...records].sort((a, b) => {
    const av = a[key] as string | number;
    const bv = b[key] as string | number;
    if (av === bv) return 0;
    const cmp = av > bv ? 1 : -1;
    return desc ? -cmp : cmp;
  });
}

/**
 * Filter records by owner-scoped query. ALWAYS pass a limit for list views.
 * Soft-deleted records (ownerDeleted=true) are excluded automatically.
 */
export async function filter<T extends BaseRecord>(
  store: StoreName,
  query: FilterQuery = {},
  options: QueryOptions = {},
): Promise<T[]> {
  const all = await db.getAll<T>(store);
  const live = all.filter((r) => r["ownerDeleted"] !== true && matches(r, query));
  const sorted = sortRecords(live, options.sort ?? "-created_date");
  const offset = options.offset ?? 0;
  const end = options.limit != null ? offset + options.limit : undefined;
  return sorted.slice(offset, end);
}
