import { createRecord, listRecords } from "../api/entities";
import { intelligenceEventSchema, type IntelligenceEvent } from "../schemas";

/**
 * Intelligence Core telemetry. Every significant inference, retrieval,
 * validation outcome, and learning event emits a structured, persisted event.
 * The Intelligence page derives ALL status from these real records.
 */

export interface EmitArgs {
  userId: string;
  engineType: string;
  operation: string;
  status: IntelligenceEvent["status"];
  modelVersion?: string;
  confidence?: number;
  validationStatus?: string;
  inputRefs?: string[];
  downstreamConsumers?: string[];
  consentStatus?: string;
  message?: string;
}

export async function emitEvent(args: EmitArgs): Promise<void> {
  const { userId, ...rest } = args;
  await createRecord(
    "IntelligenceEvent",
    {
      engineType: rest.engineType,
      operation: rest.operation,
      status: rest.status,
      modelVersion: rest.modelVersion,
      confidence: rest.confidence,
      validationStatus: rest.validationStatus,
      inputRefs: rest.inputRefs ?? [],
      downstreamConsumers: rest.downstreamConsumers ?? [],
      consentStatus: rest.consentStatus,
      message: rest.message,
    },
    { userId, source: "ai_engine" },
  );
}

export async function recentEvents(userId: string, limit = 50): Promise<IntelligenceEvent[]> {
  return listRecords("IntelligenceEvent", intelligenceEventSchema, { created_by_id: userId }, { limit, sort: "-created_date" });
}

export interface CoreStatus {
  totalInferences: number;
  succeeded: number;
  failed: number;
  lastHeartbeat: string | null;
  enginesActive: string[];
  validationRate: number;
  learningEvents: number;
}

/** Derive live AI status purely from persisted telemetry — never decorative. */
export async function coreStatus(userId: string): Promise<CoreStatus> {
  const events = await recentEvents(userId, 50);
  const succeeded = events.filter((e) => e.status === "succeeded" || e.status === "validated").length;
  const failed = events.filter((e) => e.status === "failed" || e.status === "rejected").length;
  const learning = events.filter((e) => e.status === "learning").length;
  const engines = Array.from(new Set(events.map((e) => e.engineType)));
  const validated = events.filter((e) => e.status === "validated").length;
  return {
    totalInferences: events.length,
    succeeded,
    failed,
    lastHeartbeat: events[0]?.created_date ?? null,
    enginesActive: engines,
    validationRate: events.length ? Math.round((validated / events.length) * 100) : 0,
    learningEvents: learning,
  };
}
