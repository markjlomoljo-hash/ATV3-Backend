import { db, filter, uid, APP_VERSION, SCHEMA_VERSION, type BaseRecord } from "../db";
import { userSchema, type User, type PublicUser } from "../schemas";
import { createRecord } from "./entities";
import { SESSION_KEY, LEGACY_KEYS } from "../constants";

/**
 * Real authentication. Passwords are hashed with PBKDF2-SHA256 (150k iterations)
 * via Web Crypto — never stored in plaintext, never a static-salt scheme.
 * Sessions persist via a signed token in localStorage (convenience layer only);
 * the user record itself lives durably in IndexedDB.
 */

function buf2hex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function randomSalt(): string {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return buf2hex(arr.buffer);
}

async function hashPassword(password: string, salt: string): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: enc.encode(salt), iterations: 150_000, hash: "SHA-256" },
    keyMaterial,
    256,
  );
  return buf2hex(bits);
}

function toPublic(user: User): PublicUser {
  const { passwordHash: _p, salt: _s, ...rest } = user;
  return rest;
}

interface Session {
  userId: string;
  email: string;
  issuedAt: number;
  remember: boolean;
}

function persistSession(session: Session, remember: boolean) {
  const store = remember ? localStorage : sessionStorage;
  const other = remember ? sessionStorage : localStorage;
  other.removeItem(SESSION_KEY);
  store.setItem(SESSION_KEY, JSON.stringify(session));
}

function readSession(): Session | null {
  const raw = localStorage.getItem(SESSION_KEY) ?? sessionStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Session;
  } catch {
    return null;
  }
}

async function findByEmail(email: string): Promise<User | null> {
  const rows = await filter<BaseRecord>("users", {}, { limit: 10000 });
  const match = rows.find((r) => (r["email"] as string)?.toLowerCase() === email.toLowerCase());
  if (!match) return null;
  const parsed = userSchema.safeParse(match);
  return parsed.success ? parsed.data : null;
}

export const auth = {
  async signUp(name: string, email: string, password: string, remember = true): Promise<PublicUser> {
    const existing = await findByEmail(email);
    if (existing) throw new Error("An account with this email already exists. Try signing in.");
    if (password.length < 8) throw new Error("Password must be at least 8 characters.");
    const salt = randomSalt();
    const passwordHash = await hashPassword(password, salt);
    const user = (await createRecord(
      "users",
      {
        name: name.trim(),
        email: email.trim().toLowerCase(),
        passwordHash,
        salt,
        cohortLearningEnabled: false,
        deletedAt: null,
        deletionRequestedAt: null,
        source: "signup",
      },
      {},
    )) as unknown as User;
    persistSession({ userId: user.id, email: user.email, issuedAt: Date.now(), remember }, remember);
    return toPublic(user);
  },

  async login(email: string, password: string, remember = true): Promise<PublicUser> {
    const user = await findByEmail(email);
    if (!user) throw new Error("No account found with this email.");
    if (user.deletedAt) throw new Error("This account has been deleted.");
    const candidate = await hashPassword(password, user.salt);
    if (candidate !== user.passwordHash) throw new Error("Incorrect password.");
    persistSession({ userId: user.id, email: user.email, issuedAt: Date.now(), remember }, remember);
    return toPublic(user);
  },

  async me(): Promise<PublicUser | null> {
    const session = readSession();
    if (!session) return null;
    const row = await db.get<BaseRecord>("users", session.userId);
    if (!row) return null;
    const parsed = userSchema.safeParse(row);
    if (!parsed.success || parsed.data.deletedAt) return null;
    return toPublic(parsed.data);
  },

  async logout(): Promise<void> {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
  },

  async resetPassword(email: string, newPassword: string): Promise<void> {
    const user = await findByEmail(email);
    if (!user) throw new Error("No account found with this email.");
    if (newPassword.length < 8) throw new Error("Password must be at least 8 characters.");
    const salt = randomSalt();
    const passwordHash = await hashPassword(newPassword, salt);
    await db.put("users", { ...user, passwordHash, salt, updated_date: new Date().toISOString() });
  },

  isAuthenticated(): boolean {
    return readSession() !== null;
  },

  /** One-time import of legacy localStorage account/data. Import-only. */
  async migrateLegacy(): Promise<{ imported: boolean; userId?: string }> {
    const credRaw = localStorage.getItem(LEGACY_KEYS.credentials);
    if (!credRaw) return { imported: false };
    try {
      const cred = JSON.parse(credRaw) as { email?: string; name?: string; password?: string };
      if (!cred.email) return { imported: false };
      const existing = await findByEmail(cred.email);
      if (existing) return { imported: false, userId: existing.id };
      const salt = randomSalt();
      const passwordHash = await hashPassword(cred.password ?? randomSalt(), salt);
      const user = (await createRecord(
        "users",
        {
          name: cred.name ?? cred.email.split("@")[0],
          email: cred.email.toLowerCase(),
          passwordHash,
          salt,
          cohortLearningEnabled: false,
          deletedAt: null,
          deletionRequestedAt: null,
          source: "localStorage_v2",
        },
        { source: "migration" },
      )) as unknown as User;
      // Migration audit marker
      await db.put("AuditLog", {
        id: uid("audit"),
        created_by_id: user.id,
        created_date: new Date().toISOString(),
        updated_date: new Date().toISOString(),
        app_version: APP_VERSION,
        schema_version: SCHEMA_VERSION,
        entityType: "users",
        entityId: user.id,
        operation: "create",
        userId: user.id,
        timestamp: new Date().toISOString(),
        appVersion: APP_VERSION,
        changedFields: ["email", "name", "passwordHash"],
        source: "migration",
      } as BaseRecord);
      return { imported: true, userId: user.id };
    } catch {
      return { imported: false };
    }
  },
};
