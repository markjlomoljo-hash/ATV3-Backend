import { format } from "date-fns";
import type { z } from "zod";
import {
  db,
  filter,
  uid,
  APP_VERSION,
  SCHEMA_VERSION,
  type BaseRecord,
  type StoreName,
  type FilterQuery,
  type QueryOptions,
} from "../db";
import { AUDITED_STORES, QUERY_LIMITS } from "../constants";

const now = () => new Date().toISOString();

async function writeAudit(
  store: StoreName,
  entityId: string,
  operation: "create" | "update" | "delete",
  userId: string | undefined,
  changedFields: string[],
  source: "user" | "migration" | "ai_engine",
) {
  if (!AUDITED_STORES.includes(store) || !userId) return;
  const ts = now();
  const record: BaseRecord = {
    id: uid("audit"),
    created_by_id: userId,
    created_date: ts,
    updated_date: ts,
    app_version: APP_VERSION,
    schema_version: SCHEMA_VERSION,
    entityType: store,
    entityId,
    operation,
    userId,
    timestamp: ts,
    appVersion: APP_VERSION,
    changedFields,
    source,
  };
  await db.put("AuditLog", record);
}

export interface CreateOpts {
  userId?: string;
  source?: "user" | "migration" | "ai_engine";
}

/** Create a record with full provenance metadata + audit log. */
export async function createRecord<T extends Record<string, unknown>>(
  store: StoreName,
  fields: T,
  opts: CreateOpts = {},
): Promise<BaseRecord & T> {
  const ts = now();
  const record = {
    id: uid(store.toLowerCase()),
    created_by_id: opts.userId,
    created_date: ts,
    updated_date: ts,
    app_version: APP_VERSION,
    schema_version: SCHEMA_VERSION,
    ...fields,
  } as BaseRecord & T;
  await db.put(store, record);
  await writeAudit(store, record.id, "create", opts.userId, Object.keys(fields), opts.source ?? "user");
  return record;
}

/** Update a record + audit log. */
export async function updateRecord<T extends Record<string, unknown>>(
  store: StoreName,
  id: string,
  fields: T,
  opts: CreateOpts = {},
): Promise<BaseRecord> {
  const existing = await db.get(store, id);
  if (!existing) throw new Error(`${store} record ${id} not found`);
  const updated = { ...existing, ...fields, updated_date: now() } as BaseRecord;
  await db.put(store, updated);
  await writeAudit(store, id, "update", opts.userId ?? existing.created_by_id, Object.keys(fields), opts.source ?? "user");
  return updated;
}

/** Owner-scoped list query with enforced limit + Zod validation. */
export async function listRecords<S extends z.ZodTypeAny>(
  store: StoreName,
  schema: S,
  query: FilterQuery = {},
  options: QueryOptions = {},
): Promise<z.infer<S>[]> {
  const limit = options.limit ?? QUERY_LIMITS[store] ?? 50;
  const rows = await filter<BaseRecord>(store, query, { ...options, limit });
  const out: z.infer<S>[] = [];
  for (const row of rows) {
    const parsed = schema.safeParse(row);
    if (parsed.success) out.push(parsed.data);
    // Records failing validation are skipped, never partially rendered.
  }
  return out;
}

export async function getRecord<S extends z.ZodTypeAny>(
  store: StoreName,
  schema: S,
  id: string,
): Promise<z.infer<S> | null> {
  const row = await db.get<BaseRecord>(store, id);
  if (!row) return null;
  const parsed = schema.safeParse(row);
  return parsed.success ? parsed.data : null;
}

/**
 * SAME-DAY LOG MERGE (idempotency). Updates today's record in place instead of
 * creating a duplicate, so the intelligence layer is never misled by dupes.
 */
export async function upsertDailyLog<T extends Record<string, unknown>>(
  store: StoreName,
  userId: string,
  fields: T,
): Promise<BaseRecord> {
  const todayISO = format(new Date(), "yyyy-MM-dd");
  const existing = await filter<BaseRecord>(store, { created_by_id: userId, logDate: todayISO }, { limit: 1 });
  if (existing.length > 0) {
    return updateRecord(store, existing[0].id, { ...fields, logDate: todayISO }, { userId, source: "user" });
  }
  return createRecord(store, { ...fields, logDate: todayISO }, { userId, source: "user" });
}

export async function getTodayLog(store: StoreName, userId: string): Promise<BaseRecord | null> {
  const todayISO = format(new Date(), "yyyy-MM-dd");
  const rows = await filter<BaseRecord>(store, { created_by_id: userId, logDate: todayISO }, { limit: 1 });
  return rows[0] ?? null;
}

/** Mark all owner records deleted (account deletion grace flow). */
export async function softDeleteOwner(userId: string, stores: StoreName[]): Promise<void> {
  for (const store of stores) {
    const rows = await filter<BaseRecord>(store, { created_by_id: userId }, { limit: 10000 });
    for (const r of rows) {
      await db.put(store, { ...r, ownerDeleted: true, updated_date: now() });
    }
  }
}
