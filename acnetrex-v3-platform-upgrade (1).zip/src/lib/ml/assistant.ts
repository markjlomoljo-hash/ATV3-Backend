import { ENGINE_VERSIONS } from "../constants";
import { computeCHI, computeForecast, computeTriggers, computeRiskFactors, type EngineBundle } from "./engines";
import { searchEvidence } from "./evidence";

/**
 * CUTISAI ASSISTANT ENGINE.
 *
 * Pipeline: intent detection → retrieve user context (CHI, forecast, triggers,
 * factors) → retrieve evidence → synthesise grounded answer → self-check pass
 * (remove unsupported certainty, surface uncertainty) → return content +
 * citations + confidence. Answers are grounded in the user's real records; with
 * no data it explicitly says so rather than inventing.
 */

export interface AssistantCitation {
  title: string;
  source: string;
  year?: number;
  url?: string;
}

export interface AssistantAnswer {
  content: string;
  citations: AssistantCitation[];
  confidence: number;
  contextRefs: string[];
  engineVersion: string;
}

type Intent = "score" | "trigger" | "forecast" | "product" | "routine" | "general";

function detectIntent(q: string): Intent {
  const s = q.toLowerCase();
  if (/(chi|score|health index|how.*skin|barrier)/.test(s)) return "score";
  if (/(trigger|cause|why.*break|correlat|flare.*because)/.test(s)) return "trigger";
  if (/(forecast|predict|future|will.*get|next week|improve|when.*clear)/.test(s)) return "forecast";
  if (/(product|ingredient|cream|serum|use.*safe|comedogenic)/.test(s)) return "product";
  if (/(routine|order|morning|night|apply|step)/.test(s)) return "routine";
  return "general";
}

const pct = (n: number) => `${Math.round(n)}`;

export function generateAssistantAnswer(question: string, bundle: EngineBundle): AssistantAnswer {
  const intent = detectIntent(question);
  const hasData = bundle.scans.length > 0 || Object.values(bundle.logsByType).flat().length > 0;
  const contextRefs: string[] = [];
  let body = "";
  let confidence = 0.5;

  const chi = computeCHI(bundle);
  const factors = computeRiskFactors(bundle);

  if (!hasData) {
    return {
      content:
        "I don't have any of your skin data yet, so I can't personalise this. Start by completing a FaceAtlas scan and logging sleep, diet and stress for a few days — then I can explain your scores, find your triggers, and forecast your skin with real confidence.",
      citations: [],
      confidence: 0.3,
      contextRefs: [],
      engineVersion: ENGINE_VERSIONS.assistant,
    };
  }

  switch (intent) {
    case "score": {
      contextRefs.push("CHI");
      body = `Your current Cutis Health Index is ${pct(chi.chi)}/100 (${chi.trend}). It blends inflammation (${pct(chi.inflammation)}), barrier health (${pct(chi.barrier)}) and logging consistency (${pct(chi.consistency)}). `;
      body += chi.barrier < 60 ? "Your barrier reading is on the lower side, which can make skin more reactive. " : "Your barrier reading looks reasonably resilient. ";
      confidence = chi.confidence;
      break;
    }
    case "trigger": {
      contextRefs.push("TriggerGraph");
      const trig = computeTriggers(bundle);
      if (trig.length === 0) {
        body = "I need at least 3 face scans paired with daily logs on matching dates to compute reliable trigger correlations. Keep scanning and logging and I'll surface your strongest drivers.";
        confidence = 0.35;
      } else {
        const top = trig.slice(0, 3).map((t) => `${t.factor} (r=${t.correlation}, ${t.strength})`).join(", ");
        body = `Based on correlations between your logs and scan severity, your most associated factors are: ${top}. Correlation isn't proof of causation, so treat these as leads to test with the What-If simulator. `;
        confidence = Math.min(0.8, 0.4 + trig[0].samples * 0.04);
      }
      break;
    }
    case "forecast": {
      contextRefs.push("Forecast");
      const f = computeForecast(bundle);
      if (f.validationStatus === "insufficient") {
        body = "There isn't enough history yet for a trustworthy forecast — I need around 7 days of logs or a couple of scans. ";
        confidence = 0.3;
      } else {
        const wk = f.horizons.find((h) => h.label === "7 days");
        body = `Your current breakout-risk estimate is ${pct(f.currentRisk)}/100. Projected 7-day risk is about ${wk ? pct(wk.riskScore) : "—"} (range ${wk ? `${wk.lower}–${wk.upper}` : "—"}). ${f.rationale} `;
        if (f.timeToImprovementDays) body += `If you correct your top driver, meaningful improvement is estimated in ~${f.timeToImprovementDays} days. `;
        confidence = f.confidence;
      }
      break;
    }
    case "product": {
      body = "For product safety I analyse the actual ingredient list. Open FormulaLens, paste or scan the ingredients, and I'll score comedogenic, irritant and barrier risk against your profile. ";
      confidence = 0.6;
      break;
    }
    case "routine": {
      const raising = factors.filter((f) => f.direction === "raises").slice(0, 2).map((f) => f.factor.toLowerCase());
      body = `A simple evidence-aligned routine: gentle cleanser, an active suited to your concern (BHA for comedonal, retinoid at night, benzoyl peroxide for inflammatory), then a barrier-supportive moisturiser and daily SPF. `;
      if (raising.length) body += `Given your data, also prioritise addressing ${raising.join(" and ")}. `;
      confidence = 0.55;
      break;
    }
    default: {
      body = `Here's a snapshot from your data: CHI ${pct(chi.chi)}/100 (${chi.trend}). `;
      if (factors.length) body += `Top factor right now: ${factors[0].factor.toLowerCase()} (${factors[0].detail}). `;
      body += "Ask me about your score, triggers, forecast, or a specific product. ";
      confidence = chi.confidence;
    }
  }

  // Evidence retrieval
  const evidence = searchEvidence(question + " " + factors.map((f) => f.factor).join(" "), undefined, 3);
  const citations: AssistantCitation[] = evidence
    .filter((e) => e.score > 0)
    .slice(0, 3)
    .map((e) => ({ title: e.title, source: `${e.journal} (${e.authors})`, year: e.year, url: e.url }));

  // Self-check pass: do not overstate certainty when confidence is low.
  if (confidence < 0.5 && !/\b(might|may|isn't enough|need|estimate|leads)\b/i.test(body)) {
    body += "Confidence is limited by available data, so treat this as a preliminary read. ";
  }
  if (citations.length) body += "I've attached relevant research below.";

  return {
    content: body.trim(),
    citations,
    confidence: Math.round(confidence * 100) / 100,
    contextRefs,
    engineVersion: ENGINE_VERSIONS.assistant,
  };
}
