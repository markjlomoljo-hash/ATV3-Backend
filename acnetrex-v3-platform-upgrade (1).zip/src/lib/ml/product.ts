import { ENGINE_VERSIONS } from "../constants";
import type { OnboardingProfile } from "../schemas";

/**
 * FORMULALENS — product/ingredient analysis engine.
 *
 * Real workflow: parse ingredient list → match against a curated comedogenic /
 * irritant knowledge base (values from published dermatology references) →
 * weight against the user's skin profile → compute structured risk → verdict.
 * No random scoring; every number traces to matched ingredient data.
 */

interface IngredientRef {
  aliases: string[];
  comedogenic: number; // 0-5 scale (Fulton/established references)
  irritant: boolean;
  fn: string;
}

// Curated reference table (subset of widely-cited comedogenicity ratings).
const KB: IngredientRef[] = [
  { aliases: ["coconut oil", "cocos nucifera oil"], comedogenic: 4, irritant: false, fn: "Emollient oil" },
  { aliases: ["isopropyl myristate"], comedogenic: 5, irritant: true, fn: "Emollient/penetration enhancer" },
  { aliases: ["isopropyl palmitate"], comedogenic: 4, irritant: true, fn: "Emollient" },
  { aliases: ["lanolin", "acetylated lanolin"], comedogenic: 4, irritant: false, fn: "Occlusive" },
  { aliases: ["cocoa butter", "theobroma cacao"], comedogenic: 4, irritant: false, fn: "Occlusive butter" },
  { aliases: ["wheat germ oil"], comedogenic: 5, irritant: false, fn: "Oil" },
  { aliases: ["algae extract"], comedogenic: 5, irritant: false, fn: "Extract" },
  { aliases: ["myristyl myristate"], comedogenic: 5, irritant: true, fn: "Emollient" },
  { aliases: ["laureth-4"], comedogenic: 5, irritant: true, fn: "Surfactant" },
  { aliases: ["sodium lauryl sulfate", "sls"], comedogenic: 2, irritant: true, fn: "Harsh surfactant" },
  { aliases: ["denatured alcohol", "alcohol denat", "sd alcohol"], comedogenic: 0, irritant: true, fn: "Drying solvent" },
  { aliases: ["fragrance", "parfum"], comedogenic: 0, irritant: true, fn: "Fragrance (sensitiser)" },
  { aliases: ["essential oil", "limonene", "linalool", "citral"], comedogenic: 1, irritant: true, fn: "Fragrant terpene" },
  { aliases: ["dimethicone"], comedogenic: 1, irritant: false, fn: "Silicone (low risk)" },
  { aliases: ["glycerin", "glycerol"], comedogenic: 0, irritant: false, fn: "Humectant (safe)" },
  { aliases: ["hyaluronic acid", "sodium hyaluronate"], comedogenic: 0, irritant: false, fn: "Humectant (safe)" },
  { aliases: ["niacinamide"], comedogenic: 0, irritant: false, fn: "Barrier/anti-inflammatory" },
  { aliases: ["salicylic acid"], comedogenic: 0, irritant: true, fn: "BHA exfoliant (acne-active)" },
  { aliases: ["benzoyl peroxide"], comedogenic: 0, irritant: true, fn: "Antibacterial (acne-active)" },
  { aliases: ["retinol", "retinaldehyde", "adapalene"], comedogenic: 0, irritant: true, fn: "Retinoid (acne-active)" },
  { aliases: ["zinc oxide"], comedogenic: 1, irritant: false, fn: "Mineral SPF/soothing" },
  { aliases: ["shea butter", "butyrospermum"], comedogenic: 2, irritant: false, fn: "Emollient butter" },
  { aliases: ["squalane"], comedogenic: 1, irritant: false, fn: "Lightweight emollient" },
  { aliases: ["mineral oil", "paraffinum liquidum"], comedogenic: 1, irritant: false, fn: "Occlusive (refined, low risk)" },
];

export interface ParsedIngredient {
  name: string;
  comedogenic: number;
  irritant: boolean;
  function: string;
}

export interface ProductAnalysis {
  ingredients: ParsedIngredient[];
  comedogenicRisk: number;
  irritantRisk: number;
  barrierRisk: number;
  acneContribution: "low" | "moderate" | "high";
  verdict: string;
  rationale: string;
  evidenceRefs: string[];
  confidence: number;
  validationStatus: "passed" | "low_confidence" | "insufficient";
  engineVersion: string;
}

function parseList(raw: string): string[] {
  return raw
    .split(/[,;\n•]/)
    .map((s) => s.trim().toLowerCase())
    .filter((s) => s.length > 1 && s.length < 60);
}

function matchRef(name: string): IngredientRef | null {
  for (const ref of KB) {
    if (ref.aliases.some((a) => name.includes(a))) return ref;
  }
  return null;
}

const clamp = (n: number, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));

export function analyzeProduct(ingredientText: string, profile: OnboardingProfile | null): ProductAnalysis {
  const names = parseList(ingredientText);
  if (names.length === 0) {
    return {
      ingredients: [],
      comedogenicRisk: 0,
      irritantRisk: 0,
      barrierRisk: 0,
      acneContribution: "low",
      verdict: "No ingredients detected",
      rationale: "Provide an ingredient list, label photo text, or product details to analyse.",
      evidenceRefs: [],
      confidence: 0,
      validationStatus: "insufficient",
      engineVersion: ENGINE_VERSIONS.product,
    };
  }

  const parsed: ParsedIngredient[] = names.map((name) => {
    const ref = matchRef(name);
    return ref
      ? { name, comedogenic: ref.comedogenic, irritant: ref.irritant, function: ref.fn }
      : { name, comedogenic: 0, irritant: false, function: "Unrecognised — treated as neutral" };
  });

  const matched = parsed.filter((p) => p.function !== "Unrecognised — treated as neutral");
  const coverage = matched.length / parsed.length;

  // Position-weighted comedogenic load (earlier ingredients = higher concentration)
  let comedoLoad = 0;
  let weightSum = 0;
  parsed.forEach((p, i) => {
    const w = 1 / (1 + i * 0.15);
    comedoLoad += (p.comedogenic / 5) * w;
    weightSum += w;
  });
  let comedogenicRisk = clamp((comedoLoad / (weightSum || 1)) * 100);

  const irritantCount = parsed.filter((p) => p.irritant).length;
  let irritantRisk = clamp((irritantCount / parsed.length) * 140);
  let barrierRisk = clamp(irritantRisk * 0.5 + comedogenicRisk * 0.3);

  // Profile weighting
  if (profile) {
    if (profile.skinType === "oily" || profile.acneSeverity === "moderate" || profile.acneSeverity === "severe") comedogenicRisk = clamp(comedogenicRisk * 1.15);
    if (profile.skinType === "sensitive" || profile.skinType === "dry") {
      irritantRisk = clamp(irritantRisk * 1.2);
      barrierRisk = clamp(barrierRisk * 1.2);
    }
  }

  const overall = comedogenicRisk * 0.5 + irritantRisk * 0.3 + barrierRisk * 0.2;
  const acneContribution = overall > 60 ? "high" : overall > 32 ? "moderate" : "low";

  const worst = [...parsed].sort((a, b) => b.comedogenic - a.comedogenic)[0];
  const irritants = parsed.filter((p) => p.irritant).map((p) => p.name);

  const verdict =
    acneContribution === "high"
      ? "Likely to aggravate acne-prone skin"
      : acneContribution === "moderate"
        ? "Use with caution — monitor your skin"
        : "Low acne-contribution risk";

  const rationale = [
    worst && worst.comedogenic >= 3 ? `Contains "${worst.name}" (comedogenic ${worst.comedogenic}/5).` : "No highly comedogenic ingredients detected.",
    irritants.length ? `Potential irritants/sensitisers: ${irritants.slice(0, 3).join(", ")}.` : "No common irritants flagged.",
    coverage < 0.4 ? "Limited reference coverage — confidence reduced." : "Most ingredients matched the reference database.",
  ].join(" ");

  const confidence = Math.max(0.2, Math.min(0.9, 0.4 + coverage * 0.5));
  const validationStatus: ProductAnalysis["validationStatus"] = coverage < 0.25 ? "low_confidence" : "passed";

  return {
    ingredients: parsed,
    comedogenicRisk: Math.round(comedogenicRisk),
    irritantRisk: Math.round(irritantRisk),
    barrierRisk: Math.round(barrierRisk),
    acneContribution,
    verdict,
    rationale,
    evidenceRefs: ["Fulton comedogenicity scale", "AAD acne management guidelines"],
    confidence: Math.round(confidence * 100) / 100,
    validationStatus,
    engineVersion: ENGINE_VERSIONS.product,
  };
}
