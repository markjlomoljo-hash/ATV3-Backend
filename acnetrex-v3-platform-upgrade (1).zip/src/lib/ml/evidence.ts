/**
 * DermVault evidence index. Curated dermatology evidence metadata with topic
 * tags, summaries, and trust labels. Retrieval is keyword + topic scored.
 * In a backend deployment this is replaced by an internet-augmented InvokeLLM
 * retrieval call; the interface (searchEvidence) stays identical.
 */

export interface EvidenceItem {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  topic: string;
  tags: string[];
  summary: string;
  trustLabel: "peer_reviewed" | "review" | "guideline" | "general";
  url?: string;
}

export const EVIDENCE_INDEX: EvidenceItem[] = [
  {
    id: "ev_diet_gi",
    title: "Low-glycemic-load diet and acne severity: a randomized controlled trial",
    authors: "Smith RN, et al.",
    journal: "American Journal of Clinical Nutrition",
    year: 2007,
    topic: "Diet",
    tags: ["glycemic", "diet", "sugar", "food", "insulin"],
    summary:
      "A 12-week low-glycemic-load diet significantly reduced total and inflammatory acne lesion counts versus a high-GI control, alongside improved insulin sensitivity.",
    trustLabel: "peer_reviewed",
  },
  {
    id: "ev_dairy",
    title: "Dairy intake and acne vulgaris: a systematic review and meta-analysis",
    authors: "Juhl CR, et al.",
    journal: "Nutrients",
    year: 2018,
    topic: "Diet",
    tags: ["dairy", "milk", "diet", "food"],
    summary:
      "Pooled data from 78,529 participants found dairy consumption — particularly skim milk — associated with increased odds of acne, likely via IGF-1 signalling.",
    trustLabel: "review",
  },
  {
    id: "ev_stress",
    title: "Stress and acne: the role of the HPA axis and cutaneous neuropeptides",
    authors: "Chiu A, et al.",
    journal: "Archives of Dermatology",
    year: 2003,
    topic: "Stress",
    tags: ["stress", "cortisol", "hormone", "flare"],
    summary:
      "Increased acne severity correlated with examination stress in students, supporting stress-induced sebaceous and inflammatory pathways.",
    trustLabel: "peer_reviewed",
  },
  {
    id: "ev_sleep",
    title: "Sleep quality, circadian disruption and inflammatory skin disease",
    authors: "Walia HK, et al.",
    journal: "Dermatologic Clinics",
    year: 2019,
    topic: "Sleep",
    tags: ["sleep", "circadian", "inflammation", "barrier"],
    summary:
      "Poor sleep elevates systemic inflammatory markers and impairs skin barrier recovery, plausibly worsening inflammatory acne.",
    trustLabel: "review",
  },
  {
    id: "ev_bha",
    title: "Salicylic acid in the treatment of acne vulgaris",
    authors: "Arif T.",
    journal: "Clinical, Cosmetic and Investigational Dermatology",
    year: 2015,
    topic: "Ingredients",
    tags: ["salicylic", "bha", "exfoliant", "comedonal", "product"],
    summary:
      "Lipophilic salicylic acid penetrates follicles to reduce comedones; well tolerated at 0.5–2% with gradual introduction.",
    trustLabel: "review",
  },
  {
    id: "ev_retinoid",
    title: "Topical retinoids in acne management: guideline recommendations",
    authors: "Zaenglein AL, et al.",
    journal: "Journal of the American Academy of Dermatology",
    year: 2016,
    topic: "Ingredients",
    tags: ["retinoid", "retinol", "adapalene", "comedonal", "product", "treatment"],
    summary:
      "AAD guidelines position topical retinoids as first-line for comedonal and inflammatory acne; start low-frequency to limit irritation.",
    trustLabel: "guideline",
  },
  {
    id: "ev_barrier",
    title: "Skin barrier function in acne vulgaris",
    authors: "Yamamoto A, et al.",
    journal: "Acta Dermato-Venereologica",
    year: 1995,
    topic: "Barrier",
    tags: ["barrier", "dryness", "hydration", "tewl"],
    summary:
      "Acne-prone skin shows impaired barrier and altered ceramide profiles; barrier-supportive moisturisers improve treatment tolerance.",
    trustLabel: "peer_reviewed",
  },
  {
    id: "ev_comedogenic",
    title: "Comedogenicity of cosmetic ingredients: revisiting the rabbit-ear assay",
    authors: "DiNardo JC.",
    journal: "Journal of Cosmetic Dermatology",
    year: 2005,
    topic: "Ingredients",
    tags: ["comedogenic", "ingredient", "product", "pore"],
    summary:
      "Reviews comedogenicity ratings and their real-world limits; emphasises full-formulation context over single-ingredient scores.",
    trustLabel: "review",
  },
  {
    id: "ev_sweat",
    title: "Acne mechanica: friction, occlusion and sweat",
    authors: "Mills OH, Kligman A.",
    journal: "Archives of Dermatology",
    year: 1975,
    topic: "Activity",
    tags: ["sweat", "friction", "activity", "occlusion", "mechanica"],
    summary:
      "Mechanical factors — pressure, friction, occlusion and sweat — can induce or worsen acne; prompt cleansing post-exercise helps.",
    trustLabel: "peer_reviewed",
  },
  {
    id: "ev_hormonal",
    title: "Hormonal influences and the menstrual cycle in acne",
    authors: "Geller L, et al.",
    journal: "International Journal of Women's Dermatology",
    year: 2014,
    topic: "Hormonal",
    tags: ["cycle", "hormone", "menstrual", "androgen", "flare"],
    summary:
      "Premenstrual flares are common; androgen-driven sebum changes across the cycle explain timing of breakouts in many women.",
    trustLabel: "review",
  },
];

export interface ScoredEvidence extends EvidenceItem {
  score: number;
}

export function searchEvidence(query: string, topic?: string, limit = 8): ScoredEvidence[] {
  const q = query.toLowerCase();
  const terms = q.split(/\s+/).filter((t) => t.length > 2);
  const scored = EVIDENCE_INDEX.map((item) => {
    let score = 0;
    if (topic && item.topic.toLowerCase() === topic.toLowerCase()) score += 5;
    for (const term of terms) {
      if (item.tags.some((t) => t.includes(term) || term.includes(t))) score += 3;
      if (item.title.toLowerCase().includes(term)) score += 2;
      if (item.summary.toLowerCase().includes(term)) score += 1;
      if (item.topic.toLowerCase().includes(term)) score += 2;
    }
    return { ...item, score };
  });
  return scored
    .filter((s) => s.score > 0 || !query)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}
