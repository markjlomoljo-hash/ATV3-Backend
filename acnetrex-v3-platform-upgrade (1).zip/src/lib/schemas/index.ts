import { z } from "zod";

/**
 * Runtime validation schemas. TypeScript types are erased at runtime, so every
 * entity record and every engine response that reaches the display layer is
 * validated here with safeParse before rendering. Partial data never renders.
 */

export const baseRecord = z.object({
  id: z.string(),
  created_by_id: z.string().optional(),
  created_date: z.string(),
  updated_date: z.string(),
  app_version: z.string(),
  schema_version: z.number(),
  ownerDeleted: z.boolean().optional(),
});

export const userSchema = baseRecord.extend({
  email: z.string().email(),
  name: z.string(),
  passwordHash: z.string(),
  salt: z.string(),
  source: z.string().optional(),
  cohortLearningEnabled: z.boolean().optional(),
  deletedAt: z.string().nullable().optional(),
  deletionRequestedAt: z.string().nullable().optional(),
});
export type User = z.infer<typeof userSchema>;
export type PublicUser = Omit<User, "passwordHash" | "salt">;

export const onboardingProfileSchema = baseRecord.extend({
  skinType: z.enum(["oily", "dry", "combination", "normal", "sensitive"]),
  acneSeverity: z.enum(["none", "mild", "moderate", "severe"]),
  primaryConcern: z.string(),
  age: z.number().int().min(10).max(99),
  biologicalSex: z.enum(["female", "male", "other", "prefer_not"]),
  goals: z.array(z.string()),
  knownTriggers: z.array(z.string()),
  completed: z.boolean(),
  completedAt: z.string().nullable().optional(),
});
export type OnboardingProfile = z.infer<typeof onboardingProfileSchema>;

const zoneFinding = z.object({
  zone: z.string(),
  inflammatory: z.number().min(0).max(100),
  comedonal: z.number().min(0).max(100),
  redness: z.number().min(0).max(100),
  pih: z.number().min(0).max(100),
});

export const faceScanSchema = baseRecord.extend({
  logDate: z.string(),
  photoCount: z.number().int(),
  photos: z.array(z.string()), // data URLs
  qualityScore: z.number().min(0).max(100),
  faceDetected: z.boolean(),
  zones: z.array(zoneFinding),
  lesionCount: z.number().int().min(0),
  oiliness: z.number().min(0).max(100),
  dryness: z.number().min(0).max(100),
  scarVisibility: z.number().min(0).max(100),
  overallSeverity: z.number().min(0).max(100),
  confidence: z.number().min(0).max(1),
  validationStatus: z.enum(["passed", "low_confidence", "insufficient"]),
  engineVersion: z.string(),
});
export type FaceScan = z.infer<typeof faceScanSchema>;

export const dailyLogSchema = baseRecord.extend({
  logDate: z.string(),
  type: z.string(),
  values: z.record(z.string(), z.union([z.number(), z.string(), z.boolean()])),
  note: z.string().optional(),
});
export type DailyLog = z.infer<typeof dailyLogSchema>;

const ingredientFinding = z.object({
  name: z.string(),
  comedogenic: z.number().min(0).max(5),
  irritant: z.boolean(),
  function: z.string(),
});

export const productScanSchema = baseRecord.extend({
  brand: z.string(),
  productName: z.string(),
  category: z.string(),
  ingredients: z.array(ingredientFinding),
  comedogenicRisk: z.number().min(0).max(100),
  irritantRisk: z.number().min(0).max(100),
  barrierRisk: z.number().min(0).max(100),
  acneContribution: z.enum(["low", "moderate", "high"]),
  verdict: z.string(),
  rationale: z.string(),
  evidenceRefs: z.array(z.string()),
  confidence: z.number().min(0).max(1),
  validationStatus: z.enum(["passed", "low_confidence", "insufficient"]),
  engineVersion: z.string(),
});
export type ProductScan = z.infer<typeof productScanSchema>;

const forecastHorizon = z.object({
  label: z.string(),
  riskScore: z.number().min(0).max(100),
  lower: z.number().min(0).max(100),
  upper: z.number().min(0).max(100),
});

export const forecastSchema = baseRecord.extend({
  currentRisk: z.number().min(0).max(100),
  horizons: z.array(forecastHorizon),
  drivers: z.array(z.object({ factor: z.string(), weight: z.number(), direction: z.enum(["raises", "lowers"]) })),
  timeToImprovementDays: z.number().int().nullable(),
  confidence: z.number().min(0).max(1),
  validationStatus: z.enum(["passed", "low_confidence", "insufficient"]),
  engineVersion: z.string(),
  rationale: z.string(),
});
export type Forecast = z.infer<typeof forecastSchema>;

export const whatIfScenarioSchema = baseRecord.extend({
  changedFactor: z.string(),
  baselineRisk: z.number(),
  projectedRisk: z.number(),
  deltaPct: z.number(),
  rationale: z.string(),
  engineVersion: z.string(),
});
export type WhatIfScenario = z.infer<typeof whatIfScenarioSchema>;

export const healthIndexSnapshotSchema = baseRecord.extend({
  date: z.string(),
  chi: z.number().min(0).max(100),
  barrier: z.number().min(0).max(100),
  inflammation: z.number().min(0).max(100),
  consistency: z.number().min(0).max(100),
  trend: z.enum(["improving", "stable", "worsening"]),
  contributingLogs: z.number().int(),
  confidence: z.number().min(0).max(1),
});
export type HealthIndexSnapshot = z.infer<typeof healthIndexSnapshotSchema>;

const citation = z.object({ title: z.string(), source: z.string(), year: z.number().optional(), url: z.string().optional() });

export const assistantMessageSchema = baseRecord.extend({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  citations: z.array(citation).optional(),
  confidence: z.number().min(0).max(1).optional(),
  contextRefs: z.array(z.string()).optional(),
  feedback: z.enum(["up", "down"]).nullable().optional(),
  threadId: z.string(),
});
export type AssistantMessage = z.infer<typeof assistantMessageSchema>;

export const evidenceBookmarkSchema = baseRecord.extend({
  title: z.string(),
  authors: z.string().optional(),
  journal: z.string().optional(),
  year: z.number().optional(),
  topic: z.string(),
  summary: z.string(),
  trustLabel: z.enum(["peer_reviewed", "review", "guideline", "general"]),
  url: z.string().optional(),
  bookmarked: z.boolean(),
});
export type EvidenceBookmark = z.infer<typeof evidenceBookmarkSchema>;

export const intelligenceEventSchema = baseRecord.extend({
  engineType: z.string(),
  operation: z.string(),
  status: z.enum(["started", "succeeded", "failed", "validated", "rejected", "learning", "truncated"]),
  modelVersion: z.string().optional(),
  confidence: z.number().optional(),
  validationStatus: z.string().optional(),
  inputRefs: z.array(z.string()).optional(),
  downstreamConsumers: z.array(z.string()).optional(),
  consentStatus: z.string().optional(),
  message: z.string().optional(),
});
export type IntelligenceEvent = z.infer<typeof intelligenceEventSchema>;

export const consentRecordSchema = baseRecord.extend({
  status: z.enum(["granted", "revoked"]),
  scope: z.string(),
  grantedAt: z.string().nullable().optional(),
  revokedAt: z.string().nullable().optional(),
});
export type ConsentRecord = z.infer<typeof consentRecordSchema>;

export const auditLogSchema = baseRecord.extend({
  entityType: z.string(),
  entityId: z.string(),
  operation: z.enum(["create", "update", "delete"]),
  userId: z.string(),
  timestamp: z.string(),
  appVersion: z.string(),
  changedFields: z.array(z.string()),
  source: z.enum(["user", "migration", "ai_engine"]),
});
export type AuditLog = z.infer<typeof auditLogSchema>;

export const reportExportSchema = baseRecord.extend({
  title: z.string(),
  rangeStart: z.string(),
  rangeEnd: z.string(),
  summary: z.string(),
  sections: z.array(z.object({ heading: z.string(), body: z.string() })),
  generatedAt: z.string(),
});
export type ReportExport = z.infer<typeof reportExportSchema>;
