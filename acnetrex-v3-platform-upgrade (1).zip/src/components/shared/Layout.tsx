import { useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import {
  Home,
  ScanFace,
  TrendingUp,
  Sparkles,
  Brain,
  Menu,
  X,
  ChevronLeft,
  Droplets,
  FlaskConical,
  BookOpen,
  Boxes,
  CloudSun,
  CalendarHeart,
  Hand,
  Moon,
  Apple,
  Activity,
  FileText,
  User,
  LogOut,
} from "lucide-react";
import { cn } from "../../utils/cn";
import { useAuthStore } from "../../stores/auth";

const PRIMARY_NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/face-atlas", label: "FaceAtlas", icon: ScanFace },
  { to: "/forecast", label: "Forecast", icon: TrendingUp },
  { to: "/ai", label: "CutisAI", icon: Sparkles },
  { to: "/intelligence", label: "Core", icon: Brain },
];

const DRAWER_NAV = [
  { to: "/triggers", label: "TriggerGraph", icon: Activity },
  { to: "/barrier", label: "BarrierGuard", icon: Droplets },
  { to: "/skin-twin", label: "Skin Twin Lab", icon: Boxes },
  { to: "/products", label: "FormulaLens", icon: FlaskConical },
  { to: "/research", label: "DermVault", icon: BookOpen },
  { to: "/sleep", label: "SleepDerm", icon: Moon },
  { to: "/diet", label: "DermDiet", icon: Apple },
  { to: "/activity", label: "SweatFlow", icon: Activity },
  { to: "/cycle", label: "CycleSync", icon: CalendarHeart },
  { to: "/contact", label: "ContactGuard", icon: Hand },
  { to: "/climate", label: "ClimateSkin", icon: CloudSun },
  { to: "/reports", label: "Reports", icon: FileText },
  { to: "/profile", label: "Profile & Privacy", icon: User },
];

const TITLES: Record<string, string> = {
  "/": "AcneTrex",
  "/face-atlas": "FaceAtlas",
  "/forecast": "Skin Horizon",
  "/ai": "CutisAI",
  "/intelligence": "Intelligence Core",
  "/triggers": "TriggerGraph",
  "/barrier": "BarrierGuard",
  "/skin-twin": "Skin Twin Lab",
  "/products": "FormulaLens",
  "/research": "DermVault",
  "/reports": "Reports",
  "/profile": "Profile & Privacy",
  "/sleep": "SleepDerm",
  "/diet": "DermDiet",
  "/activity": "SweatFlow",
  "/cycle": "CycleSync",
  "/contact": "ContactGuard",
  "/climate": "ClimateSkin",
};

export default function Layout() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const isHome = location.pathname === "/";
  const title = TITLES[location.pathname] ?? "AcneTrex";

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-canvas">
      {/* Header */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-surface/90 px-3 backdrop-blur">
        <div className="flex items-center gap-1">
          {!isHome ? (
            <button onClick={() => navigate(-1)} className="flex h-11 w-11 items-center justify-center rounded-xl text-ink active:bg-canvas" aria-label="Back">
              <ChevronLeft className="h-5 w-5" />
            </button>
          ) : (
            <div className="flex items-center gap-2 pl-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent text-white">
                <Sparkles className="h-4 w-4" />
              </div>
            </div>
          )}
          <h1 className="text-base font-semibold text-ink">{title}</h1>
        </div>
        <button onClick={() => setDrawerOpen(true)} className="flex h-11 w-11 items-center justify-center rounded-xl text-ink active:bg-canvas" aria-label="Menu">
          <Menu className="h-5 w-5" />
        </button>
      </header>

      {/* Content */}
      <main className="scroll-touch flex-1 overflow-y-auto px-4 pt-4 at-safe-bottom">
        <Outlet />
      </main>

      {/* Bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-md items-stretch justify-around border-t border-line bg-surface/95 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur">
        {PRIMARY_NAV.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              cn(
                "flex min-h-[3.25rem] w-full flex-col items-center justify-center gap-0.5 py-1.5 text-[10px] font-medium transition-colors",
                isActive ? "text-accent" : "text-muted",
              )
            }
          >
            {({ isActive }) => (
              <>
                <Icon className={cn("h-[22px] w-[22px]", isActive && "stroke-[2.4]")} />
                <span>{label}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="fixed inset-0 z-40 bg-ink/40"
              onClick={() => setDrawerOpen(false)}
            />
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.2, ease: "easeOut" }}
              className="fixed inset-y-0 right-0 z-50 flex w-[82%] max-w-xs flex-col bg-surface"
            >
              <div className="flex h-14 items-center justify-between border-b border-line px-4">
                <span className="text-sm font-semibold text-ink">{user?.name ?? "Menu"}</span>
                <button onClick={() => setDrawerOpen(false)} className="flex h-11 w-11 items-center justify-center rounded-xl active:bg-canvas" aria-label="Close">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="scroll-touch flex-1 overflow-y-auto p-2">
                {DRAWER_NAV.map(({ to, label, icon: Icon }) => (
                  <NavLink
                    key={to}
                    to={to}
                    onClick={() => setDrawerOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        "flex min-h-[3rem] items-center gap-3 rounded-xl px-3 text-sm font-medium",
                        isActive ? "bg-primary-soft text-primary" : "text-ink active:bg-canvas",
                      )
                    }
                  >
                    <Icon className="h-5 w-5" />
                    {label}
                  </NavLink>
                ))}
              </div>
              <div className="border-t border-line p-2">
                <button
                  onClick={async () => {
                    await logout();
                    setDrawerOpen(false);
                    navigate("/auth");
                  }}
                  className="flex min-h-[3rem] w-full items-center gap-3 rounded-xl px-3 text-sm font-medium text-flare active:bg-canvas"
                >
                  <LogOut className="h-5 w-5" />
                  Log out
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
