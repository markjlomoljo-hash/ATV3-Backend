import type { ReactNode, ButtonHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

export function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-2xl bg-surface border border-line shadow-[0_1px_3px_rgba(30,30,40,0.04)]",
        onClick && "cursor-pointer active:scale-[0.99] transition-transform duration-150",
        className,
      )}
    >
      {children}
    </div>
  );
}

interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
  full?: boolean;
}

export function Button({ children, variant = "primary", size = "md", loading, full, className, disabled, ...rest }: BtnProps) {
  const variants = {
    primary: "bg-primary text-white hover:bg-[#6a5cd6] disabled:opacity-50",
    secondary: "bg-primary-soft text-primary hover:bg-[#e4dffa] disabled:opacity-50",
    ghost: "bg-transparent text-ink hover:bg-canvas disabled:opacity-50",
    danger: "bg-flare text-white hover:opacity-90 disabled:opacity-50",
  };
  const sizes = { sm: "h-9 px-3 text-sm", md: "h-11 px-4 text-sm", lg: "h-12 px-5 text-base" };
  return (
    <button
      disabled={disabled || loading}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-150 active:scale-[0.98]",
        variants[variant],
        sizes[size],
        full && "w-full",
        className,
      )}
      {...rest}
    >
      {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />}
      {children}
    </button>
  );
}

export function Badge({ children, tone = "neutral", className }: { children: ReactNode; tone?: "neutral" | "primary" | "accent" | "clear" | "flare"; className?: string }) {
  const tones = {
    neutral: "bg-canvas text-muted",
    primary: "bg-primary-soft text-primary",
    accent: "bg-accent-soft text-[#2596b7]",
    clear: "bg-[#e4f7ef] text-clear",
    flare: "bg-[#fde9ec] text-flare",
  };
  return <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold", tones[tone], className)}>{children}</span>;
}

export function Progress({ value, max = 100, tone = "primary", className }: { value: number; max?: number; tone?: "primary" | "accent" | "clear" | "flare"; className?: string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const tones = { primary: "bg-primary", accent: "bg-accent", clear: "bg-clear", flare: "bg-flare" };
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-canvas", className)}>
      <div className={cn("h-full rounded-full transition-all duration-500 ease-out", tones[tone])} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function SectionTitle({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between px-1">
      <h2 className="text-base font-semibold text-ink">{title}</h2>
      {action}
    </div>
  );
}

export function ConfidenceBadge({ confidence }: { confidence: number }) {
  const tone = confidence >= 0.6 ? "clear" : confidence >= 0.4 ? "accent" : "flare";
  return <Badge tone={tone}>Confidence {Math.round(confidence * 100)}%</Badge>;
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-[#f6d4d9] bg-[#fdf1f3] px-4 py-3">
      <p className="text-sm text-flare">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="shrink-0 text-sm font-semibold text-flare underline">
          Retry
        </button>
      )}
    </div>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-12 text-muted">
      <span className="h-7 w-7 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      {label && <p className="text-sm">{label}</p>}
    </div>
  );
}

export function Ring({ value, size = 96, label, sublabel, tone = "#7C6EE6" }: { value: number; size?: number; label?: string; sublabel?: string; tone?: string }) {
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, value));
  const offset = circ - (pct / 100) * circ;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#ECECF1" strokeWidth={8} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={tone} strokeWidth={8} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={offset} style={{ transition: "stroke-dashoffset 0.6s ease-out" }} />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-xl font-bold text-ink">{label ?? Math.round(value)}</span>
        {sublabel && <span className="text-[10px] font-medium uppercase tracking-wide text-muted">{sublabel}</span>}
      </div>
    </div>
  );
}
