import type { LucideIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button, Card, Progress } from "./ui";

/** Shared EmptyState — used when an entity query returns zero records. */
export function EmptyState({
  icon: Icon,
  title,
  description,
  ctaLabel,
  ctaRoute,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  ctaLabel: string;
  ctaRoute: string;
}) {
  const navigate = useNavigate();
  return (
    <Card className="flex flex-col items-center gap-4 px-6 py-10 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-soft text-primary">
        <Icon className="h-7 w-7" />
      </div>
      <div className="space-y-1.5">
        <h3 className="text-base font-semibold text-ink">{title}</h3>
        <p className="mx-auto max-w-xs text-sm text-muted">{description}</p>
      </div>
      <Button onClick={() => navigate(ctaRoute)}>{ctaLabel}</Button>
    </Card>
  );
}

/** Shared InsufficientDataState — used when data volume is below threshold. */
export function InsufficientDataState({
  moduleName,
  requiredDataPoints,
  currentDataPoints,
  ctaLabel,
  ctaRoute,
}: {
  moduleName: string;
  requiredDataPoints: number;
  currentDataPoints: number;
  ctaLabel: string;
  ctaRoute: string;
}) {
  const navigate = useNavigate();
  const remaining = Math.max(0, requiredDataPoints - currentDataPoints);
  return (
    <Card className="space-y-4 px-6 py-8 text-center">
      <div className="space-y-1.5">
        <h3 className="text-base font-semibold text-ink">{moduleName} is warming up</h3>
        <p className="mx-auto max-w-xs text-sm text-muted">
          This engine needs <span className="font-semibold text-ink">{requiredDataPoints}</span> data points for a trustworthy result. You have{" "}
          <span className="font-semibold text-ink">{currentDataPoints}</span>. {remaining} more to go.
        </p>
      </div>
      <div className="space-y-1.5">
        <Progress value={currentDataPoints} max={requiredDataPoints} />
        <p className="text-xs font-medium text-muted">
          {currentDataPoints} / {requiredDataPoints}
        </p>
      </div>
      <Button onClick={() => navigate(ctaRoute)}>{ctaLabel}</Button>
    </Card>
  );
}
