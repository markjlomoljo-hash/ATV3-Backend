import { useEffect, useState } from "react";
import { BrowserRouter, HashRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { useAuthStore } from "./stores/auth";
import { listRecords } from "./lib/api/entities";
import { onboardingProfileSchema } from "./lib/schemas";
import Layout from "./components/shared/Layout";
import { Spinner } from "./components/shared/ui";

import AuthPage from "./features/auth/AuthPage";
import OnboardingPage from "./features/onboarding/OnboardingPage";
import Dashboard from "./features/dashboard/Dashboard";
import FaceAtlas from "./features/scans/FaceAtlas";
import LogPage from "./features/logs/LogPage";
import Forecast from "./features/forecast/Forecast";
import Assistant from "./features/assistant/Assistant";
import Intelligence from "./features/intelligence/Intelligence";
import Triggers from "./features/analytics/Triggers";
import Barrier from "./features/analytics/Barrier";
import SkinTwin from "./features/analytics/SkinTwin";
import TrackerModule from "./features/analytics/TrackerModule";
import Products from "./features/products/Products";
import Research from "./features/research/Research";
import Reports from "./features/reports/Reports";
import Profile from "./features/profile/Profile";

// vite-plugin-singlefile serves from file:// in some contexts; HashRouter is
// the most robust for a single-file bundle. Fall back gracefully.
const Router = typeof window !== "undefined" && window.location.protocol === "file:" ? HashRouter : BrowserRouter;

function FullScreenSpinner() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas">
      <Spinner label="AcneTrex" />
    </div>
  );
}

/** Auth gate. Redirects unauthenticated users to /auth. */
function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, initialized } = useAuthStore();
  const location = useLocation();
  if (!initialized) return <FullScreenSpinner />;
  if (!user) return <Navigate to="/auth" replace state={{ from: location.pathname }} />;
  return <>{children}</>;
}

/** Onboarding gate. Authenticated users without a completed profile go to /onboarding. */
function RequireOnboarding({ children }: { children: React.ReactNode }) {
  const user = useAuthStore((s) => s.user);
  const [status, setStatus] = useState<"checking" | "done" | "needed">("checking");

  useEffect(() => {
    let active = true;
    if (!user) return;
    void (async () => {
      const rows = await listRecords("OnboardingProfile", onboardingProfileSchema, { created_by_id: user.id }, { limit: 1, sort: "-created_date" });
      if (active) setStatus(rows[0]?.completed ? "done" : "needed");
    })();
    return () => {
      active = false;
    };
  }, [user]);

  if (status === "checking") return <FullScreenSpinner />;
  if (status === "needed") return <Navigate to="/onboarding" replace />;
  return <>{children}</>;
}

export default function App() {
  const init = useAuthStore((s) => s.init);
  const initialized = useAuthStore((s) => s.initialized);

  useEffect(() => {
    void init();
  }, [init]);

  if (!initialized) return <FullScreenSpinner />;

  return (
    <Router>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route
          path="/onboarding"
          element={
            <RequireAuth>
              <OnboardingPage />
            </RequireAuth>
          }
        />
        <Route
          element={
            <RequireAuth>
              <RequireOnboarding>
                <Layout />
              </RequireOnboarding>
            </RequireAuth>
          }
        >
          <Route path="/" element={<Dashboard />} />
          <Route path="/face-atlas" element={<FaceAtlas />} />
          <Route path="/log/:type" element={<LogPage />} />
          <Route path="/forecast" element={<Forecast />} />
          <Route path="/ai" element={<Assistant />} />
          <Route path="/intelligence" element={<Intelligence />} />
          <Route path="/triggers" element={<Triggers />} />
          <Route path="/barrier" element={<Barrier />} />
          <Route path="/skin-twin" element={<SkinTwin />} />
          <Route path="/products" element={<Products />} />
          <Route path="/research" element={<Research />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/sleep" element={<TrackerModule routeKey="sleep" />} />
          <Route path="/diet" element={<TrackerModule routeKey="diet" />} />
          <Route path="/activity" element={<TrackerModule routeKey="activity" />} />
          <Route path="/cycle" element={<TrackerModule routeKey="cycle" />} />
          <Route path="/contact" element={<TrackerModule routeKey="contact" />} />
          <Route path="/climate" element={<TrackerModule routeKey="climate" />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
